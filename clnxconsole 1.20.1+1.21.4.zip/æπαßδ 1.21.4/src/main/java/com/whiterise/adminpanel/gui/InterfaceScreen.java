package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.hud.HudManager;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Современный экран настроек интерфейса (HUD) - полностью переработанный дизайн
 * Двухколоночный макет с анимированными переключателями
 */
public class InterfaceScreen extends Screen {
    private final Screen parent;
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fillGradient()
    }
    
    // Цвета - интегрированы с ColorManager
    private int COLOR_BG_DARKEST() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_DARK() { return ColorManager.getC2().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BG_HOVER() { return adjustBrightness(ColorManager.getC3().getRGB(), 1.15f); }
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    // ФИКСИРОВАННЫЕ цвета (не зависят от темы)
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;    // Белый всегда
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;  // Светло-серый всегда
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;      // Серый всегда
    private static final int COLOR_SUCCESS_FIXED = 0xFF10b981;
    private static final int COLOR_ACCENT_FIXED = 0xFF00D9FF;
    
    // Виджеты
    private ModernSliderWidget scaleSlider;
    private ModernSliderWidget opacitySlider; // Новый ползунок прозрачности
    private ModernToggleWidget togglePlayer;
    private ModernToggleWidget toggleFps;
    private ModernToggleWidget togglePing;
    private ModernToggleWidget toggleTime;
    private ModernToggleWidget togglePunishments;
    private ModernToggleWidget toggleBackgroundParticles; // Новый переключатель
    private net.minecraft.client.gui.widget.ButtonWidget saveButton;
    private net.minecraft.client.gui.widget.ButtonWidget backButton;
    private net.minecraft.client.gui.widget.ButtonWidget particleSettingsButton; // Кнопка настроек частиц
    
    public InterfaceScreen(Screen parent) {
        super(Text.literal("Настройки интерфейса"));
        this.parent = parent;
    }
    
    @Override
    protected void init() {
        HudManager.getInstance().loadConfig();
        var unifiedBar = HudManager.getInstance().getUnifiedBar();
        
        int panelX = this.width / 2 - 250;
        int panelY = 60;
        int centerX = panelX + 250;
        int leftColX = panelX + 40;
        int rightColX = centerX + 40;
        
        // === ЛЕВАЯ КОЛОНКА ===
        
        // Только слайдер масштаба
        int leftY = panelY + 30;
        
        // Слайдер масштаба (вплотную к тексту)
        leftY += 15; // Уменьшено с 40 до 15 (вплотную)
        int sliderY = leftY + 25;
        scaleSlider = new ModernSliderWidget(
            leftColX, sliderY, 180, 6, // Высота уменьшена с 8 до 6
            0.5, 2.0, unifiedBar.getScale(), 0.05,
            value -> {
                unifiedBar.setScale((float)value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(scaleSlider);
        
        // Слайдер прозрачности (вплотную к тексту)
        leftY += 50; // Отступ после масштаба
        int opacitySliderY = leftY + 10; // Уменьшено с 25 до 10 (вплотную)
        opacitySlider = new ModernSliderWidget(
            leftColX, opacitySliderY, 180, 6,
            0.0, 1.0, unifiedBar.getOpacity(), 0.05,
            value -> {
                unifiedBar.setOpacity((float)value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(opacitySlider);
        
        // === ПРАВАЯ КОЛОНКА ===
        
        int rightY = panelY + 15; // Поднимаем весь текст на 5px выше (было 20)
        
        // Переключатель "Игрок" - выровнен с текстом
        togglePlayer = new ModernToggleWidget(
            rightColX + 120, rightY, "Игрок", 
            unifiedBar.isShowPlayer(),
            value -> {
                unifiedBar.setShowPlayer(value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(togglePlayer);
        rightY += 35; // Было 40, уменьшаем отступ
        
        // Переключатель "FPS" - выровнен с текстом
        toggleFps = new ModernToggleWidget(
            rightColX + 120, rightY, "FPS",
            unifiedBar.isShowFps(),
            value -> {
                unifiedBar.setShowFps(value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(toggleFps);
        rightY += 35; // Было 40
        
        // Переключатель "Пинг" - выровнен с текстом
        togglePing = new ModernToggleWidget(
            rightColX + 120, rightY, "Пинг",
            unifiedBar.isShowPing(),
            value -> {
                unifiedBar.setShowPing(value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(togglePing);
        rightY += 35; // Было 40
        
        // Переключатель "Время сессии" - выровнен с текстом
        toggleTime = new ModernToggleWidget(
            rightColX + 120, rightY, "Время сессии",
            unifiedBar.isShowTime(),
            value -> {
                unifiedBar.setShowTime(value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(toggleTime);
        rightY += 35; // Было 40
        
        // Переключатель "Наказания" - выровнен с текстом
        togglePunishments = new ModernToggleWidget(
            rightColX + 120, rightY, "Наказания",
            unifiedBar.isShowPunishments(),
            value -> {
                unifiedBar.setShowPunishments(value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(togglePunishments);
        rightY += 35; // Было 40
        
        // === РАЗДЕЛИТЕЛЬ ===
        rightY += 5; // Уменьшаем отступ чтобы поднять переключатель "Частицы" на 5px
        
        // Переключатель "Частицы" (фоновые частицы) - выровнен с текстом
        toggleBackgroundParticles = new ModernToggleWidget(
            rightColX + 120, rightY, "Частицы",
            com.whiterise.adminpanel.hud.HudConfig.isBackgroundParticlesEnabled(),
            value -> {
                com.whiterise.adminpanel.hud.HudConfig.setBackgroundParticlesEnabled(value);
                HudManager.getInstance().saveConfig();
            }
        );
        addDrawableChild(toggleBackgroundParticles);
        
        // Кнопка настроек частиц (шестерёнка) - справа от переключателя, опущена на 4px
        particleSettingsButton = new net.minecraft.client.gui.widget.ButtonWidget(
            rightColX + 120 + 50, rightY - 6, 24, 24, // Y - 6 вместо Y - 10 (опущено на 4px)
            Text.literal("⚙"),
            button -> {
                SoundManager.playClickSound();
                this.client.setScreen(new ParticleSettingsScreen(this));
            },
            (button) -> Text.literal("Настройки частиц")
        ) {
            @Override
            public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
                int x = getX();
                int y = getY();
                int width = getWidth();
                int height = getHeight();
                
                // Цвет кнопки с эффектом hover - ЯРЧЕ
                int bgColor = isHovered() ? adjustBrightness(COLOR_BG_DARK(), 1.3f) : COLOR_BG_DARK();
                
                // Закругленная кнопка
                RenderUtils.fillRounded(context, x, y, width, height, 6, bgColor);
                RenderUtils.drawRoundedBorder(context, x, y, width, height, 6, isHovered() ? COLOR_ACCENT_FIXED : COLOR_BORDER());
                
                // Иконка шестерёнки - ЯРЧЕ и КРУПНЕЕ
                var mc = net.minecraft.client.MinecraftClient.getInstance();
                String icon = "⚙";
                int iconWidth = mc.textRenderer.getWidth(icon);
                
                // Увеличиваем размер иконки через масштаб
                context.getMatrices().push();
                context.getMatrices().translate(x + width / 2.0, y + height / 2.0, 0);
                context.getMatrices().scale(1.3f, 1.3f, 1.0f); // Увеличиваем на 30%
                context.drawText(mc.textRenderer, icon, 
                    -iconWidth / 2, 
                    -4, 
                    isHovered() ? COLOR_ACCENT_FIXED : 0xFFCCCCCC, false); // Ярче цвет
                context.getMatrices().pop();
            }
        };
        addDrawableChild(particleSettingsButton);
        
        // === КНОПКИ ===
        
        // Красивая кнопка "Назад" с современным дизайном
        backButton = new net.minecraft.client.gui.widget.ButtonWidget(
            20, 20, 100, 30,
            Text.literal("← Назад"),
            button -> {
                SoundManager.playClickSound();
                this.client.setScreen(parent);
            },
            (button) -> Text.literal("Вернуться назад")
        ) {
            @Override
            public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
                int x = getX();
                int y = getY();
                int width = getWidth();
                int height = getHeight();
                
                // Цвет кнопки с эффектом hover
                int bgColor = isHovered() ? COLOR_BG_HOVER() : COLOR_BG_CARD();
                
                // Закругленная кнопка
                RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
                RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, isHovered() ? COLOR_ACCENT_FIXED : COLOR_BORDER());
                
                // Текст с тенью
                var mc = net.minecraft.client.MinecraftClient.getInstance();
                String text = getMessage().getString();
                int textWidth = mc.textRenderer.getWidth(text);
                context.drawText(mc.textRenderer, text, 
                    x + (width - textWidth) / 2, 
                    y + (height - 8) / 2, 
                    isHovered() ? COLOR_ACCENT_FIXED : COLOR_TEXT_PRIMARY, false);
            }
        };
        addDrawableChild(backButton);
        
        // Стильная кнопка "Сохранить"
        int saveButtonX = this.width / 2 - 75;
        int saveButtonY = this.height - 60;
        
        saveButton = new net.minecraft.client.gui.widget.ButtonWidget(
            saveButtonX, saveButtonY, 150, 35,
            Text.literal("Сохранить"),
            button -> {
                SoundManager.playClickSound();
                HudManager.getInstance().saveConfig();
            },
            (button) -> Text.literal("Сохранить настройки")
        ) {
            @Override
            public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
                int x = getX();
                int y = getY();
                int width = getWidth();
                int height = getHeight();
                
                // Цвет кнопки с эффектом hover
                int bgColor = isHovered() ? 0xFF2E7D32 : COLOR_SUCCESS_FIXED;
                
                // Закругленная кнопка
                RenderUtils.fillRounded(context, x, y, width, height, 10, bgColor);
                
                // Свечение при наведении
                if (isHovered()) {
                    // Внешнее свечение
                    RenderUtils.fillRounded(context, x - 2, y - 2, width + 4, height + 4, 12, 0x30FFFFFF);
                }
                
                // Текст с тенью
                var mc = net.minecraft.client.MinecraftClient.getInstance();
                String text = getMessage().getString();
                int textWidth = mc.textRenderer.getWidth(text);
                context.drawText(mc.textRenderer, text, 
                    x + (width - textWidth) / 2, 
                    y + (height - 8) / 2, 
                    COLOR_TEXT_PRIMARY, true);
            }
        };
        addDrawableChild(saveButton);
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Градиентный фон
        context.fillGradient(0, 0, this.width, this.height, COLOR_BG_CARD(), COLOR_BG_DARKEST());
        
        // ФОНОВЫЕ ЧАСТИЦЫ (рендерим ПОСЛЕ фона, но ДО UI элементов)
        context.getMatrices().push();
        com.whiterise.adminpanel.background.ParticleSystem.getInstance().render(context, delta, mouseX, mouseY);
        context.getMatrices().pop();
        
        // Заголовок
        String title = "Настройки интерфейса";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, 20, COLOR_TEXT_PRIMARY, true);
        
        // Подзаголовок
        String subtitle = "Настройки ватермарки (HUD Bar)";
        int subtitleWidth = this.textRenderer.getWidth(subtitle);
        context.drawText(this.textRenderer, subtitle, (this.width - subtitleWidth) / 2, 35, COLOR_TEXT_SECONDARY, false);
        
        // Основная панель настроек
        renderMainPanel(context, mouseX, mouseY);
        
        // Предпросмотр
        renderPreview(context, mouseX, mouseY);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рендерит основную панель с настройками в две колонки
     */
    private void renderMainPanel(DrawContext context, int mouseX, int mouseY) {
        int panelX = this.width / 2 - 250;
        int panelY = 60;
        int panelWidth = 500;
        int panelHeight = 220;
        
        // Фон панели
        RenderUtils.fillRounded(context, panelX, panelY, panelWidth, panelHeight, 12, COLOR_BG_CARD());
        RenderUtils.drawRoundedBorder(context, panelX, panelY, panelWidth, panelHeight, 12, COLOR_BORDER());
        
        // Включаем scissor test
        enableScissor(panelX, panelY, panelWidth, panelHeight);
        
        int centerX = panelX + panelWidth / 2;
        int leftColX = panelX + 40;
        int rightColX = centerX + 40;
        
        // Получаем unifiedBar для отображения значений
        var unifiedBar = HudManager.getInstance().getUnifiedBar();
        
        // === ЛЕВАЯ КОЛОНКА ===
        int leftY = panelY + 30; // Начальная позиция
        
        // Метка "Масштаб" НАД ползунком масштаба (вплотную)
        context.drawText(this.textRenderer, "Масштаб", leftColX, leftY, COLOR_TEXT_SECONDARY, false);
        
        // Значение масштаба НАД ползунком справа
        String scaleValue = String.format("%.2f", unifiedBar.getScale());
        context.drawText(this.textRenderer, scaleValue, leftColX + 160, leftY, COLOR_TEXT_PRIMARY, false);
        
        // Отступ до следующей секции (должен соответствовать init())
        // В init: leftY += 15 (до первого ползунка) + 50 (после первого ползунка) = 65
        leftY += 65;
        
        // Метка "Прозрачность" НАД ползунком прозрачности (вплотную)
        context.drawText(this.textRenderer, "Прозрачность", leftColX, leftY, COLOR_TEXT_SECONDARY, false);
        
        // Значение прозрачности НАД ползунком справа
        String opacityValue = String.format("%.0f%%", unifiedBar.getOpacity() * 100);
        context.drawText(this.textRenderer, opacityValue, leftColX + 160, leftY, COLOR_TEXT_PRIMARY, false);
        
        // === ПРАВАЯ КОЛОНКА ===
        int rightY = panelY + 15; // Поднимаем весь текст на 5px выше (было 20)
        
        // Метка "Игрок" - точно на уровне переключателя
        context.drawText(this.textRenderer, "Игрок", rightColX, rightY + 4, COLOR_TEXT_SECONDARY, false); // Было +8, теперь +4 (на 4px выше)
        rightY += 35;
        
        // Метка "FPS"
        context.drawText(this.textRenderer, "FPS", rightColX, rightY + 4, COLOR_TEXT_SECONDARY, false);
        rightY += 35;
        
        // Метка "Пинг"
        context.drawText(this.textRenderer, "Пинг", rightColX, rightY + 4, COLOR_TEXT_SECONDARY, false);
        rightY += 35;
        
        // Метка "Время сессии"
        context.drawText(this.textRenderer, "Время сессии", rightColX, rightY + 4, COLOR_TEXT_SECONDARY, false);
        rightY += 35;
        
        // Метка "Наказания"
        context.drawText(this.textRenderer, "Наказания", rightColX, rightY + 4, COLOR_TEXT_SECONDARY, false);
        rightY += 35;
        
        // === РАЗДЕЛИТЕЛЬ ===
        rightY += 5; // Уменьшаем отступ чтобы поднять переключатель "Частицы" на 5px
        
        // Метка "Частицы" - точно на уровне переключателя
        context.drawText(this.textRenderer, "Частицы", rightColX, rightY + 4, COLOR_TEXT_SECONDARY, false);
        
        // Разделительная линия между колонками (более выраженная)
        int lineWidth = 2;
        int lineX = centerX - lineWidth / 2;
        context.fill(lineX, panelY + 20, lineX + lineWidth, panelY + panelHeight - 20, 0x66FFFFFF);
        
        // Дополнительная тень для глубины
        context.fill(lineX + lineWidth, panelY + 20, lineX + lineWidth + 1, panelY + panelHeight - 20, 0x20000000);
        
        // Отключаем scissor test после рендеринга содержимого панели
        disableScissor();
    }
    
    /**
     * Рендерит предпросмотр ватермарки
     */
    private void renderPreview(DrawContext context, int mouseX, int mouseY) {
        int previewWidth = 500;
        int previewHeight = 100;
        int previewX = (this.width - previewWidth) / 2; // Блок в центре
        int previewY = 300; // Вернули как было
        
        // Фон предпросмотра с более темным цветом
        RenderUtils.fillRounded(context, previewX, previewY, previewWidth, previewHeight, 12, 0xCC1A1A1A);
        RenderUtils.drawRoundedBorder(context, previewX, previewY, previewWidth, previewHeight, 12, 0xFF444444);
        
        // Заголовок
        context.drawText(this.textRenderer, "Предпросмотр:", previewX + 15, previewY + 10, COLOR_TEXT_MUTED, false);
        
        // Рендерим настоящую ватермарку
        var unifiedBar = HudManager.getInstance().getUnifiedBar();
        
        // Включаем режим предпросмотра (отключает scissor)
        unifiedBar.setPreviewMode(true);
        
        context.getMatrices().push();
        
        // Центрируем ватермарку в области предпросмотра, но смещаем левее на 85px и выше на 20px
        int hudX = previewX + (previewWidth / 2) - 100 - 85; // Смещение левее на 85px (было 70px, +15px)
        int hudY = previewY + 45 - 20; // Смещение выше на 20px
        
        context.getMatrices().translate(hudX, hudY, 0);
        
        // Применяем текущий масштаб для предпросмотра
        float currentScale = unifiedBar.getScale();
        context.getMatrices().scale(currentScale, currentScale, 1.0f);
        
        // Рендерим HUD Bar БЕЗ scissor (для предпросмотра)
        // Передаем фиктивные размеры экрана чтобы избежать проблем с scissor
        unifiedBar.render(context, 10000, 10000, 0);
        
        context.getMatrices().pop();
        
        // Восстанавливаем режим
        unifiedBar.setPreviewMode(false);
        
        // Дополнительная информация под предпросмотром
        String info = "Живой предпросмотр - изменения применяются мгновенно";
        int infoWidth = this.textRenderer.getWidth(info);
        context.drawText(this.textRenderer, info, 
            previewX + (previewWidth - infoWidth) / 2, 
            previewY + previewHeight - 15, 
            COLOR_TEXT_MUTED, false);
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    /**
     * Проверяет, находится ли точка в прямоугольнике
     */
    private boolean isInBounds(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
    
    /**
     * Интерполирует между двумя цветами
     */
    private int interpolateColor(int color1, int color2, float factor) {
        factor = Math.max(0, Math.min(1, factor));
        
        int a1 = (color1 >> 24) & 0xFF;
        int r1 = (color1 >> 16) & 0xFF;
        int g1 = (color1 >> 8) & 0xFF;
        int b1 = color1 & 0xFF;
        
        int a2 = (color2 >> 24) & 0xFF;
        int r2 = (color2 >> 16) & 0xFF;
        int g2 = (color2 >> 8) & 0xFF;
        int b2 = color2 & 0xFF;
        
        int a = (int)(a1 + (a2 - a1) * factor);
        int r = (int)(r1 + (r2 - r1) * factor);
        int g = (int)(g1 + (g2 - g1) * factor);
        int b = (int)(b1 + (b2 - b1) * factor);
        
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    /**
     * Включает scissor test для обрезки области рендеринга
     */
    private void enableScissor(int x, int y, int width, int height) {
        double scale = this.client.getWindow().getScaleFactor();
        int scaledX = (int)(x * scale);
        int scaledY = (int)(this.client.getWindow().getHeight() - (y + height) * scale);
        int scaledWidth = (int)(width * scale);
        int scaledHeight = (int)(height * scale);
        
        com.mojang.blaze3d.systems.RenderSystem.enableScissor(scaledX, scaledY, scaledWidth, scaledHeight);
    }
    
    /**
     * Отключает scissor test
     */
    private void disableScissor() {
        com.mojang.blaze3d.systems.RenderSystem.disableScissor();
    }
    
    @Override
    public void close() {
        HudManager.getInstance().saveConfig();
        super.close();
    }
}

