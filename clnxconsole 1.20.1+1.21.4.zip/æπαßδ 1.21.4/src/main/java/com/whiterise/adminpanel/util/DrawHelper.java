package com.whiterise.adminpanel.util;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.render.builders.states.QuadColorState;
import com.whiterise.adminpanel.render.builders.states.QuadRadiusState;
import com.whiterise.adminpanel.render.builders.states.SizeState;
import com.whiterise.adminpanel.render.renderers.impl.BuiltRectangle;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public class DrawHelper {
   public static final Color TEXT_PRIMARY = new Color(248, 250, 252);
   private static final Map<Integer, Double> toggleAnimations = new HashMap<>();

   /**
    * Рисует скругленный прямоугольник используя GPU-ускоренную систему из spacemoderation
    */
   public static void drawRoundedRect(DrawContext context, float x, float y, float width, float height, float radius, Color color) {
      Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
      BuiltRectangle rect = new BuiltRectangle(
         new SizeState(width, height), 
         new QuadRadiusState(radius, radius, radius, radius), 
         new QuadColorState(color, color, color, color), 
         0.5F
      );
      rect.render(matrix, x, y, 0.0F);
   }

   /**
    * Рисует скругленный прямоугольник с int цветом
    */
   public static void drawRoundedRect(DrawContext context, float x, float y, float width, float height, float radius, int color) {
      Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
      BuiltRectangle rect = new BuiltRectangle(
         new SizeState(width, height), 
         new QuadRadiusState(radius, radius, radius, radius), 
         new QuadColorState(color, color, color, color), 
         0.5F
      );
      rect.render(matrix, x, y, 0.0F);
   }

   /**
    * Рисует скругленный прямоугольник с int параметрами (для совместимости с RenderUtils)
    */
   public static void fillRounded(DrawContext context, int x, int y, int width, int height, int radius, int color) {
      Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
      BuiltRectangle rect = new BuiltRectangle(
         new SizeState(width, height), 
         new QuadRadiusState(radius, radius, radius, radius), 
         new QuadColorState(color, color, color, color), 
         0.5F
      );
      rect.render(matrix, x, y, 0.0F);
   }

   /**
    * Рисует скругленный прямоугольник с разными радиусами углов
    */
   public static void drawRoundedRect(DrawContext context, float x, float y, float width, float height, float radius1, float radius2, float radius3, float radius4, int color) {
      Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
      BuiltRectangle rect = new BuiltRectangle(
         new SizeState(width, height), 
         new QuadRadiusState(radius1, radius2, radius3, radius4), 
         new QuadColorState(color, color, color, color), 
         0.5F
      );
      rect.render(matrix, x, y, 0.0F);
   }

   /**
    * Рисует тень для скругленного прямоугольника
    */
   public static void drawRoundedShadow(DrawContext context, float x, float y, float width, float height, float radius, int shadowColor) {
      drawRoundedRect(context, x + 2, y + 2, width, height, radius, shadowColor);
   }

   // Остальные методы для совместимости
   public static void drawToggle(DrawContext context, double x, double y, double width, double height, boolean enabled, boolean isHovered, boolean skipAnimation) {
      // Реализация toggle с использованием новой системы
      int id = (int)(x * 31.0D + y * 17.0D + width * 13.0D + height);
      double anim = toggleAnimations.getOrDefault(id, enabled ? 1.0D : 0.0D);
      double target = enabled ? 1.0D : 0.0D;
      
      if (!skipAnimation) {
         anim = animate(anim, target, 0.2D);
      } else {
         anim = target;
      }

      double easedAnim = easeInOut(anim);
      toggleAnimations.put(id, anim);
      
      Color inactiveColor = new Color(71, 85, 105);
      Color activeColor = ColorManager.getC5();
      Color trackColor = blendColors(inactiveColor, activeColor, easedAnim);
      
      if (isHovered) {
         int r = Math.min(255, (int)((float)trackColor.getRed() * 1.15F));
         int g = Math.min(255, (int)((float)trackColor.getGreen() * 1.15F));
         int b = Math.min(255, (int)((float)trackColor.getBlue() * 1.15F));
         trackColor = new Color(r, g, b, trackColor.getAlpha());
      }

      double trackRadius = height * 0.4D;
      double thumbSize = height - 4.0D;
      double thumbRadius = thumbSize * 0.4D;
      double thumbX = lerp(x + 2.0D, x + width - thumbSize - 2.0D, easedAnim);
      
      drawRoundedRect(context, (float)x, (float)y, (float)width, (float)height, (float)trackRadius, trackColor);
      drawRoundedRect(context, (float)thumbX, (float)(y + 2.0D), (float)thumbSize, (float)thumbSize, (float)thumbRadius, TEXT_PRIMARY);
   }

   public static void drawSlider(DrawContext context, double x, double y, double width, double height, double progress, Color trackColor, Color fillColor, Color thumbColor) {
      float trackRadius = (float)(height * 0.4D);
      float thumbSize = (float)(height * 2.0D);
      float thumbRadius = thumbSize * 0.4F;
      float thumbX = (float)(x + (width - (double)thumbSize) * progress);
      
      drawRoundedRect(context, (float)x, (float)y, (float)width, (float)height, trackRadius, trackColor);
      
      if (progress > 0.0D) {
         drawRoundedRect(context, (float)x, (float)y, (float)(width * progress), (float)height, trackRadius, fillColor);
      }

      drawRoundedRect(context, thumbX, (float)(y - ((double)thumbSize - height) / 2.0D), thumbSize, thumbSize, thumbRadius, thumbColor);
   }

   // Утилиты для анимации
   private static Color blendColors(Color c1, Color c2, double a) {
      a = clamp(a, 0.0D, 1.0D);
      int r = (int)((double)c1.getRed() + (double)(c2.getRed() - c1.getRed()) * a);
      int g = (int)((double)c1.getGreen() + (double)(c2.getGreen() - c1.getGreen()) * a);
      int b = (int)((double)c1.getBlue() + (double)(c2.getBlue() - c1.getBlue()) * a);
      int alpha = (int)((double)c1.getAlpha() + (double)(c2.getAlpha() - c1.getAlpha()) * a);
      return new Color(r, g, b, alpha);
   }

   private static double easeInOut(double t) {
      t = clamp(t, 0.0D, 1.0D);
      return t < 0.5D ? 4.0D * t * t * t : 1.0D - Math.pow(-2.0D * t + 2.0D, 3.0D) / 2.0D;
   }

   private static double animate(double current, double target, double speed) {
      return current + (target - current) * speed;
   }

   private static double lerp(double start, double end, double t) {
      return start + (end - start) * t;
   }

   private static double clamp(double value, double min, double max) {
      return Math.max(min, Math.min(max, value));
   }

   /**
    * Очищает кеш анимаций (вызывать при закрытии экрана)
    */
   public static void clearAnimationCache() {
      toggleAnimations.clear();
   }
}
