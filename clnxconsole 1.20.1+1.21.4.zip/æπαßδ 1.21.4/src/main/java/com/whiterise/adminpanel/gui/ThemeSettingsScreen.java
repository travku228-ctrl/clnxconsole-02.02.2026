package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.util.DrawHelper;
import com.whiterise.adminpanel.util.AnimationUtil;
import com.whiterise.adminpanel.sound.SoundManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * Экран настроек темы - демонстрация новых возможностей
 * Улучшенная версия с анимациями и красивым дизайном
 */
public class ThemeSettingsScreen extends Screen {
    private final Screen parent;
    private static final int PANEL_WIDTH = 900;
    private static final int PANEL_HEIGHT = 600;
    
    // Анимации для карточек тем
    private final Map<String, Float> hoverAnimations = new HashMap<>();
    private String selectedScheme = null;
    
    public ThemeSettingsScreen(Screen parent) {
        super(Text.literal("Настройки темы"));
        this.parent = parent;
        this.selectedScheme = ColorManager.getCurrentScheme();
        
        // Инициализируем анимации
        for (String scheme : ColorManager.getAvailableSchemes()) {
            hoverAnimations.put(scheme, 0.0f);
        }
    }
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fill()
    }
    
    @Override
    protected void init() {
        super.init();
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Затемненный фон
        context.fill(0, 0, width, height, 0xCC000000);
        
        int centerX = width / 2;
        int centerY = height / 2;
        int panelX = centerX - PANEL_WIDTH / 2;
        int panelY = centerY - PANEL_HEIGHT / 2;
        
        // Панель с использованием ColorManager
        Color bgColor = ColorManager.getC2();
        DrawHelper.drawRoundedRect(context, panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, 16, bgColor);
        
        // Заголовок
        Color headerColor = ColorManager.getC5();
        DrawHelper.drawRoundedRect(context, panelX, panelY, PANEL_WIDTH, 60, 16, headerColor);
        
        // Текст заголовка с иконкой
        String titleText = "🎨 Выбор цветовой темы";
        context.drawCenteredTextWithShadow(textRenderer, titleText, centerX, panelY + 22, 0xFFFFFFFF);
        
        // Текущая схема
        String currentScheme = "Текущая: " + capitalize(ColorManager.getCurrentScheme());
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(currentScheme), 
            centerX, panelY + 75, ColorManager.getC4().getRGB());
        
        // Карточки тем (4x3 сетка - 4 в ряд)
        String[] schemes = ColorManager.getAvailableSchemes();
        int cardWidth = 200;  // Уменьшено для 4 карточек в ряд
        int cardHeight = 90;  // Немного уменьшено
        int cardSpacing = 15;
        int cardsPerRow = 4;  // Теперь 4 в ряд
        
        int totalCardsWidth = cardWidth * cardsPerRow + cardSpacing * (cardsPerRow - 1);
        int startX = panelX + (PANEL_WIDTH - totalCardsWidth) / 2;
        int startY = panelY + 100;  // Поднято выше (было 110)
        
        for (int i = 0; i < schemes.length; i++) {
            int row = i / cardsPerRow;
            int col = i % cardsPerRow;
            
            int cardX = startX + col * (cardWidth + cardSpacing);
            int cardY = startY + row * (cardHeight + cardSpacing);
            
            renderThemeCard(context, cardX, cardY, cardWidth, cardHeight, schemes[i], mouseX, mouseY, delta);
        }
        
        // Кнопка "Назад" (поднята ещё выше)
        int buttonWidth = 120;
        int buttonHeight = 35;
        int buttonX = centerX - buttonWidth / 2;
        int buttonY = panelY + PANEL_HEIGHT - 90;  // Поднято на 30px выше (было -60)
        
        boolean isBackHovered = mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                               mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        
        Color buttonColor = isBackHovered ? ColorManager.getC5() : ColorManager.getC3();
        DrawHelper.drawRoundedRect(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonColor);
        
        String backText = "← Назад";
        int textWidth = textRenderer.getWidth(backText);
        context.drawCenteredTextWithShadow(textRenderer, backText, 
            buttonX + buttonWidth / 2, buttonY + (buttonHeight - 8) / 2, 0xFFFFFFFF);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рендерит карточку темы с анимацией
     */
    private void renderThemeCard(DrawContext context, int x, int y, int width, int height, 
                                 String schemeName, int mouseX, int mouseY, float delta) {
        boolean isHovered = mouseX >= x && mouseX <= x + width && 
                           mouseY >= y && mouseY <= y + height;
        boolean isSelected = schemeName.equals(selectedScheme);
        
        // Обновляем анимацию
        float currentAnim = hoverAnimations.get(schemeName);
        float targetAnim = isHovered ? 1.0f : 0.0f;
        float newAnim = AnimationUtil.animate(currentAnim, targetAnim, 0.15f);
        hoverAnimations.put(schemeName, newAnim);
        
        // Временно устанавливаем схему для получения цветов
        String originalScheme = ColorManager.getCurrentScheme();
        ColorManager.setScheme(schemeName);
        
        // Фон карточки с анимацией
        Color cardBg = ColorManager.getC3();
        if (isSelected) {
            cardBg = ColorManager.getC5();
        } else if (newAnim > 0) {
            cardBg = ColorManager.blendColors(ColorManager.getC3(), ColorManager.getC5(), newAnim);
        }
        
        DrawHelper.drawRoundedRect(context, x, y, width, height, 12, cardBg);
        
        // Граница
        if (isSelected) {
            Color borderColor = ColorManager.getC7();
            com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, x, y, width, height, 12, borderColor.getRGB());
        }
        
        // Название темы
        String displayName = capitalize(schemeName);
        if (isSelected) {
            displayName = "✓ " + displayName;
        }
        context.drawText(textRenderer, displayName, x + 12, y + 12, 
                        ColorManager.getC8().getRGB(), isSelected);
        
        // Превью цветов (8 маленьких квадратиков)
        int colorBoxSize = 18;  // Немного меньше
        int colorBoxSpacing = 3;
        int colorsStartX = x + 10;
        int colorsStartY = y + 32;
        
        Color[] colors = {
            ColorManager.getC1(), ColorManager.getC2(), ColorManager.getC3(), ColorManager.getC4(),
            ColorManager.getC5(), ColorManager.getC6(), ColorManager.getC7(), ColorManager.getC8()
        };
        
        for (int i = 0; i < 8; i++) {
            int boxX = colorsStartX + (i % 4) * (colorBoxSize + colorBoxSpacing);
            int boxY = colorsStartY + (i / 4) * (colorBoxSize + colorBoxSpacing);
            
            DrawHelper.drawRoundedRect(context, boxX, boxY, colorBoxSize, colorBoxSize, 4, colors[i]);
        }
        
        // Описание
        String description = getSchemeDescription(schemeName);
        context.drawText(textRenderer, description, x + 12, y + height - 20, 
                        ColorManager.getC4().getRGB(), false);
        
        // Восстанавливаем оригинальную схему
        ColorManager.setScheme(originalScheme);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        
        int centerX = width / 2;
        int centerY = height / 2;
        int panelX = centerX - PANEL_WIDTH / 2;
        int panelY = centerY - PANEL_HEIGHT / 2;
        
        // Проверка клика по кнопке "Назад"
        int buttonWidth = 120;
        int buttonHeight = 35;
        int buttonX = centerX - buttonWidth / 2;
        int buttonY = panelY + PANEL_HEIGHT - 90;  // Обновлено: поднято на 30px выше (было -60)
        
        if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            close();
            return true;
        }
        
        // Проверка клика по карточкам тем (ОБНОВЛЕНО: 4 в ряд)
        String[] schemes = ColorManager.getAvailableSchemes();
        int cardWidth = 200;  // Было 270
        int cardHeight = 90;  // Было 110
        int cardSpacing = 15;
        int cardsPerRow = 4;  // Было 3
        
        int totalCardsWidth = cardWidth * cardsPerRow + cardSpacing * (cardsPerRow - 1);
        int startX = panelX + (PANEL_WIDTH - totalCardsWidth) / 2;
        int startY = panelY + 100;  // Было 110
        
        for (int i = 0; i < schemes.length; i++) {
            int row = i / cardsPerRow;
            int col = i % cardsPerRow;
            
            int cardX = startX + col * (cardWidth + cardSpacing);
            int cardY = startY + row * (cardHeight + cardSpacing);
            
            if (mouseX >= cardX && mouseX <= cardX + cardWidth && 
                mouseY >= cardY && mouseY <= cardY + cardHeight) {
                SoundManager.playClickSound();
                ColorManager.setScheme(schemes[i]);
                selectedScheme = schemes[i];
                return true;
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    @Override
    public void close() {
        if (client != null) {
            client.setScreen(parent);
        }
    }
    
    @Override
    public boolean shouldPause() {
        return false;
    }
    
    /**
     * Возвращает описание цветовой схемы
     */
    private String getSchemeDescription(String scheme) {
        return switch (scheme.toLowerCase()) {
            case "purple" -> "Классическая фиолетовая";
            case "blue" -> "Спокойная синяя";
            case "red" -> "Энергичная красная";
            case "pink" -> "Нежная розовая";
            case "orange" -> "Теплая оранжевая";
            case "gray" -> "Нейтральная серая";
            case "cyan" -> "Свежая бирюзовая";
            case "brown" -> "Уютная коричневая";
            case "lime" -> "Яркая лаймовая";
            case "gold" -> "Роскошная золотая";
            case "white" -> "Минималистичная белая";
            default -> "Цветовая схема";
        };
    }
    
    /**
     * Делает первую букву заглавной
     */
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
