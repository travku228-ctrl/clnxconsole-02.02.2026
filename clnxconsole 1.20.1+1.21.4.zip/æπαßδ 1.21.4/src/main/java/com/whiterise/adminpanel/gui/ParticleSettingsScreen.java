package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.hud.HudConfig;
import com.whiterise.adminpanel.hud.HudManager;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Экран настроек фоновых частиц
 */
public class ParticleSettingsScreen extends Screen {
    private final Screen parent;
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fillGradient()
    }
    
    // Цвета - современная палитра
    private static final int COLOR_BG_DARKEST = 0xFF0F141C;
    private static final int COLOR_BG_DARK = 0xFF161C26;
    private static final int COLOR_BG_CARD = 0xFF1A2332;
    private static final int COLOR_BG_HOVER = 0xFF1F2938;
    private static final int COLOR_ACCENT = 0xFF00D9FF;
    private static final int COLOR_SUCCESS = 0xFF10b981;
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;
    private static final int COLOR_BORDER = 0xFF2a3441;
    
    // Виджеты
    private ModernSliderWidget countSlider;
    private ModernSliderWidget speedSlider;
    private net.minecraft.client.gui.widget.ButtonWidget backButton;
    private net.minecraft.client.gui.widget.ButtonWidget applyButton;
    
    public ParticleSettingsScreen(Screen parent) {
        super(Text.literal("Настройки частиц"));
        this.parent = parent;
    }
    
    @Override
    protected void init() {
        int panelX = this.width / 2 - 200;
        int panelY = 80;
        int sliderX = panelX + 40;
        
        // Слайдер количества частиц (10-100)
        int sliderY = panelY + 60;
        countSlider = new ModernSliderWidget(
            sliderX, sliderY, 320, 6,
            10, 100, HudConfig.getParticleCount(), 1,
            value -> {
                // Обновление происходит при нажатии "Применить"
            }
        );
        addDrawableChild(countSlider);
        
        // Слайдер скорости частиц (0.1-3.0)
        sliderY += 80;
        speedSlider = new ModernSliderWidget(
            sliderX, sliderY, 320, 6,
            0.1, 3.0, HudConfig.getParticleSpeed(), 0.1,
            value -> {
                // Обновление происходит при нажатии "Применить"
            }
        );
        addDrawableChild(speedSlider);
        
        // Кнопка "Назад"
        backButton = new net.minecraft.client.gui.widget.ButtonWidget.Builder(
            Text.literal("← Назад"),
            button -> {
                SoundManager.playClickSound();
                this.client.setScreen(parent);
            }
        )
        .position(20, 20)
        .size(100, 30)
        .build();
        addDrawableChild(backButton);
        
        // Кнопка "Применить"
        int applyButtonX = this.width / 2 - 75;
        int applyButtonY = this.height - 60;
        
        applyButton = new net.minecraft.client.gui.widget.ButtonWidget(
            applyButtonX, applyButtonY, 150, 35,
            Text.literal("Применить"),
            button -> {
                SoundManager.playClickSound();
                
                // Применяем настройки
                HudConfig.setParticleCount((int) countSlider.getCurrentValue());
                HudConfig.setParticleSpeed((float) speedSlider.getCurrentValue());
                HudManager.getInstance().saveConfig();
                
                // Пересоздаём частицы с новыми настройками
                MinecraftClient client = MinecraftClient.getInstance();
                com.whiterise.adminpanel.background.ParticleSystem.getInstance().reinitialize(
                    client.getWindow().getScaledWidth(),
                    client.getWindow().getScaledHeight()
                );
            },
            (button) -> Text.literal("Применить настройки")
        ) {
            @Override
            public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
                int x = getX();
                int y = getY();
                int width = getWidth();
                int height = getHeight();
                
                // Цвет кнопки с эффектом hover
                int bgColor = isHovered() ? 0xFF2E7D32 : COLOR_SUCCESS;
                
                // Закругленная кнопка
                RenderUtils.fillRounded(context, x, y, width, height, 10, bgColor);
                
                // Свечение при наведении
                if (isHovered()) {
                    RenderUtils.fillRounded(context, x - 2, y - 2, width + 4, height + 4, 12, 0x30FFFFFF);
                }
                
                // Текст с тенью
                var mc = MinecraftClient.getInstance();
                String text = getMessage().getString();
                int textWidth = mc.textRenderer.getWidth(text);
                context.drawText(mc.textRenderer, text, 
                    x + (width - textWidth) / 2, 
                    y + (height - 8) / 2, 
                    COLOR_TEXT_PRIMARY, true);
            }
        };
        addDrawableChild(applyButton);
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Градиентный фон
        context.fillGradient(0, 0, this.width, this.height, 0xFF1a2332, 0xFF191a1c);
        
        // ФОНОВЫЕ ЧАСТИЦЫ (рендерим ПОСЛЕ фона, но ДО UI элементов)
        context.getMatrices().push();
        com.whiterise.adminpanel.background.ParticleSystem.getInstance().render(context, delta, mouseX, mouseY);
        context.getMatrices().pop();
        
        // Заголовок
        String title = "Настройки частиц";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, 20, COLOR_TEXT_PRIMARY, true);
        
        // Подзаголовок
        String subtitle = "Настройка фоновых эффектов в меню";
        int subtitleWidth = this.textRenderer.getWidth(subtitle);
        context.drawText(this.textRenderer, subtitle, (this.width - subtitleWidth) / 2, 35, COLOR_TEXT_SECONDARY, false);
        
        // Основная панель настроек
        renderMainPanel(context, mouseX, mouseY);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рендерит основную панель с настройками
     */
    private void renderMainPanel(DrawContext context, int mouseX, int mouseY) {
        int panelX = this.width / 2 - 200;
        int panelY = 80;
        int panelWidth = 400;
        int panelHeight = 200;
        
        // Фон панели
        RenderUtils.fillRounded(context, panelX, panelY, panelWidth, panelHeight, 12, COLOR_BG_CARD);
        RenderUtils.drawRoundedBorder(context, panelX, panelY, panelWidth, panelHeight, 12, COLOR_BORDER);
        
        int leftX = panelX + 40;
        int currentY = panelY + 30;
        
        // === КОЛИЧЕСТВО ЧАСТИЦ ===
        context.drawText(this.textRenderer, "Количество частиц", leftX, currentY, COLOR_TEXT_SECONDARY, false);
        
        // Значение над ползунком
        String countValue = String.format("%d", (int) countSlider.getCurrentValue());
        int countValueWidth = this.textRenderer.getWidth(countValue);
        context.drawText(this.textRenderer, countValue, leftX + 160 - countValueWidth / 2, currentY + 15, COLOR_TEXT_PRIMARY, false);
        
        // Описание
        String countDesc = "Диапазон: 10-100 частиц";
        context.drawText(this.textRenderer, countDesc, leftX, currentY + 45, COLOR_TEXT_MUTED, false);
        
        currentY += 80;
        
        // === СКОРОСТЬ ЧАСТИЦ ===
        context.drawText(this.textRenderer, "Скорость движения", leftX, currentY, COLOR_TEXT_SECONDARY, false);
        
        // Значение над ползунком
        String speedValue = String.format("%.1fx", speedSlider.getCurrentValue());
        int speedValueWidth = this.textRenderer.getWidth(speedValue);
        context.drawText(this.textRenderer, speedValue, leftX + 160 - speedValueWidth / 2, currentY + 15, COLOR_TEXT_PRIMARY, false);
        
        // Описание
        String speedDesc = "Диапазон: 0.1x-3.0x (множитель)";
        context.drawText(this.textRenderer, speedDesc, leftX, currentY + 45, COLOR_TEXT_MUTED, false);
    }
    
    @Override
    public void close() {
        super.close();
    }
}
