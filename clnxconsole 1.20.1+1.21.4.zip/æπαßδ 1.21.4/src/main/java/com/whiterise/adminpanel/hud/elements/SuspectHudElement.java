package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import com.whiterise.adminpanel.manager.AntiCheatSessionManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Подозреваемый
 */
public class SuspectHudElement extends HudElement {
    private static final int COLOR_BG = 0xCC1A2332;
    private static final int COLOR_ACCENT = 0xFF9333ea; // Фиолетовый
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    
    public SuspectHudElement() {
        super("suspect", "Подозреваемый");
        setPosition(HudPosition.TOP_LEFT);
        setOffsetY(10);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        // Проверяем есть ли активная проверка
        if (!AntiCheatSessionManager.hasActiveSession()) {
            return;
        }
        
        var session = AntiCheatSessionManager.getActiveSession();
        String suspect = session.getPlayerName();
        
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Фон
        int width = getWidth();
        int height = getHeight();
        int bgColor = applyOpacity(COLOR_BG);
        
        RenderUtils.fillRounded(context, 0, 0, width, height, 6, bgColor);
        
        // Иконка глаза
        context.drawText(client.textRenderer, "👁", 6, 6, COLOR_ACCENT, false);
        
        // Текст
        context.drawText(client.textRenderer, "Подозреваемый:", 24, 6, COLOR_TEXT, false);
        context.drawText(client.textRenderer, suspect, 24, 18, COLOR_ACCENT, true);
    }
    
    @Override
    public int getWidth() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!AntiCheatSessionManager.hasActiveSession()) {
            return 150;
        }
        var session = AntiCheatSessionManager.getActiveSession();
        int textWidth = client.textRenderer.getWidth(session.getPlayerName());
        return Math.max(150, textWidth + 30);
    }
    
    @Override
    public int getHeight() {
        return 32;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
