package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import com.whiterise.adminpanel.manager.AntiCheatSessionManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Таймер проверки
 */
public class CheckTimerHudElement extends HudElement {
    private static final int COLOR_BG = 0xCC1A2332;
    private static final int COLOR_ACCENT = 0xFF10b981; // Зеленый
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    
    public CheckTimerHudElement() {
        super("check_timer", "Время проверки");
        setPosition(HudPosition.TOP_LEFT);
        setOffsetY(90);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        // Проверяем есть ли активная проверка
        if (!AntiCheatSessionManager.hasActiveSession()) {
            return;
        }
        
        var session = AntiCheatSessionManager.getActiveSession();
        String timer = session.getFormattedRemainingTime();
        
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Фон
        int width = getWidth();
        int height = getHeight();
        int bgColor = applyOpacity(COLOR_BG);
        
        RenderUtils.fillRounded(context, 0, 0, width, height, 6, bgColor);
        
        // Иконка
        context.drawText(client.textRenderer, "⏱", 6, 6, COLOR_ACCENT, false);
        
        // Текст
        context.drawText(client.textRenderer, "Начало проверки:", 24, 6, COLOR_TEXT, false);
        context.drawText(client.textRenderer, timer, 24, 18, COLOR_ACCENT, false);
    }
    
    @Override
    public int getWidth() {
        return 160;
    }
    
    @Override
    public int getHeight() {
        return 32;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
