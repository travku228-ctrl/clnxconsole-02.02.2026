package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.AdminPanelClient;
import com.whiterise.adminpanel.data.ChatLogEntry;
import com.whiterise.adminpanel.data.PunishmentRule;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.CustomFontRenderer;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.render.RenderLayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.render.RenderLayer;

/**
 * Экран консоли для удаленных наказаний
 * Позволяет выдавать наказания игрокам (онлайн/оффлайн) через команды
 */
public class ConsoleScreen extends Screen {
    private final Screen parent;
    
    // Цвета (из AdminPanelScreen) - ЗАМЕНЕНЫ НА ColorManager
    // Эти методы возвращают цвета из текущей темы
    private int COLOR_BG_DARKEST() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_DARK() { return ColorManager.getC2().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BG_HOVER() { return ColorManager.getC4().getRGB(); }
    private int COLOR_ACCENT() { return ColorManager.getC5().getRGB(); }
    // ФИКСИРОВАННЫЕ цвета для кнопок наказаний (не зависят от темы)
    private static final int COLOR_SUCCESS_FIXED = 0xFF10b981;   // Зеленый
    private static final int COLOR_WARNING_FIXED = 0xFFf59e0b;   // Желтый
    private static final int COLOR_DANGER_FIXED = 0xFFef4444;    // Красный
    private static final int COLOR_ACCENT_FIXED = 0xFF00D9FF;    // Бирюзовый
    // ФИКСИРОВАННЫЕ цвета текста (всегда читаемые)
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;    // Белый всегда
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;  // Светло-серый всегда
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;      // Серый всегда
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    
    // Иконки
    private static final Identifier ICON_CONSOLE = Identifier.of("whiterise_adminpanel", "textures/icons/console.png");
    private static final Identifier ICON_PLAYERS = Identifier.of("whiterise_adminpanel", "textures/icons/players.png");
    private static final Identifier ICON_SHIELD = Identifier.of("whiterise_adminpanel", "textures/icons/shield.png");
    private static final Identifier ICON_ISSUED = Identifier.of("whiterise_adminpanel", "textures/icons/issued.png");
    private static final Identifier ICON_ONLINE = Identifier.of("whiterise_adminpanel", "textures/icons/online.png");
    private static final Identifier ICON_RULES = Identifier.of("whiterise_adminpanel", "textures/icons/rules.png");
    private static final Identifier ICON_GUI_SETTINGS = Identifier.of("whiterise_adminpanel", "textures/icons/gui_settings.png");
    private static final Identifier ICON_THEME = Identifier.of("whiterise_adminpanel", "textures/icons/theme.png");
    
    private TextFieldWidget nicknameField;
    private TextFieldWidget searchField; // Поле поиска в чате
    private int chatScrollOffset = 0;
    private int chatHorizontalScrollOffset = 0; // Горизонтальный скролл для длинных сообщений
    private int rulesScrollOffset = 0; // Скролл для списка причин
    private String selectedAction = ""; // mute, unmute, ban, unban
    private List<PunishmentRule> currentRules = null;
    private PunishmentRule selectedRule = null; // Выбранное правило (для выбора времени)
    private boolean waitingForRealname = false; // Ожидаем ответ от /realname
    private List<String> autocompleteSuggestions = new ArrayList<>(); // Подсказки автодополнения
    private int selectedSuggestionIndex = -1; // Выбранная подсказка (для навигации стрелками)
    
    // ОПТИМИЗАЦИЯ: кэш обработанных сообщений чата
    private static class CachedLine {
        final ChatLogEntry entry;
        final String plainText;
        
        CachedLine(ChatLogEntry entry, String plainText) {
            this.entry = entry;
            this.plainText = plainText;
        }
    }
    private List<CachedLine> cachedChatLines = new ArrayList<>();
    private int cachedChatHash = 0; // Хэш для определения изменений
    
    // СТАТИЧЕСКИЕ переменные для сохранения результата между открытиями
    private static String savedResultMessage = ""; // Сообщение о результате действия
    private static String savedRealNickname = null; // Сохраненный никнейм
    
    // Отслеживание hover состояния для звуков
    private boolean wasMuteButtonHovered = false;
    private boolean wasUnmuteButtonHovered = false;
    private boolean wasBanButtonHovered = false;
    private boolean wasUnbanButtonHovered = false;
    private boolean wasIPBanButtonHovered = false;
    private boolean wasCheckMuteButtonHovered = false;
    private boolean wasCheckButtonHovered = false;
    private boolean was14dButtonHovered = false;
    private boolean was21dButtonHovered = false;
    
    // Отслеживание hover для кнопок верхней панели
    private boolean wasPlayersButtonHovered = false;
    private boolean wasLogsButtonHovered = false;
    private boolean wasIssuedButtonHovered = false;
    private boolean wasAntiCheatButtonHovered = false;
    private boolean wasRulesButtonHovered = false;
    private boolean wasThemeButtonHovered = false;
    private boolean wasInterfaceButtonHovered = false;
    
    // Кастомный шрифт
    private TextRenderer customFont;
    
    public ConsoleScreen(Screen parent) {
        super(Text.literal("Консоль"));
        this.parent = parent;
    }
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fillGradient()
    }
    
    /**
     * Получает текущий шрифт (кастомный Montserrat или стандартный)
     */
    private TextRenderer getFont() {
        if (customFont == null) {
            customFont = CustomFontRenderer.getMontserrat();
        }
        return customFont;
    }
    
    @Override
    protected void init() {
        // Поле ввода никнейма - опущено ниже из-за верхней панели
        int fieldX = 30;
        int fieldY = 70; // Было 120, подняли на 50px
        int fieldHeight = 30;
        
        // ИСПРАВЛЕНО: выравниваем текст по иконке 👤 и опускаем на 5px
        int nicknameIconWidth = getFont().getWidth("👤");
        nicknameField = new TextFieldWidget(getFont(), 
            fieldX + 8 + nicknameIconWidth + 5,  // После иконки с отступом
            fieldY + (fieldHeight - 8) / 2 - 4 + 5,  // Центрирован + опущен на 5px
            210 - nicknameIconWidth - 5,  // Ширина с учетом иконки
            20, 
            Text.literal("Nickname"));
        nicknameField.setPlaceholder(Text.literal("Введите никнейм..."));
        nicknameField.setMaxLength(16);
        nicknameField.setDrawsBackground(false); // Отключаем стандартный фон
        
        // КРИТИЧНО: добавляем как drawable И selectable
        this.addDrawableChild(nicknameField);
        
        // Поле поиска в чате (над чатом справа) - опущено ниже
        int dividerX = 320;
        int searchX = dividerX + 20;
        int searchY = 70; // Было 95, подняли на 25px выше
        int searchWidth = this.width - dividerX - 40;
        
        // ИСПРАВЛЕНО: выравниваем текст по иконке + опускаем на 6px для центрирования
        int iconWidth = getFont().getWidth("🔍");
        searchField = new TextFieldWidget(getFont(), searchX + 5 + iconWidth + 5, searchY + 10, searchWidth - (5 + iconWidth + 10), 20, Text.literal("Search"));
        searchField.setPlaceholder(Text.literal("")); // Placeholder убран
        searchField.setMaxLength(16);
        searchField.setDrawsBackground(false);
        
        // КРИТИЧНО: добавляем как drawable (чтобы рендерился автоматически)
        this.addDrawableChild(searchField);
        this.setInitialFocus(nicknameField); // Устанавливаем начальный фокус на поле никнейма
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Фон
        context.fillGradient(0, 0, this.width, this.height, COLOR_BG_DARKEST(), COLOR_BG_DARK());
        
        // ФОНОВЫЕ ЧАСТИЦЫ (рендерим ПОСЛЕ фона, но ДО UI элементов)
        context.getMatrices().push();
        com.whiterise.adminpanel.background.ParticleSystem.getInstance().render(context, delta, mouseX, mouseY);
        context.getMatrices().pop();
        
        // ВЕРХНЯЯ ПАНЕЛЬ НАВИГАЦИИ
        renderTopNavigationBar(context, mouseX, mouseY);
        
        // СЧЕТЧИК ОНЛАЙН ИГРОКОВ убран по запросу
        
        // Заголовки удалены - освобождаем место
        
        // КРАСИВОЕ ПОЛЕ НИКНЕЙМА (смещено вверх на 50px)
        renderNicknameField(context, mouseX, mouseY, delta);
        
        // ПОЛЕ ПОИСКА В ЧАТЕ (с надписью)
        renderSearchField(context, mouseX, mouseY, delta);
        
        // СТИЛЬНЫЕ КНОПКИ (как в админ-панели, смещены вверх на 50px)
        renderStyledButtons(context, mouseX, mouseY);
        
        // Вертикальный разделитель убран для чистого вида
        
        // ПРАВАЯ ЧАСТЬ: Чат (опустили ниже)
        int dividerX = 320; // Позиция разделителя (хотя сам разделитель убран)
        renderChatView(context, dividerX + 20, 105, this.width - dividerX - 40, this.height - 145, mouseX, mouseY); // Было 130, подняли на 25px
        
        // ЛЕВАЯ ЧАСТЬ: Список причин (если выбрано действие)
        if (currentRules != null && !currentRules.isEmpty()) {
            renderRulesList(context, 30, 260, 260, this.height - 300, mouseX, mouseY); // Было 310, подняли на 50px
        }
        
        // ЛЕВАЯ ЧАСТЬ: Выбор времени для читов (если выбрано правило 2.4)
        if (selectedRule != null && selectedRule.getCode().equals("2.4")) {
            renderDurationChoice(context, 30, 260, 260, mouseX, mouseY); // Было 310, подняли на 50px
        }
        
        // ИНФОРМАЦИЯ О ПОЛЬЗОВАТЕЛЕ (слева снизу) - КОМПАКТНАЯ В ОДНУ СТРОКУ
        renderCompactUserInfo(context);
        
        // КРИТИЧНО: рендерим виджеты (поля ввода)
        super.render(context, mouseX, mouseY, delta);
        
        // АВТОДОПОЛНЕНИЕ (РЕНДЕРИМ В САМОМ КОНЦЕ, ЧТОБЫ БЫТЬ ПОВЕРХ ВСЕГО)
        if (!autocompleteSuggestions.isEmpty() && nicknameField.isFocused()) {
            renderAutocompleteSuggestions(context, mouseX, mouseY);
        }
    }
    
    /**
     * Рендерит счетчик онлайн игроков (слева сверху)
     */
    private void renderOnlineCounter(DrawContext context) {
        int x = 10;
        int y = 18;
        
        // Получаем количество онлайн игроков
        int onlineCount = AdminPanelClient.getPlayerManager().getPlayersSortedByActivity().size();
        
        // Текст без иконки
        String text = onlineCount + " онлайн";
        context.drawText(getFont(), text, x, y, COLOR_TEXT_SECONDARY, false);
    }
    
    /**
     * Рендерит красивое поле ввода никнейма
     */
    private void renderNicknameField(DrawContext context, int mouseX, int mouseY, float delta) {
        int fieldX = 30;
        int fieldY = 70; // Было 120, подняли на 50px
        int fieldWidth = 250;
        int fieldHeight = 30;
        
        // Проверка hover
        boolean isHovered = mouseX >= fieldX && mouseX <= fieldX + fieldWidth && 
                           mouseY >= fieldY && mouseY <= fieldY + fieldHeight;
        
        // Фон поля с градиентом (чуть светлее при фокусе) - СКРУГЛЕННЫЙ
        int bgColor = nicknameField.isFocused() ? 
            com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BG_CARD(), 1.1f) : 
            COLOR_BG_CARD();
        int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, fieldX, fieldY, fieldWidth, fieldHeight, 8, bgColor, bgColorDarker);
        
        // Границы с улучшенным эффектом (чуть светлее при hover/focus) - СКРУГЛЕННЫЕ
        int borderColor = (nicknameField.isFocused() || isHovered) ? 
            com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BORDER(), 1.3f) : 
            COLOR_BORDER();
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, fieldX, fieldY, fieldWidth, fieldHeight, 8, borderColor);
        
        // Убрано свечение при фокусе (было слишком ярко)
        
        // Иконка игрока слева (выровнена по центру блока)
        int iconY = fieldY + (fieldHeight - 8) / 2; // Центрируем иконку по вертикали
        context.drawText(getFont(), "👤", fieldX + 8, iconY, COLOR_TEXT_SECONDARY, false);
        
        // Поле рендерится автоматически через addDrawableChild()
    }
    
    /**
     * Рендерит поле поиска в чате
     */
    private void renderSearchField(DrawContext context, int mouseX, int mouseY, float delta) {
        int dividerX = 320;
        int fieldX = dividerX + 20;
        int fieldY = 70; // Было 95, подняли на 25px выше
        int fieldWidth = this.width - dividerX - 40;
        int fieldHeight = 25;
        
        // Проверка hover
        boolean isHovered = mouseX >= fieldX && mouseX <= fieldX + fieldWidth && 
                           mouseY >= fieldY && mouseY <= fieldY + fieldHeight;
        
        // Фон поля с градиентом (чуть светлее при фокусе) - СКРУГЛЕННЫЙ
        int bgColor = searchField.isFocused() ? 
            com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BG_CARD(), 1.1f) : 
            COLOR_BG_CARD();
        int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, fieldX, fieldY, fieldWidth, fieldHeight, 8, bgColor, bgColorDarker);
        
        // Границы с улучшенным эффектом (чуть светлее при hover/focus) - СКРУГЛЕННЫЕ
        int borderColor = (searchField.isFocused() || isHovered) ? 
            com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BORDER(), 1.3f) : 
            COLOR_BORDER();
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, fieldX, fieldY, fieldWidth, fieldHeight, 8, borderColor);
        
        // Убрано свечение при фокусе (было слишком ярко)
        
        // Иконка поиска слева
        int iconX = fieldX + 5;
        int iconY = fieldY + (fieldHeight - 8) / 2;
        int iconWidth = getFont().getWidth("🔍");
        context.drawText(getFont(), "🔍", iconX, iconY, COLOR_TEXT_SECONDARY, false);
        
        // Поле рендерится автоматически через addDrawableChild()
    }
    
    /**
     * Рендерит список автодополнения под полем никнейма - СКРУГЛЕННЫЙ
     */
    private void renderAutocompleteSuggestions(DrawContext context, int mouseX, int mouseY) {
        int fieldX = 30;
        int fieldY = 70; // ИСПРАВЛЕНО: было 120, теперь 70 (синхронизировано с полем никнейма)
        int fieldWidth = 250;
        int fieldHeight = 30;
        
        int suggestionsX = fieldX;
        int suggestionsY = fieldY + fieldHeight + 2; // Под полем ввода
        int suggestionsWidth = fieldWidth;
        int itemHeight = 20;
        int maxVisible = Math.min(5, autocompleteSuggestions.size()); // Максимум 5 подсказок
        int suggestionsHeight = maxVisible * itemHeight;
        
        // КРИТИЧНО: Включаем scissor для обрезки любого контента с учетом скруглений
        com.whiterise.adminpanel.util.RenderUtils.enableRoundedScissor(context, suggestionsX, suggestionsY, suggestionsWidth, suggestionsHeight, 8);
        
        // Тень для списка (рисуем ПЕРВОЙ, чтобы была под всем)
        context.fill(suggestionsX + 2, suggestionsY + 2, 
                    suggestionsX + suggestionsWidth + 2, 
                    suggestionsY + suggestionsHeight + 2, 0xCC000000);
        
        // КРИТИЧНО: Рисуем ПОЛНОСТЬЮ НЕПРОЗРАЧНЫЙ базовый слой
        // Расширяем на 10px во все стороны для гарантии покрытия
        context.fill(suggestionsX - 10, suggestionsY - 10, 
                    suggestionsX + suggestionsWidth + 10, 
                    suggestionsY + suggestionsHeight + 10, 0xFF0F141C);
        
        // Фон списка - СКРУГЛЕННЫЙ и НЕПРОЗРАЧНЫЙ (поверх базового слоя)
        RenderUtils.fillRounded(context, suggestionsX, suggestionsY, suggestionsWidth, suggestionsHeight, 8, 0xFF161C26);
        
        // Границы - СКРУГЛЕННЫЕ (толще для лучшей видимости)
        RenderUtils.drawRoundedBorder(context, suggestionsX, suggestionsY, suggestionsWidth, suggestionsHeight, 8, COLOR_ACCENT());
        RenderUtils.drawRoundedBorder(context, suggestionsX - 1, suggestionsY - 1, suggestionsWidth + 2, suggestionsHeight + 2, 8, COLOR_ACCENT());
        
        // Рендерим подсказки
        for (int i = 0; i < maxVisible; i++) {
            String suggestion = autocompleteSuggestions.get(i);
            int itemY = suggestionsY + i * itemHeight;
            
            // Проверка hover или выбран стрелками
            boolean isHovered = mouseX >= suggestionsX && mouseX <= suggestionsX + suggestionsWidth && 
                               mouseY >= itemY && mouseY < itemY + itemHeight;
            boolean isSelected = i == selectedSuggestionIndex;
            
            // Фон элемента - СКРУГЛЕННЫЙ (только если hover/selected)
            if (isHovered || isSelected) {
                RenderUtils.fillRounded(context, suggestionsX + 2, itemY, suggestionsWidth - 4, itemHeight, 6, COLOR_BG_HOVER());
            }
            
            // Текст (БЕЗ тени!)
            int textColor = (isHovered || isSelected) ? COLOR_ACCENT() : COLOR_TEXT_PRIMARY;
            context.drawText(getFont(), suggestion, suggestionsX + 10, 
                            itemY + (itemHeight - 8) / 2, textColor, false);
        }
        
        // КРИТИЧНО: Отключаем scissor
        context.disableScissor();
    }
    
    /**
     * Рендерит компактную информацию о пользователе (слева снизу) - В ОДНУ СТРОКУ
     */
    private void renderCompactUserInfo(DrawContext context) {
        int x = 15;
        int y = this.height - 25;
        
        String username = this.client.getSession().getUsername();
        String infoText = "CLNXconsole | Logged: " + username + " | Role: Staff";
        
        context.drawText(getFont(), infoText, x, y, COLOR_TEXT_MUTED, false);
    }
    
    /**
     * Рендерит стильные кнопки действий
     */
    private void renderStyledButtons(DrawContext context, int mouseX, int mouseY) {
        int buttonY = 110; // Было 160, подняли на 50px
        int buttonWidth = 120;
        int buttonHeight = 30;
        int buttonSpacing = 10;
        
        // Кнопка 1: Мут (желтая)
        boolean hover1 = mouseX >= 30 && mouseX <= 30 + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover1 && !wasMuteButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasMuteButtonHovered = hover1;
        renderButton(context, 30, buttonY, buttonWidth, buttonHeight, "🔇 Мут", 
                     hover1 ? adjustBrightness(COLOR_WARNING_FIXED, 1.15f) : COLOR_WARNING_FIXED, hover1);
        
        // Кнопка 2: Размут (зеленая)
        boolean hover2 = mouseX >= 30 + buttonWidth + buttonSpacing && 
                        mouseX <= 30 + buttonWidth * 2 + buttonSpacing && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover2 && !wasUnmuteButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasUnmuteButtonHovered = hover2;
        renderButton(context, 30 + buttonWidth + buttonSpacing, buttonY, buttonWidth, buttonHeight, "🔊 Размут",
                     hover2 ? adjustBrightness(COLOR_SUCCESS_FIXED, 1.15f) : COLOR_SUCCESS_FIXED, hover2);
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 3: Бан (красная)
        boolean hover3 = mouseX >= 30 && mouseX <= 30 + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover3 && !wasBanButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasBanButtonHovered = hover3;
        renderButton(context, 30, buttonY, buttonWidth, buttonHeight, "🔨 Бан",
                     hover3 ? adjustBrightness(COLOR_DANGER_FIXED, 1.15f) : COLOR_DANGER_FIXED, hover3);
        
        // Кнопка 4: Разбан (синяя)
        boolean hover4 = mouseX >= 30 + buttonWidth + buttonSpacing && 
                        mouseX <= 30 + buttonWidth * 2 + buttonSpacing && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover4 && !wasUnbanButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasUnbanButtonHovered = hover4;
        renderButton(context, 30 + buttonWidth + buttonSpacing, buttonY, buttonWidth, buttonHeight, "✅ Разбан",
                     hover4 ? adjustBrightness(COLOR_ACCENT_FIXED, 1.15f) : COLOR_ACCENT_FIXED, hover4);
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 5: Бан по IP (фиолетовая)
        int ipBanButtonWidth = 250;
        boolean hover5 = mouseX >= 30 && mouseX <= 30 + ipBanButtonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover5 && !wasIPBanButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasIPBanButtonHovered = hover5;
        int purpleColor = 0xFF9333ea; // Фиолетовый цвет
        renderButton(context, 30, buttonY, ipBanButtonWidth, buttonHeight, "🔒 Бан по IP",
                     hover5 ? adjustBrightness(purpleColor, 1.15f) : purpleColor, hover5);
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 6: Проверка мута (оранжевая)
        int checkMuteButtonWidth = 250;
        boolean hover6 = mouseX >= 30 && mouseX <= 30 + checkMuteButtonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover6 && !wasCheckMuteButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasCheckMuteButtonHovered = hover6;
        int orangeColor = 0xFFf97316; // Оранжевый цвет
        renderButton(context, 30, buttonY, checkMuteButtonWidth, buttonHeight, "🔇 Проверка мута",
                     hover6 ? adjustBrightness(orangeColor, 1.15f) : orangeColor, hover6);
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 7: Проверка никнейма (бирюзовая)
        // СКРЫВАЕМ если открыт список причин или выбор времени
        if (currentRules == null && selectedRule == null) {
            int checkButtonWidth = 250;
            boolean hover7 = mouseX >= 30 && mouseX <= 30 + checkButtonWidth && 
                            mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
            if (hover7 && !wasCheckButtonHovered) {
                SoundManager.playHoverSound();
            }
            wasCheckButtonHovered = hover7;
            int tealColor = 0xFF14b8a6; // Бирюзовый цвет
            renderButton(context, 30, buttonY, checkButtonWidth, buttonHeight, "🔍 Проверка никнейма",
                         hover7 ? adjustBrightness(tealColor, 1.15f) : tealColor, hover7);
            
            buttonY += buttonHeight + buttonSpacing;
        }
        
        // ПОЛЕ РЕЗУЛЬТАТОВ (только если НЕТ списка причин и выбора времени)
        if (currentRules == null && selectedRule == null) {
            renderResultBox(context, 30, buttonY, 250, mouseX, mouseY);
        }
    }
    
    /**
     * Рендерит одну кнопку в стиле админ-панели - СКРУГЛЕННУЮ
     */
    private void renderButton(DrawContext context, int x, int y, int width, int height, 
                              String text, int color, boolean isHovered) {
        // Тень при hover
        if (isHovered) {
            RenderUtils.fillRounded(context, x + 2, y + 2, width, height, 15, 0x88000000);
        }
        
        // Фон кнопки - СКРУГЛЕННЫЙ (БЕЗ ГРАНИЦ для чистого вида)
        RenderUtils.fillRounded(context, x, y, width, height, 15, color);
        
        // Текст по центру (БЕЗ тени - shadow=false)
        int textWidth = getFont().getWidth(text);
        context.drawText(getFont(), text, x + (width - textWidth) / 2, 
                        y + (height - 8) / 2, COLOR_TEXT_PRIMARY, false);
    }
    
    /**
     * Рендерит поле результатов действий
     */
    private void renderResultBox(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        int height = this.height - y - 60; // До кнопки "Назад"
        
        // Фон - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, x, y, width, height, 20, COLOR_BG_CARD());
        
        // Границы - СКРУГЛЕННЫЕ
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 10, COLOR_BORDER());
        
        // Заголовок
        context.drawText(getFont(), "Результат", x + 10, y + 10, COLOR_TEXT_SECONDARY, false);
        
        // Текст результата (многострочный) - сдвинуто выше после удаления разделителя
        if (!savedResultMessage.isEmpty()) {
            int textY = y + 30; // Было y + 35, теперь y + 30
            int maxWidth = width - 20;
            int lineHeight = 12;
            
            // Разбиваем на строки
            List<String> lines = wrapText(savedResultMessage, maxWidth);
            
            for (String line : lines) {
                if (textY < y + height - 10) {
                    context.drawText(getFont(), line, x + 10, textY, COLOR_TEXT_PRIMARY, false);
                    textY += lineHeight;
                }
            }
            
            // Кнопка копирования никнейма (если есть)
            if (savedRealNickname != null && !savedRealNickname.isEmpty()) {
                int copyButtonY = y + height - 40; // Опущено на 15px ниже (было -55)
                int copyButtonWidth = width - 20;
                int copyButtonHeight = 25;
                int copyButtonX = x + 10;
                
                boolean isHovered = mouseX >= copyButtonX && mouseX <= copyButtonX + copyButtonWidth && 
                                   mouseY >= copyButtonY && mouseY <= copyButtonY + copyButtonHeight;
                
                // Фон кнопки
                int buttonColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_DARK();
                RenderUtils.fillRounded(context, copyButtonX, copyButtonY, copyButtonWidth, copyButtonHeight, 6, buttonColor);
                
                // Границы
                int borderColor = isHovered ? COLOR_ACCENT() : COLOR_BORDER();
                RenderUtils.drawRoundedBorder(context, copyButtonX, copyButtonY, copyButtonWidth, copyButtonHeight, 6, borderColor);
                
                // Текст
                String copyText = "📋 Копировать: " + savedRealNickname;
                int copyTextWidth = getFont().getWidth(copyText);
                int textColor = isHovered ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
                context.drawText(getFont(), copyText, 
                               copyButtonX + (copyButtonWidth - copyTextWidth) / 2,
                               copyButtonY + (copyButtonHeight - 8) / 2, textColor, isHovered);
            }
        } else {
            // Пустое состояние
            String emptyText = "Здесь будет результат";
            int textWidth = getFont().getWidth(emptyText);
            context.drawText(getFont(), emptyText, 
                           x + (width - textWidth) / 2, 
                           y + height / 2, COLOR_TEXT_MUTED, false);
        }
    }
    
    /**
     * Разбивает текст на строки по ширине
     */
    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        
        // Сначала разбиваем по \n (явные переносы строк)
        String[] paragraphs = text.split("\n");
        
        for (String paragraph : paragraphs) {
            // Пропускаем пустые строки
            if (paragraph.trim().isEmpty()) {
                lines.add("");
                continue;
            }
            
            // Разбиваем каждый параграф по словам
            String[] words = paragraph.split(" ");
            StringBuilder currentLine = new StringBuilder();
            
            for (String word : words) {
                String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
                
                if (getFont().getWidth(testLine) <= maxWidth) {
                    if (currentLine.length() > 0) {
                        currentLine.append(" ");
                    }
                    currentLine.append(word);
                } else {
                    if (currentLine.length() > 0) {
                        lines.add(currentLine.toString());
                        currentLine = new StringBuilder(word);
                    } else {
                        // Слово слишком длинное - обрезаем
                        lines.add(getFont().trimToWidth(word, maxWidth));
                    }
                }
            }
            
            if (currentLine.length() > 0) {
                lines.add(currentLine.toString());
            }
        }
        
        return lines;
    }
    
    /**
     * Рендерит верхнюю панель навигации с кнопками
     */
    private void renderTopNavigationBar(DrawContext context, int mouseX, int mouseY) {
        int barHeight = 50;
        
        // Фон панели
        context.fillGradient(0, 0, this.width, barHeight, COLOR_BG_CARD(), COLOR_BG_DARK());
        
        // Нижняя граница
        context.fill(0, barHeight, this.width, barHeight + 2, COLOR_BORDER());
        
        // Кнопки в один ряд (7 кнопок: Консоль, Игроки, Проверка, Выданные, Правила, Темы, Интерфейс)
        int buttonWidth = 115; // Уменьшено для 7 кнопок
        int buttonHeight = 35;
        int buttonSpacing = 8; // Уменьшено для 7 кнопок
        int totalWidth = buttonWidth * 7 + buttonSpacing * 6; // 7 кнопок
        int startX = (this.width - totalWidth) / 2; // Центрируем
        int buttonY = (barHeight - buttonHeight) / 2;
        
        // Кнопка 1: Консоль (активная)
        boolean hover1 = mouseX >= startX && mouseX <= startX + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover1 && !wasPlayersButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasPlayersButtonHovered = hover1;
        renderTopBarButton(context, startX, buttonY, buttonWidth, buttonHeight, ICON_CONSOLE, "Консоль", hover1, true);
        
        // Кнопка 2: Игроки
        int button2X = startX + buttonWidth + buttonSpacing;
        boolean hover2 = mouseX >= button2X && mouseX <= button2X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover2 && !wasLogsButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasLogsButtonHovered = hover2;
        renderTopBarButton(context, button2X, buttonY, buttonWidth, buttonHeight, ICON_PLAYERS, "Игроки", hover2, false);
        
        // Кнопка 3: Проверка
        int button3X = button2X + buttonWidth + buttonSpacing;
        boolean hover3 = mouseX >= button3X && mouseX <= button3X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover3 && !wasAntiCheatButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasAntiCheatButtonHovered = hover3;
        renderTopBarButton(context, button3X, buttonY, buttonWidth, buttonHeight, ICON_SHIELD, "Проверка", hover3, false);
        
        // Кнопка 4: Выданные
        int button4X = button3X + buttonWidth + buttonSpacing;
        boolean hover4 = mouseX >= button4X && mouseX <= button4X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover4 && !wasIssuedButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasIssuedButtonHovered = hover4;
        renderTopBarButton(context, button4X, buttonY, buttonWidth, buttonHeight, ICON_ISSUED, "Выданные", hover4, false);
        
        // Кнопка 5: Правила
        int button5X = button4X + buttonWidth + buttonSpacing;
        boolean hover5 = mouseX >= button5X && mouseX <= button5X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover5 && !wasRulesButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasRulesButtonHovered = hover5;
        renderTopBarButton(context, button5X, buttonY, buttonWidth, buttonHeight, ICON_RULES, "Правила", hover5, false);
        
        // Кнопка 6: Темы (НОВАЯ)
        int button6X = button5X + buttonWidth + buttonSpacing;
        boolean hover6 = mouseX >= button6X && mouseX <= button6X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover6 && !wasThemeButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasThemeButtonHovered = hover6;
        renderTopBarButton(context, button6X, buttonY, buttonWidth, buttonHeight, ICON_THEME, "Темы", hover6, false);
        
        // Кнопка 7: Интерфейс
        int button7X = button6X + buttonWidth + buttonSpacing;
        boolean hover7 = mouseX >= button7X && mouseX <= button7X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover7 && !wasInterfaceButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasInterfaceButtonHovered = hover7;
        renderTopBarButton(context, button7X, buttonY, buttonWidth, buttonHeight, ICON_GUI_SETTINGS, "Интерфейс", hover7, false);
    }
    
    /**
     * Рендерит одну кнопку верхней панели с иконкой (текстовая иконка - эмодзи)
     */
    private void renderTopBarButton(DrawContext context, int x, int y, int width, int height, String icon, String text, boolean isHovered, boolean isActive) {
        // Фон кнопки (активная кнопка всегда подсвечена)
        int bgColor;
        if (isActive) {
            bgColor = COLOR_BG_HOVER(); // Активная кнопка
        } else {
            bgColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_DARKEST();
        }
        RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
        
        // Границы (активная кнопка с акцентной границей)
        int borderColor;
        if (isActive) {
            borderColor = COLOR_ACCENT(); // Активная кнопка
        } else {
            borderColor = isHovered ? COLOR_ACCENT() : COLOR_BORDER();
        }
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, borderColor);
        
        // Иконка слева
        int iconSize = 16;
        int iconX = x + 15;
        int iconY = y + (height - iconSize) / 2;
        context.drawText(getFont(), icon, iconX, iconY, COLOR_ACCENT(), false);
        
        // Текст справа от иконки
        int textX = iconX + iconSize + 8;
        int textY = y + (height - 8) / 2;
        int textColor;
        if (isActive) {
            textColor = COLOR_TEXT_PRIMARY; // Активная кнопка
        } else {
            textColor = isHovered ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
        }
        context.drawText(getFont(), text, textX, textY, textColor, false);
    }
    
    /**
     * Рендерит одну кнопку верхней панели с иконкой (PNG иконка из assets)
     */
    private void renderTopBarButton(DrawContext context, int x, int y, int width, int height, net.minecraft.util.Identifier iconTexture, String text, boolean isHovered, boolean isActive) {
        // Фон кнопки (активная кнопка всегда подсвечена)
        int bgColor;
        if (isActive) {
            bgColor = COLOR_BG_HOVER(); // Активная кнопка
        } else {
            bgColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_DARKEST();
        }
        RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
        
        // Границы (активная кнопка с акцентной границей)
        int borderColor;
        if (isActive) {
            borderColor = COLOR_ACCENT(); // Активная кнопка
        } else {
            borderColor = isHovered ? COLOR_ACCENT() : COLOR_BORDER();
        }
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, borderColor);
        
        // Текст - центрируем
        int iconSize = 24; // Увеличено с 20 до 24
        int textWidth = getFont().getWidth(text);
        
        // Центрируем текст по горизонтали
        int textX = x + (width - textWidth) / 2;
        int textY = y + (height - 8) / 2;
        
        // Иконка слева от текста
        int iconX = textX - iconSize - 8; // Слева от текста с отступом 8px
        int iconY = y + (height - iconSize) / 2;
        context.drawTexture(RenderLayer::getGuiTextured, iconTexture, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Рендерим текст
        int textColor;
        if (isActive) {
            textColor = COLOR_TEXT_PRIMARY; // Активная кнопка
        } else {
            textColor = isHovered ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
        }
        context.drawText(getFont(), text, textX, textY, textColor, false);
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    /**
     * Рендерит окно чата справа - ОПТИМИЗИРОВАНО
     */
    private void renderChatView(DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY) {
        // Динамический заголовок в зависимости от поиска НАД полем поиска
        String searchQuery = searchField.getText().trim();
        String title = searchQuery.isEmpty() ? "Чат сервера" : "Поиск по " + searchQuery;
        
        // Заголовок НАД полем поиска (поднят на 30px выше от поля поиска, опущен на 7px)
        context.drawText(getFont(), title, x, y - 48, COLOR_TEXT_SECONDARY, false);
        
        // Фон чата - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, x, y, width, height, 10, COLOR_BG_CARD());
        
        // Границы - СКРУГЛЕННЫЕ
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 10, COLOR_BORDER());
        
        // Получаем логи из менеджера
        var logs = AdminPanelClient.getChatLogManager().getAllLogs();
        
        // Фильтруем логи по поисковому запросу
        if (!searchQuery.isEmpty()) {
            String searchLower = searchQuery.toLowerCase();
            logs = logs.stream()
                .filter(entry -> entry.getColoredText().getPlainText().toLowerCase().contains(searchLower))
                .collect(java.util.stream.Collectors.toList());
        }
        
        if (logs.isEmpty()) {
            String emptyText = searchQuery.isEmpty() ? "Чат пуст" : "Ничего не найдено";
            int textWidth = getFont().getWidth(emptyText);
            context.drawText(getFont(), emptyText, x + (width - textWidth) / 2, y + height / 2, COLOR_TEXT_MUTED, false);
            return;
        }
        
        // ОПТИМИЗАЦИЯ: проверяем нужно ли пересчитывать кэш
        int currentHash = logs.hashCode() + searchQuery.hashCode();
        if (currentHash != cachedChatHash) {
            cachedChatHash = currentHash;
            cachedChatLines.clear();
            
            // Обрабатываем все сообщения ОДИН РАЗ
            int maxWidth = width - 30; // Учитываем отступы и скроллбар
            for (var entry : logs) {
                // Не оборачиваем текст, просто добавляем entry в кэш
                cachedChatLines.add(new CachedLine(entry, ""));
            }
        }
        
        // Рендерим только видимые строки из кэша
        int lineHeight = 12;
        int visibleStart = Math.max(0, chatScrollOffset / lineHeight);
        int visibleEnd = Math.min(cachedChatLines.size(), visibleStart + (height / lineHeight) + 2);
        
        String myUsername = this.client.getSession().getUsername();
        
        for (int i = visibleStart; i < visibleEnd; i++) {
            CachedLine cached = cachedChatLines.get(i);
            String lineStr = cached.plainText;
            ChatLogEntry entry = cached.entry;
            int currentY = y + 10 + (i * lineHeight) - chatScrollOffset;
            
            // Проверка видимости строки
            if (currentY < y || currentY >= y + height - 10) {
                continue;
            }
            
            // Подсветка поиска
            if (!searchQuery.isEmpty() && lineStr.toLowerCase().contains(searchQuery.toLowerCase())) {
                String lowerLine = lineStr.toLowerCase();
                String lowerQuery = searchQuery.toLowerCase();
                int queryIndex = lowerLine.indexOf(lowerQuery);
                
                if (queryIndex != -1) {
                    String before = lineStr.substring(0, queryIndex);
                    String found = lineStr.substring(queryIndex, queryIndex + searchQuery.length());
                    String after = lineStr.substring(queryIndex + searchQuery.length());
                    
                    int currentX = x + 10;
                    if (!before.isEmpty()) {
                        context.drawText(getFont(), before, currentX, currentY, COLOR_TEXT_PRIMARY, false);
                        currentX += getFont().getWidth(before);
                    }
                    context.drawText(getFont(), found, currentX, currentY, COLOR_DANGER_FIXED, false);
                    currentX += getFont().getWidth(found);
                    if (!after.isEmpty()) {
                        context.drawText(getFont(), after, currentX, currentY, COLOR_TEXT_PRIMARY, false);
                    }
                } else {
                    context.drawText(getFont(), lineStr, x + 10, currentY, COLOR_TEXT_PRIMARY, false);
                }
            }
            // Подсветка античита (красный цвет)
            else if (lineStr.contains("[ᴡʜɪᴛᴇᴄʜᴇᴀᴛ]")) {
                context.drawText(getFont(), lineStr, x + 10, currentY, COLOR_DANGER_FIXED, false);
            }
            // Подсветка моего никнейма
            else if (lineStr.contains(myUsername)) {
                renderMyNicknameLine(context, lineStr, myUsername, x + 10, currentY);
            } 
            // Обычный рендеринг - используем ColoredText для правильных цветов
            else {
                // Включаем scissor для обрезки текста по границам чата с учетом скруглений
                com.whiterise.adminpanel.util.RenderUtils.enableRoundedScissor(context, x, y, width, height, 10);
                
                // Рендерим время
                context.drawText(getFont(), entry.getTimeString() + " ", x + 10 - chatHorizontalScrollOffset, currentY, COLOR_TEXT_PRIMARY, false);
                int currentX = x + 10 + getFont().getWidth(entry.getTimeString() + " ") - chatHorizontalScrollOffset;
                
                // Рендерим каждый сегмент с его цветом (БЕЗ обрезки, используем горизонтальный скролл)
                for (var segment : entry.getColoredText().getSegments()) {
                    String text = segment.text;
                    context.drawText(getFont(), text, currentX, currentY, segment.color, false);
                    currentX += getFont().getWidth(text);
                }
                
                // Отключаем scissor
                context.disableScissor();
            }
        }
        
        // Рендерим скроллбар
        renderChatScrollbar(context, x, y, width, height);
    }
    
    /**
     * Рендерит скроллбар для чата
     */
    private void renderChatScrollbar(DrawContext context, int x, int y, int width, int height) {
        int lineHeight = 12;
        int totalLines = cachedChatLines.size();
        int visibleLines = height / lineHeight;
        int maxScroll = Math.max(0, (totalLines - visibleLines) * lineHeight);
        
        // Вертикальный скроллбар
        if (maxScroll > 0) {
            int scrollbarX = x + width - 6;
            int scrollbarY = y;
            int scrollbarWidth = 6;
            int scrollbarHeight = height;
            
            // Фон скроллбара
            context.fill(scrollbarX, scrollbarY, scrollbarX + scrollbarWidth, scrollbarY + scrollbarHeight, 0xFF1a1f2e);
            
            // Ползунок
            float scrollPercentage = (float) chatScrollOffset / maxScroll;
            int thumbHeight = Math.max(20, (int) (scrollbarHeight * ((float) scrollbarHeight / (scrollbarHeight + maxScroll))));
            int thumbY = scrollbarY + (int) ((scrollbarHeight - thumbHeight) * scrollPercentage);
            
            context.fill(scrollbarX, thumbY, scrollbarX + scrollbarWidth, thumbY + thumbHeight, COLOR_ACCENT());
        }
        
        // Горизонтальный скроллбар (если есть горизонтальный скролл)
        if (chatHorizontalScrollOffset > 0) {
            int hScrollbarX = x;
            int hScrollbarY = y + height - 6;
            int hScrollbarWidth = width - (maxScroll > 0 ? 6 : 0); // Учитываем вертикальный скроллбар
            int hScrollbarHeight = 6;
            
            // Фон горизонтального скроллбара
            context.fill(hScrollbarX, hScrollbarY, hScrollbarX + hScrollbarWidth, hScrollbarY + hScrollbarHeight, 0xFF1a1f2e);
            
            // Вычисляем максимальную ширину контента
            int maxContentWidth = 0;
            for (var cached : cachedChatLines) {
                ChatLogEntry entry = cached.entry;
                int lineWidth = getFont().getWidth(entry.getTimeString() + " " + entry.getColoredText().getPlainText());
                maxContentWidth = Math.max(maxContentWidth, lineWidth);
            }
            
            int visibleWidth = width - 30; // Учитываем отступы
            int maxHScroll = Math.max(0, maxContentWidth - visibleWidth);
            
            if (maxHScroll > 0) {
                // Ползунок
                float hScrollPercentage = (float) chatHorizontalScrollOffset / maxHScroll;
                int thumbWidth = Math.max(30, (int) (hScrollbarWidth * ((float) visibleWidth / maxContentWidth)));
                int thumbX = hScrollbarX + (int) ((hScrollbarWidth - thumbWidth) * hScrollPercentage);
                
                context.fill(thumbX, hScrollbarY, thumbX + thumbWidth, hScrollbarY + hScrollbarHeight, COLOR_ACCENT());
            }
        }
    }
    

    
    /**
     * Рендерит строку спамера с красным никнеймом
     */
    private void renderSpammerLine(DrawContext context, String line, String username, int x, int y) {
        // Ищем никнейм в строке
        int usernameIndex = line.indexOf(username);
        
        if (usernameIndex == -1) {
            // Никнейм не найден - обычный рендеринг
            context.drawText(getFont(), line, x, y, COLOR_TEXT_PRIMARY, false);
            return;
        }
        
        // Разбиваем строку на части
        String before = line.substring(0, usernameIndex);
        String after = line.substring(usernameIndex + username.length());
        
        int currentX = x;
        
        // До никнейма (обычный цвет)
        if (!before.isEmpty()) {
            context.drawText(getFont(), before, currentX, y, COLOR_TEXT_PRIMARY, false);
            currentX += getFont().getWidth(before);
        }
        
        // Никнейм (красный)
        context.drawText(getFont(), username, currentX, y, COLOR_DANGER_FIXED, false);
        currentX += getFont().getWidth(username);
        
        // После никнейма (обычный цвет)
        if (!after.isEmpty()) {
            context.drawText(getFont(), after, currentX, y, COLOR_TEXT_PRIMARY, false);
        }
    }
    
    /**
     * Рендерит строку с голубым выделением моего никнейма
     */
    private void renderMyNicknameLine(DrawContext context, String line, String myUsername, int x, int y) {
        // Ищем мой никнейм в строке
        int usernameIndex = line.indexOf(myUsername);
        
        if (usernameIndex == -1) {
            // Никнейм не найден - обычный рендеринг
            context.drawText(getFont(), line, x, y, COLOR_TEXT_PRIMARY, false);
            return;
        }
        
        // Разбиваем строку на части
        String before = line.substring(0, usernameIndex);
        String after = line.substring(usernameIndex + myUsername.length());
        
        int currentX = x;
        
        // До никнейма (обычный цвет)
        if (!before.isEmpty()) {
            context.drawText(getFont(), before, currentX, y, COLOR_TEXT_PRIMARY, false);
            currentX += getFont().getWidth(before);
        }
        
        // Мой никнейм (голубой/cyan)
        context.drawText(getFont(), myUsername, currentX, y, COLOR_ACCENT(), false);
        currentX += getFont().getWidth(myUsername);
        
        // После никнейма (обычный цвет)
        if (!after.isEmpty()) {
            context.drawText(getFont(), after, currentX, y, COLOR_TEXT_PRIMARY, false);
        }
    }
    
    /**
     * Рендерит строку с фиолетовым выделением никнейма (обученное нарушение)
     */
    private void renderLearnedViolationLine(DrawContext context, String line, String username, int x, int y) {
        // Ищем никнейм в строке
        int usernameIndex = line.indexOf(username);
        
        if (usernameIndex == -1) {
            // Никнейм не найден - обычный рендеринг
            context.drawText(getFont(), line, x, y, COLOR_TEXT_PRIMARY, false);
            return;
        }
        
        // Разбиваем строку на части
        String before = line.substring(0, usernameIndex);
        String after = line.substring(usernameIndex + username.length());
        
        int currentX = x;
        
        // До никнейма (обычный цвет)
        if (!before.isEmpty()) {
            context.drawText(getFont(), before, currentX, y, COLOR_TEXT_PRIMARY, false);
            currentX += getFont().getWidth(before);
        }
        
        // Никнейм (фиолетовый)
        int purpleColor = 0xFF9333ea; // Фиолетовый цвет
        context.drawText(getFont(), username, currentX, y, purpleColor, false);
        currentX += getFont().getWidth(username);
        
        // После никнейма (обычный цвет)
        if (!after.isEmpty()) {
            context.drawText(getFont(), after, currentX, y, COLOR_TEXT_PRIMARY, false);
        }
    }
    
    /**
     * Рендерит текст с поддержкой цветовых кодов Minecraft (§, §#RRGGBB, &#RRGGBB)
     * Поддерживает градиенты: &#ffd600t&#f78f00e&#ee4700s&#e60000t
     * @return конечная X позиция после рендеринга
     */
    private int renderColoredText(DrawContext context, String text, int x, int y) {
        if (text == null || text.isEmpty()) {
            return x;
        }
        
        int currentX = x;
        int currentColor = COLOR_TEXT_PRIMARY;
        
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            
            // Проверяем HEX цвет в формате &#RRGGBB (градиент)
            if (c == '&' && i + 7 < text.length() && text.charAt(i + 1) == '#') {
                String hexCode = text.substring(i + 2, i + 8);
                try {
                    int rgb = Integer.parseInt(hexCode, 16);
                    currentColor = 0xFF000000 | rgb; // Добавляем альфа-канал
                    i += 7; // Пропускаем &#RRGGBB
                    continue;
                } catch (NumberFormatException e) {
                    // Неверный HEX код - рендерим символ как есть
                    context.drawText(getFont(), String.valueOf(c), currentX, y, currentColor, false);
                    currentX += getFont().getWidth(String.valueOf(c));
                }
            }
            // Проверяем цветовой код §
            else if (c == '§' && i + 1 < text.length()) {
                char nextChar = text.charAt(i + 1);
                
                // Проверяем HEX цвет (§#RRGGBB)
                if (nextChar == '#' && i + 7 < text.length()) {
                    String hexCode = text.substring(i + 2, i + 8);
                    try {
                        int rgb = Integer.parseInt(hexCode, 16);
                        currentColor = 0xFF000000 | rgb; // Добавляем альфа-канал
                        i += 7; // Пропускаем §#RRGGBB
                        continue;
                    } catch (NumberFormatException e) {
                        // Неверный HEX код - игнорируем
                    }
                }
                
                // Обычный код цвета (§0-f, §r)
                currentColor = getMinecraftColor(nextChar);
                i++; // Пропускаем код цвета
            } else {
                // Обычный символ - рендерим с текущим цветом
                context.drawText(getFont(), String.valueOf(c), currentX, y, currentColor, false);
                currentX += getFont().getWidth(String.valueOf(c));
            }
        }
        
        return currentX;
    }
    
    /**
     * Преобразует код цвета Minecraft в RGB
     */
    private int getMinecraftColor(char code) {
        switch (code) {
            case '0': return 0xFF000000; // Черный
            case '1': return 0xFF0000AA; // Темно-синий
            case '2': return 0xFF00AA00; // Темно-зеленый
            case '3': return 0xFF00AAAA; // Темно-голубой
            case '4': return 0xFFAA0000; // Темно-красный
            case '5': return 0xFFAA00AA; // Темно-фиолетовый
            case '6': return 0xFFFFAA00; // Золотой
            case '7': return 0xFFAAAAAA; // Серый
            case '8': return 0xFF555555; // Темно-серый
            case '9': return 0xFF5555FF; // Синий
            case 'a': return 0xFF55FF55; // Зеленый
            case 'b': return 0xFF55FFFF; // Голубой
            case 'c': return 0xFFFF5555; // Красный
            case 'd': return 0xFFFF55FF; // Светло-фиолетовый
            case 'e': return 0xFFFFFF55; // Желтый
            case 'f': return 0xFFFFFFFF; // Белый
            case 'r': return COLOR_TEXT_PRIMARY; // Сброс
            default: return COLOR_TEXT_PRIMARY;
        }
    }
    
    /**
     * Извлекает никнейм из сообщения чата
     */
    private String extractUsername(String rawText) {
        try {
            // Формат: [ранг] [префикс] никнейм » сообщение
            String[] parts = rawText.split(" » ");
            if (parts.length < 2) {
                return null;
            }
            
            String beforeMessage = parts[0];
            String[] beforeParts = beforeMessage.split(" ");
            if (beforeParts.length == 0) {
                return null;
            }
            
            String username = beforeParts[beforeParts.length - 1];
            username = username.replaceAll("[^A-Za-z0-9_]", "");
            
            if (username.isEmpty() || username.length() < 3 || username.length() > 16) {
                return null;
            }
            
            return username;
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Рендерит список причин наказаний (СО СКРОЛЛОМ) - СКРУГЛЕННЫЙ
     */
    private void renderRulesList(DrawContext context, int x, int y, int width, int height, int mouseX, int mouseY) {
        // Заголовок УДАЛЕН (было: "Выберите причину мута/бана/IP-бана")
        
        // Фон списка - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, x, y, width, height, 10, COLOR_BG_CARD());
        
        // Границы - СКРУГЛЕННЫЕ (ТОНКАЯ рамка, как у автодополнения)
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 10, COLOR_ACCENT());
        
        // Включаем scissor для обрезки контента с учетом скруглений
        com.whiterise.adminpanel.util.RenderUtils.enableRoundedScissor(context, x, y, width, height, 10);
        
        int itemY = y + 5 - rulesScrollOffset; // Применяем скролл
        int itemHeight = 22;
        int separatorHeight = 10; // Высота разделителя
        
        for (PunishmentRule rule : currentRules) {
            // Если это разделитель
            if (rule.isSeparator()) {
                if (itemY + separatorHeight >= y && itemY < y + height) {
                    // Рисуем разделительную линию
                    int lineY = itemY + separatorHeight / 2;
                    context.fill(x + 10, lineY, x + width - 10, lineY + 2, 0xFF8D00C8); // Цвет акцента
                }
                itemY += separatorHeight;
                continue;
            }
            
            // Рендерим только видимые элементы
            if (itemY + itemHeight >= y && itemY < y + height) {
                // Проверка hover
                boolean isHovered = mouseX >= x && mouseX <= x + width && 
                                   mouseY >= itemY && mouseY <= itemY + itemHeight &&
                                   mouseY >= y && mouseY < y + height; // Только внутри области
                
                // Фон элемента - СКРУГЛЕННЫЙ
                if (isHovered) {
                    RenderUtils.fillRounded(context, x + 2, itemY, width - 4, itemHeight, 6, COLOR_BG_HOVER());
                }
                
                // Код правила (слева)
                context.drawText(getFont(), rule.getCode(), x + 10, itemY + 7, COLOR_ACCENT(), true);
                
                // Причина (по центру, УВЕЛИЧЕНА длина до 150)
                String reason = rule.getReason();
                if (getFont().getWidth(reason) > 150) {
                    reason = getFont().trimToWidth(reason, 150) + "...";
                }
                context.drawText(getFont(), reason, x + 60, itemY + 7, COLOR_TEXT_PRIMARY, false);
                
                // Длительность (справа)
                String duration = rule.getDisplayDuration();
                int durationWidth = getFont().getWidth(duration);
                context.drawText(getFont(), duration, x + width - durationWidth - 10, itemY + 7, COLOR_TEXT_MUTED, false);
                
                // Разделитель убран для чистого вида
            }
            
            itemY += itemHeight;
        }
        
        // Отключаем scissor
        context.disableScissor();
    }
    
    /**
     * Рендерит выбор времени для читов (14d или 21d) - СКРУГЛЕННЫЙ
     */
    private void renderDurationChoice(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        // Заголовок
        context.drawText(getFont(), "Выберите срок бана:", x, y - 20, COLOR_TEXT_SECONDARY, false);
        
        // Фон - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, x, y, width, 100, 10, COLOR_BG_CARD());
        
        // Границы - СКРУГЛЕННЫЕ
        RenderUtils.drawRoundedBorder(context, x, y, width, 100, 10, COLOR_BORDER());
        
        int buttonWidth = 120;
        int buttonHeight = 35;
        int buttonSpacing = 10;
        int buttonX = x + (width - buttonWidth) / 2;
        int buttonY = y + 15;
        
        // Кнопка 14d
        boolean hover14 = mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                         mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover14 && !was14dButtonHovered) {
            SoundManager.playHoverSound();
        }
        was14dButtonHovered = hover14;
        renderButton(context, buttonX, buttonY, buttonWidth, buttonHeight, "14 дней",
                     hover14 ? adjustBrightness(COLOR_WARNING_FIXED, 1.15f) : COLOR_WARNING_FIXED, hover14);
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 21d
        boolean hover21 = mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                         mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover21 && !was21dButtonHovered) {
            SoundManager.playHoverSound();
        }
        was21dButtonHovered = hover21;
        renderButton(context, buttonX, buttonY, buttonWidth, buttonHeight, "21 день",
                     hover21 ? adjustBrightness(COLOR_DANGER_FIXED, 1.15f) : COLOR_DANGER_FIXED, hover21);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // ПКМ по полю поиска - очистить
        if (button == 1) { // ПКМ
            // Поле поиска в чате (ConsoleScreen)
            int dividerX = 320;
            int searchX = dividerX + 20;
            int searchY = 70;
            int searchWidth = this.width - dividerX - 40;
            int searchHeight = 25;
            
            if (mouseX >= searchX && mouseX <= searchX + searchWidth && 
                mouseY >= searchY && mouseY <= searchY + searchHeight) {
                searchField.setText("");
                SoundManager.playClickSound();
                return true;
            }
            
            // Поле никнейма (ConsoleScreen)
            int fieldX = 30;
            int fieldY = 70;
            int fieldWidth = 250;
            int fieldHeight = 30;
            
            if (mouseX >= fieldX && mouseX <= fieldX + fieldWidth && 
                mouseY >= fieldY && mouseY <= fieldY + fieldHeight) {
                nicknameField.setText("");
                SoundManager.playClickSound();
                return true;
            }
            
            return super.mouseClicked(mouseX, mouseY, button);
        }
        
        // Только ЛКМ обрабатываем дальше
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        
        // 0. ПРИОРИТЕТ: Клик по верхней панели навигации
        if (handleTopBarClick(mouseX, mouseY)) {
            return true;
        }
        
        // 1. ПРИОРИТЕТ: Клик по автодополнению
        if (!autocompleteSuggestions.isEmpty() && nicknameField.isFocused()) {
            if (handleAutocompleteClick(mouseX, mouseY)) {
                return true;
            }
        }
        
        // 2. Клик по выбору времени для читов (если открыт)
        if (selectedRule != null && selectedRule.getCode().equals("2.4")) {
            if (handleDurationChoiceClick(mouseX, mouseY)) {
                return true;
            }
        }
        
        // 3. Клик по списку причин (если открыт)
        if (currentRules != null && !currentRules.isEmpty()) {
            int x = 30;
            int y = 260; // Было 310, подняли на 50px
            int width = 260;
            int height = this.height - 300; // Было 350, подняли на 50px
            
            if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height) {
                int itemY = y + 5 - rulesScrollOffset;
                int itemHeight = 22;
                int separatorHeight = 10;
                
                for (PunishmentRule rule : currentRules) {
                    // Пропускаем разделители
                    if (rule.isSeparator()) {
                        itemY += separatorHeight;
                        continue;
                    }
                    
                    if (itemY + itemHeight >= y && itemY < y + height) {
                        if (mouseY >= itemY && mouseY <= itemY + itemHeight) {
                            SoundManager.playClickSound();
                            // Если это правило "Читы" - показываем выбор времени
                            if (rule.getCode().equals("2.4")) {
                                selectedRule = rule;
                                currentRules = null;
                            } else {
                                // Иначе сразу выполняем наказание
                                checkRealnameAndExecute(rule, rule.getDuration());
                            }
                            return true;
                        }
                    }
                    itemY += itemHeight;
                }
            }
        }
        
        // 4. Клик по кнопкам действий (Мут, Размут, Бан, Разбан, Проверка)
        if (handleButtonClick(mouseX, mouseY)) {
            return true;
        }
        
        // 5. Клик в чате - копировать никнейм в поле ввода
        // Проверяем что клик в области чата (справа от разделителя)
        int dividerX = 320;
        if (mouseX >= dividerX && handleChatLeftClick(mouseX, mouseY)) {
            return true;
        }
        
        // 6. НОВОЕ: Клик в пустое место - закрыть все доп окна и снять фокус
        if (handleEmptySpaceClick(mouseX, mouseY)) {
            return true;
        }
        
        // 7. Остальные клики (включая поле ввода) обрабатываются через super
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    /**
     * Обработка клика по верхней панели навигации
     */
    private boolean handleTopBarClick(double mouseX, double mouseY) {
        int barHeight = 50;
        
        // Проверяем что клик в области верхней панели
        if (mouseY < 0 || mouseY > barHeight) {
            return false;
        }
        
        int buttonWidth = 115; // Уменьшено для 7 кнопок
        int buttonHeight = 35;
        int buttonSpacing = 8; // Уменьшено для 7 кнопок
        int totalWidth = buttonWidth * 7 + buttonSpacing * 6; // 7 кнопок
        int startX = (this.width - totalWidth) / 2;
        int buttonY = (barHeight - buttonHeight) / 2;
        
        // Кнопка 1: Консоль (остаемся на текущем экране)
        int button1X = startX;
        if (mouseX >= button1X && mouseX <= button1X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            // Уже на экране консоли, ничего не делаем
            return true;
        }
        
        // Кнопка 2: Игроки
        int button2X = button1X + buttonWidth + buttonSpacing;
        if (mouseX >= button2X && mouseX <= button2X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            AdminPanelScreen screen = new AdminPanelScreen();
            screen.setCurrentTab("players");
            this.client.setScreen(screen);
            return true;
        }
        
        // Кнопка 3: Проверка
        int button3X = button2X + buttonWidth + buttonSpacing;
        if (mouseX >= button3X && mouseX <= button3X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            AdminPanelScreen screen = new AdminPanelScreen();
            screen.setCurrentTab("anticheat");
            this.client.setScreen(screen);
            return true;
        }
        
        // Кнопка 4: Выданные
        int button4X = button3X + buttonWidth + buttonSpacing;
        if (mouseX >= button4X && mouseX <= button4X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            AdminPanelScreen screen = new AdminPanelScreen();
            screen.setCurrentTab("issued");
            this.client.setScreen(screen);
            return true;
        }
        
        // Кнопка 5: Правила
        int button5X = button4X + buttonWidth + buttonSpacing;
        if (mouseX >= button5X && mouseX <= button5X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new RulesScreen(this));
            return true;
        }
        
        // Кнопка 6: Темы (НОВАЯ)
        int button6X = button5X + buttonWidth + buttonSpacing;
        if (mouseX >= button6X && mouseX <= button6X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new ThemeSettingsScreen(this));
            return true;
        }
        
        // Кнопка 7: Интерфейс
        int button7X = button6X + buttonWidth + buttonSpacing;
        if (mouseX >= button7X && mouseX <= button7X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new InterfaceScreen(this));
            return true;
        }
        
        return false;
    }
    
    /**
     * Обработка клика по автодополнению
     */
    private boolean handleAutocompleteClick(double mouseX, double mouseY) {
        int fieldX = 30;
        int fieldY = 70; // ИСПРАВЛЕНО: было 120, теперь 70 (синхронизировано с полем никнейма)
        int fieldWidth = 250;
        int fieldHeight = 30;
        
        int suggestionsX = fieldX;
        int suggestionsY = fieldY + fieldHeight + 2;
        int suggestionsWidth = fieldWidth;
        int itemHeight = 20;
        int maxVisible = Math.min(5, autocompleteSuggestions.size());
        int suggestionsHeight = maxVisible * itemHeight;
        
        // Проверяем клик внутри области автодополнения
        if (mouseX >= suggestionsX && mouseX <= suggestionsX + suggestionsWidth && 
            mouseY >= suggestionsY && mouseY < suggestionsY + suggestionsHeight) {
            
            // Определяем на какую подсказку кликнули
            int clickedIndex = (int) ((mouseY - suggestionsY) / itemHeight);
            
            if (clickedIndex >= 0 && clickedIndex < autocompleteSuggestions.size()) {
                String selectedNickname = autocompleteSuggestions.get(clickedIndex);
                nicknameField.setText(selectedNickname);
                autocompleteSuggestions.clear();
                selectedSuggestionIndex = -1;
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Обработка ЛКМ по чату (копирует никнейм в поле ввода И в буфер обмена)
     * ИСПРАВЛЕНО: берет никнейм ИМЕННО под курсором (по X и Y координатам)
     * Использует посимвольный анализ для точного определения позиции
     * НОВОЕ: Проверяет реальный никнейм через /realname перед копированием
     */
    private boolean handleChatLeftClick(double mouseX, double mouseY) {
        int dividerX = 320;
        int chatX = dividerX + 20;
        int chatY = 105; // ИСПРАВЛЕНО: чат начинается с Y=105 (синхронизировано с renderChatView)
        int chatWidth = this.width - dividerX - 40;
        int chatHeight = this.height - 145; // ИСПРАВЛЕНО: высота чата (синхронизировано с renderChatView)
        
        // Проверяем что клик внутри области чата
        if (mouseX < chatX || mouseX > chatX + chatWidth || 
            mouseY < chatY || mouseY > chatY + chatHeight) {
            return false;
        }
        
        var logs = AdminPanelClient.getChatLogManager().getAllLogs();
        if (logs.isEmpty()) return false;
        
        int lineY = chatY + 10 - chatScrollOffset;
        int lineHeight = 12;
        int textX = chatX + 10; // Начало текста
        
        // Ищем строку под курсором по Y
        for (var entry : logs) {
            // Проверяем что строка видима
            if (lineY >= chatY && lineY < chatY + chatHeight - 10) {
                // Проверяем что курсор на этой строке по Y
                if (mouseY >= lineY && mouseY < lineY + lineHeight) {
                    // Нашли строку! Теперь ищем слово под курсором по X
                    String timeString = entry.getTimeString();
                    String rawText = entry.getColoredText().getPlainText();
                    String username = findUsernameAtPosition(timeString, rawText, mouseX, textX);
                    
                    if (username != null && !username.isEmpty()) {
                        // Копируем никнейм в поле ввода
                        nicknameField.setText(username);
                        nicknameField.setFocused(true);
                        
                        // Копируем никнейм и в поле поиска
                        searchField.setText(username);
                        
                        // НОВОЕ: Проверяем реальный никнейм и копируем в буфер обмена
                        checkRealnameAndCopyToClipboard(username);
                        
                        // Визуальная обратная связь
                        if (this.client.player != null) {
                            this.client.player.sendMessage(Text.literal("§a✓ Никнейм скопирован: §f" + username), true);
                        }
                        
                        return true;
                    }
                    
                    // Если никнейм не найден, но клик был на строке - все равно возвращаем false
                    return false;
                }
            }
            
            lineY += lineHeight;
        }
        
        return false;
    }
    
    /**
     * Находит никнейм под курсором по X-координате
     * НОВЫЙ ПОДХОД: Посимвольный анализ для точного определения позиции каждого слова
     */
    private String findUsernameAtPosition(String timeString, String rawText, double mouseX, int textStartX) {
        // Формируем полную строку как она рендерится
        String fullLine = timeString + " " + rawText;
        
        // Очищаем от цветовых кодов для анализа
        String cleanedLine = fullLine.replaceAll("§.", "");
        
        // Вычисляем позицию каждого символа
        int currentX = textStartX;
        StringBuilder currentWord = new StringBuilder();
        int wordStartX = currentX;
        
        for (int i = 0; i < cleanedLine.length(); i++) {
            char c = cleanedLine.charAt(i);
            
            // Если пробел или спецсимвол - заканчиваем текущее слово
            if (c == ' ' || c == ':' || c == '»' || c == '>' || c == '-' || c == '[' || c == ']' || c == '!' || c == '(' || c == ')') {
                // Проверяем накопленное слово
                if (currentWord.length() > 0) {
                    String word = currentWord.toString();
                    int wordWidth = getFont().getWidth(word);
                    
                    // Проверяем попадает ли курсор на это слово
                    if (mouseX >= wordStartX && mouseX < wordStartX + wordWidth) {
                        // Очищаем слово от спецсимволов
                        String cleanWord = word.replaceAll("[^A-Za-z0-9_]", "");
                        
                        // Проверяем что это валидный никнейм
                        if (isValidNickname(cleanWord)) {
                            return cleanWord;
                        }
                    }
                    
                    // Сдвигаем позицию на ширину слова
                    currentX = wordStartX + wordWidth;
                    currentWord.setLength(0);
                }
                
                // Добавляем ширину разделителя
                currentX += getFont().getWidth(String.valueOf(c));
                wordStartX = currentX;
            } else {
                // Добавляем символ к текущему слову
                if (currentWord.length() == 0) {
                    wordStartX = currentX;
                }
                currentWord.append(c);
                // НЕ сдвигаем currentX здесь - сдвинем когда слово закончится
            }
        }
        
        // Проверяем последнее слово (если строка не заканчивается разделителем)
        if (currentWord.length() > 0) {
            String word = currentWord.toString();
            int wordWidth = getFont().getWidth(word);
            
            if (mouseX >= wordStartX && mouseX < wordStartX + wordWidth) {
                String cleanWord = word.replaceAll("[^A-Za-z0-9_]", "");
                if (isValidNickname(cleanWord)) {
                    return cleanWord;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Проверяет является ли строка валидным никнеймом Minecraft
     */
    private boolean isValidNickname(String name) {
        if (name == null || name.length() < 3 || name.length() > 16) {
            return false;
        }
        
        // Только буквы, цифры и подчеркивание
        if (!name.matches("^[A-Za-z0-9_]+$")) {
            return false;
        }
        
        // Исключаем системные слова
        String upper = name.toUpperCase();
        if (upper.equals("HELPER") || upper.equals("ADMIN") || upper.equals("MODER") || 
            upper.equals("MOD") || upper.equals("VIP") || upper.equals("MVP") || 
            upper.equals("OWNER") || upper.equals("BUILDER") || upper.equals("STAFF") ||
            upper.equals("SERVER") || upper.equals("PLAYER") || upper.equals("GAME") ||
            upper.equals("CHAT") || upper.equals("INFO") || upper.equals("WARNING") ||
            upper.equals("ERROR") || upper.equals("SYSTEM") || upper.equals("CONSOLE")) {
            return false;
        }
        
        return true;
    }
    

    /**
     * Обработка кликов по кнопкам действий
     */
    private boolean handleButtonClick(double mouseX, double mouseY) {
        int buttonY = 110; // Было 160, подняли на 50px
        int buttonWidth = 120;
        int buttonHeight = 30;
        int buttonSpacing = 10;
        
        // Кнопка Мут
        if (mouseX >= 30 && mouseX <= 30 + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            selectedAction = "mute";
            currentRules = PunishmentRule.getMuteRules();
            selectedRule = null;
            return true;
        }
        
        // Кнопка Размут
        if (mouseX >= 30 + buttonWidth + buttonSpacing && 
            mouseX <= 30 + buttonWidth * 2 + buttonSpacing && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            selectedAction = "unmute";
            checkRealnameAndExecuteUnmute();
            return true;
        }
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка Бан
        if (mouseX >= 30 && mouseX <= 30 + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            selectedAction = "ban";
            currentRules = PunishmentRule.getBanRules();
            selectedRule = null;
            return true;
        }
        
        // Кнопка Разбан
        if (mouseX >= 30 + buttonWidth + buttonSpacing && 
            mouseX <= 30 + buttonWidth * 2 + buttonSpacing && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            selectedAction = "unban";
            checkRealnameAndExecuteUnban();
            return true;
        }
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка Бан по IP
        int ipBanButtonWidth = 250;
        if (mouseX >= 30 && mouseX <= 30 + ipBanButtonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            selectedAction = "ipban";
            currentRules = PunishmentRule.getIPBanRules();
            selectedRule = null;
            return true;
        }
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка Проверка мута
        int checkMuteButtonWidth = 250;
        if (mouseX >= 30 && mouseX <= 30 + checkMuteButtonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            executeCheckMute();
            return true;
        }
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка Проверка никнейма (СКРЫВАЕМ если открыт список причин или выбор времени)
        if (currentRules == null && selectedRule == null) {
            int checkButtonWidth = 250;
            if (mouseX >= 30 && mouseX <= 30 + checkButtonWidth && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                SoundManager.playClickSound();
                executeRealnameCheck();
                return true;
            }
            
            buttonY += buttonHeight + buttonSpacing;
        }
        
        // Клик по кнопке копирования никнейма в результатах (только если НЕТ списка причин и выбора времени)
        if (currentRules == null && selectedRule == null && savedRealNickname != null && !savedRealNickname.isEmpty()) {
            // СИНХРОНИЗИРОВАНО С renderResultBox
            int resultBoxX = 30;
            int resultBoxY = buttonY;
            int resultBoxWidth = 250;
            int resultBoxHeight = this.height - resultBoxY - 60;
            int copyButtonY = resultBoxY + resultBoxHeight - 40; // Опущено на 15px ниже (было -55)
            int copyButtonWidth = resultBoxWidth - 20; // 230
            int copyButtonHeight = 25;
            int copyButtonX = resultBoxX + 10; // 40
            
            if (mouseX >= copyButtonX && mouseX <= copyButtonX + copyButtonWidth && 
                mouseY >= copyButtonY && mouseY <= copyButtonY + copyButtonHeight) {
                SoundManager.playClickSound();
                // Копируем никнейм в поле ввода
                nicknameField.setText(savedRealNickname);
                nicknameField.setFocused(true);
                
                // Визуальная обратная связь
                if (this.client.player != null) {
                    this.client.player.sendMessage(Text.literal("§a✓ Никнейм скопирован: §f" + savedRealNickname), true);
                }
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Обработка клика по выбору времени для читов
     */
    private boolean handleDurationChoiceClick(double mouseX, double mouseY) {
        int x = 30;
        int y = 260; // Было 310, подняли на 50px
        int width = 260;
        
        int buttonWidth = 120;
        int buttonHeight = 35;
        int buttonSpacing = 10;
        int buttonX = x + (width - buttonWidth) / 2;
        int buttonY = y + 15;
        
        // Кнопка 14d
        if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            checkRealnameAndExecute(selectedRule, "14d");
            selectedRule = null;
            return true;
        }
        
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 21d
        if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            checkRealnameAndExecute(selectedRule, "21d");
            selectedRule = null;
            return true;
        }
        
        return false;
    }
    
    /**
     * Обработка клика в пустое место
     * Закрывает все доп окна и снимает фокус с полей ввода
     */
    private boolean handleEmptySpaceClick(double mouseX, double mouseY) {
        // Определяем все интерактивные области
        boolean clickedOnInteractive = false;
        
        // 1. Поле ввода никнейма
        int nicknameFieldX = 30;
        int nicknameFieldY = 70; // ИСПРАВЛЕНО: было 80, теперь 70
        int nicknameFieldWidth = 250;
        int nicknameFieldHeight = 30;
        if (mouseX >= nicknameFieldX && mouseX <= nicknameFieldX + nicknameFieldWidth && 
            mouseY >= nicknameFieldY && mouseY <= nicknameFieldY + nicknameFieldHeight) {
            clickedOnInteractive = true;
        }
        
        // 2. Поле поиска
        int dividerX = 320;
        int searchFieldX = dividerX + 20;
        int searchFieldY = 70; // ИСПРАВЛЕНО: было 55, теперь 70 (синхронизировано с init и renderSearchField)
        int searchFieldWidth = this.width - dividerX - 40;
        int searchFieldHeight = 25;
        if (mouseX >= searchFieldX && mouseX <= searchFieldX + searchFieldWidth && 
            mouseY >= searchFieldY && mouseY <= searchFieldY + searchFieldHeight) {
            clickedOnInteractive = true;
        }
        
        // 3. Кнопки действий (Мут, Размут, Бан, Разбан, IP-Бан, Проверка мута, Проверка никнейма)
        int buttonY = 120;
        int buttonWidth = 120;
        int buttonHeight = 30;
        int buttonSpacing = 10;
        
        // Проверяем все кнопки (7 рядов)
        for (int i = 0; i < 7; i++) {
            int currentButtonWidth = (i == 2 || i == 3 || i == 4) ? 250 : buttonWidth; // IP-Бан, Проверка мута, Проверка никнейма шире
            
            if (mouseX >= 30 && mouseX <= 30 + currentButtonWidth && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                clickedOnInteractive = true;
                break;
            }
            
            // Вторая кнопка в ряду (только для первых двух рядов)
            if (i < 2) {
                if (mouseX >= 30 + buttonWidth + buttonSpacing && 
                    mouseX <= 30 + buttonWidth * 2 + buttonSpacing && 
                    mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                    clickedOnInteractive = true;
                    break;
                }
            }
            
            buttonY += buttonHeight + buttonSpacing;
        }
        
        // 4. Чат (справа)
        int chatX = dividerX + 20;
        int chatY = 90;
        int chatWidth = this.width - dividerX - 40;
        int chatHeight = this.height - 150;
        if (mouseX >= chatX && mouseX <= chatX + chatWidth && 
            mouseY >= chatY && mouseY <= chatY + chatHeight) {
            clickedOnInteractive = true;
        }
        
        // 5. Список причин (если открыт)
        if (currentRules != null && !currentRules.isEmpty()) {
            int rulesX = 30;
            int rulesY = 270;
            int rulesWidth = 260;
            int rulesHeight = this.height - 330;
            if (mouseX >= rulesX && mouseX <= rulesX + rulesWidth && 
                mouseY >= rulesY && mouseY <= rulesY + rulesHeight) {
                clickedOnInteractive = true;
            }
        }
        
        // 6. Выбор времени для читов (если открыт)
        if (selectedRule != null && selectedRule.getCode().equals("2.4")) {
            int durationX = 30;
            int durationY = 270;
            int durationWidth = 260;
            int durationHeight = 100;
            if (mouseX >= durationX && mouseX <= durationX + durationWidth && 
                mouseY >= durationY && mouseY <= durationY + durationHeight) {
                clickedOnInteractive = true;
            }
        }
        
        // 7. Поле результатов (если есть кнопка копирования)
        if (savedRealNickname != null && !savedRealNickname.isEmpty() && 
            currentRules == null && selectedRule == null) {
            int resultBoxY = 270;
            int resultBoxHeight = this.height - resultBoxY - 60;
            int copyButtonY = resultBoxY + resultBoxHeight - 40;
            int copyButtonWidth = 230;
            int copyButtonHeight = 25;
            int copyButtonX = 40;
            
            if (mouseX >= copyButtonX && mouseX <= copyButtonX + copyButtonWidth && 
                mouseY >= copyButtonY && mouseY <= copyButtonY + copyButtonHeight) {
                clickedOnInteractive = true;
            }
        }
        
        // 8. Автодополнение (если открыто)
        if (!autocompleteSuggestions.isEmpty() && nicknameField.isFocused()) {
            int suggestionsX = nicknameFieldX;
            int suggestionsY = nicknameFieldY + nicknameFieldHeight + 2;
            int suggestionsWidth = nicknameFieldWidth;
            int maxVisible = Math.min(5, autocompleteSuggestions.size());
            int suggestionsHeight = maxVisible * 20;
            
            if (mouseX >= suggestionsX && mouseX <= suggestionsX + suggestionsWidth && 
                mouseY >= suggestionsY && mouseY < suggestionsY + suggestionsHeight) {
                clickedOnInteractive = true;
            }
        }
        
        // Если клик НЕ на интерактивной области - закрываем все
        if (!clickedOnInteractive) {
            // Закрываем список причин
            if (currentRules != null) {
                currentRules = null;
                selectedAction = "";
            }
            
            // Закрываем выбор времени
            if (selectedRule != null) {
                selectedRule = null;
            }
            
            // Снимаем фокус с полей ввода
            if (nicknameField.isFocused()) {
                nicknameField.setFocused(false);
            }
            if (searchField.isFocused()) {
                searchField.setFocused(false);
            }
            
            // Закрываем автодополнение
            if (!autocompleteSuggestions.isEmpty()) {
                autocompleteSuggestions.clear();
                selectedSuggestionIndex = -1;
            }
            
            return true;
        }
        
        return false;
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // ESC закрывает весь GUI
        if (keyCode == 256) { // 256 = ESC
            this.close();
            return true;
        }
        
        // Навигация по автодополнению стрелками
        if (!autocompleteSuggestions.isEmpty() && nicknameField.isFocused()) {
            // Стрелка вниз (264)
            if (keyCode == 264) {
                selectedSuggestionIndex++;
                if (selectedSuggestionIndex >= autocompleteSuggestions.size()) {
                    selectedSuggestionIndex = 0;
                }
                return true;
            }
            
            // Стрелка вверх (265)
            if (keyCode == 265) {
                selectedSuggestionIndex--;
                if (selectedSuggestionIndex < 0) {
                    selectedSuggestionIndex = autocompleteSuggestions.size() - 1;
                }
                return true;
            }
            
            // Enter (257) или Tab (258) - выбрать подсказку
            if ((keyCode == 257 || keyCode == 258) && selectedSuggestionIndex >= 0 && 
                selectedSuggestionIndex < autocompleteSuggestions.size()) {
                String selectedNickname = autocompleteSuggestions.get(selectedSuggestionIndex);
                nicknameField.setText(selectedNickname);
                nicknameField.setCursorToEnd(true);
                autocompleteSuggestions.clear();
                selectedSuggestionIndex = -1;
                return true;
            }
        }
        
        // Передаем нажатия клавиш в поле поиска
        if (searchField.isFocused() && searchField.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        
        // Передаем нажатия клавиш в поле ввода
        if (nicknameField.isFocused() && nicknameField.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean charTyped(char chr, int modifiers) {
        // Передаем символы в поле поиска
        if (searchField.isFocused() && searchField.charTyped(chr, modifiers)) {
            return true;
        }
        
        // Передаем символы в поле ввода
        if (nicknameField.isFocused() && nicknameField.charTyped(chr, modifiers)) {
            return true;
        }
        
        return super.charTyped(chr, modifiers);
    }
    
    @Override
    public void tick() {
        // Обновляем поле ввода (для мигания курсора)
        if (nicknameField != null) {
            // nicknameField.tick(); // Removed in 1.21.4
            
            // Обновляем автодополнение при изменении текста
            updateAutocompleteSuggestions();
        }
        
        // Обновляем поле поиска
        if (searchField != null) {
            // searchField.tick(); // Removed in 1.21.4
        }
        
        super.tick();
    }
    
    /**
     * Обновляет список подсказок автодополнения на основе введенного текста
     */
    private void updateAutocompleteSuggestions() {
        String input = nicknameField.getText().trim().toLowerCase();
        
        // Если поле пустое или не в фокусе - очищаем подсказки
        if (input.isEmpty() || !nicknameField.isFocused()) {
            autocompleteSuggestions.clear();
            selectedSuggestionIndex = -1;
            return;
        }
        
        // Получаем список онлайн игроков
        if (this.client.getNetworkHandler() == null) {
            autocompleteSuggestions.clear();
            return;
        }
        
        Collection<PlayerListEntry> playerList = this.client.getNetworkHandler().getPlayerList();
        
        // Фильтруем игроков по введенному тексту
        autocompleteSuggestions = playerList.stream()
            .map(entry -> entry.getProfile().getName())
            .filter(name -> name.toLowerCase().startsWith(input))
            .sorted()
            .limit(10) // Максимум 10 подсказок
            .collect(Collectors.toList());
        
        // Сбрасываем выбранный индекс если список изменился
        if (selectedSuggestionIndex >= autocompleteSuggestions.size()) {
            selectedSuggestionIndex = -1;
        }
    }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        // Скролл списка причин (ПРИОРИТЕТ)
        if (currentRules != null && !currentRules.isEmpty()) {
            int x = 30;
            int y = 270;
            int width = 260;
            int height = this.height - 330;
            
            if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height) {
                rulesScrollOffset -= (int) (verticalAmount * 15);
                
                // Ограничиваем скролл
                int totalHeight = currentRules.size() * 22;
                int maxScroll = Math.max(0, totalHeight - height + 10);
                
                if (rulesScrollOffset < 0) rulesScrollOffset = 0;
                if (rulesScrollOffset > maxScroll) rulesScrollOffset = maxScroll;
                
                return true;
            }
        }
        
        // Скролл чата
        int dividerX = 320;
        if (mouseX >= dividerX + 20) {
            // Проверяем нажат ли Shift для горизонтального скролла
            boolean shiftPressed = net.minecraft.client.gui.screen.Screen.hasShiftDown();
            
            if (shiftPressed) {
                // Горизонтальный скролл
                chatHorizontalScrollOffset -= (int) (verticalAmount * 20);
                if (chatHorizontalScrollOffset < 0) chatHorizontalScrollOffset = 0;
                
                // Вычисляем максимальную ширину контента
                int maxContentWidth = 0;
                for (var cached : cachedChatLines) {
                    ChatLogEntry entry = cached.entry;
                    int lineWidth = getFont().getWidth(entry.getTimeString() + " " + entry.getColoredText().getPlainText());
                    maxContentWidth = Math.max(maxContentWidth, lineWidth);
                }
                
                int chatWidth = this.width - dividerX - 40;
                int visibleWidth = chatWidth - 30; // Учитываем отступы
                int maxHScroll = Math.max(0, maxContentWidth - visibleWidth);
                if (chatHorizontalScrollOffset > maxHScroll) chatHorizontalScrollOffset = maxHScroll;
            } else {
                // Вертикальный скролл
                chatScrollOffset -= (int) (verticalAmount * 15);
                if (chatScrollOffset < 0) chatScrollOffset = 0;
                
                // Ограничиваем максимальный скролл
                int chatHeight = this.height - 145;
                int lineHeight = 12;
                int totalLines = cachedChatLines.size();
                int visibleLines = chatHeight / lineHeight;
                int maxChatScroll = Math.max(0, (totalLines - visibleLines) * lineHeight);
                if (chatScrollOffset > maxChatScroll) chatScrollOffset = maxChatScroll;
            }
            
            return true;
        }
        
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
    
    /**
     * Выполняет проверку никнейма через /realname
     */
    private void executeRealnameCheck() {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            if (this.client.player != null) {
                this.client.player.sendMessage(Text.literal("§c✗ Введите никнейм"), true);
            }
            savedResultMessage = "Ошибка: Введите никнейм";
            savedRealNickname = null;
            return;
        }
        
        // Отправляем команду /realname
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage("/realname " + nickname);
            this.client.player.sendMessage(Text.literal("§e⏳ Проверка никнейма..."), true);
        }
        
        savedResultMessage = "Проверка никнейма: " + nickname;
        savedRealNickname = nickname;
        waitingForRealname = true;
    }
    
    /**
     * Выполняет проверку мута через /checkmute
     */
    private void executeCheckMute() {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            if (this.client.player != null) {
                this.client.player.sendMessage(Text.literal("§c✗ Введите никнейм"), true);
            }
            savedResultMessage = "Ошибка: Введите никнейм";
            savedRealNickname = null;
            return;
        }
        
        // Отправляем команду /checkmute
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage("/checkmute " + nickname);
            this.client.player.sendMessage(Text.literal("§e⏳ Проверка мута..."), true);
        }
        
        // Ждем 500ms для получения ответа, затем парсим результат
        new Thread(() -> {
            try {
                Thread.sleep(500);
                
                // Парсим ответ на главном потоке
                this.client.execute(() -> {
                    String result = parseCheckMuteResponse(nickname);
                    savedResultMessage = result;
                    savedRealNickname = nickname;
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
        
        savedResultMessage = "Проверка мута: " + nickname + "\n⏳ Загрузка...";
        savedRealNickname = nickname;
    }
    
    /**
     * Проверяет никнейм и выполняет наказание
     */
    private void checkRealnameAndExecute(PunishmentRule rule, String duration) {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            if (this.client.player != null) {
                this.client.player.sendMessage(Text.literal("§c✗ Введите никнейм"), true);
            }
            return;
        }
        
        // Отправляем /realname для проверки
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage("/realname " + nickname);
        }
        
        // Ждем 500ms для получения ответа, затем выполняем наказание
        new Thread(() -> {
            try {
                Thread.sleep(500);
                
                // Выполняем наказание на главном потоке
                this.client.execute(() -> {
                    executePunishmentWithRealname(rule, duration, nickname);
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    /**
     * Выполняет наказание с учетом реального никнейма
     */
    private void executePunishmentWithRealname(PunishmentRule rule, String duration, String originalNickname) {
        // Проверяем последние сообщения чата на наличие ответа от /realname
        String targetNickname = parseRealnameFromChat(originalNickname);
        
        if (targetNickname == null) {
            targetNickname = originalNickname; // Используем оригинальный если не нашли
        }
        
        // Формируем команду
        String command;
        String actionName = "";
        if (selectedAction.equals("mute")) {
            command = String.format("/tempmute %s %s %s", targetNickname, duration, rule.getCode());
            actionName = "Мут";
        } else if (selectedAction.equals("ban")) {
            command = String.format("/ban %s %s %s", targetNickname, duration, rule.getCode());
            actionName = "Бан";
        } else if (selectedAction.equals("ipban")) {
            // Для IP-бана: если duration = "999d" (навсегда), не указываем время
            if (duration.equals("999d")) {
                command = String.format("/banip %s %s", targetNickname, rule.getCode());
            } else {
                command = String.format("/banip %s %s %s", targetNickname, duration, rule.getCode());
            }
            actionName = "IP-Бан";
        } else {
            return;
        }
        
        // Отправляем команду на сервер
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage(command);
            
            // ClientCommandMixin автоматически отслеживает команду
            
            // Показываем уведомление
            if (!targetNickname.equals(originalNickname)) {
                this.client.player.sendMessage(
                    Text.literal(String.format("§a✓ Наказание выдано: §f%s §7(оригинал: §f%s§7)", 
                        targetNickname, originalNickname)), 
                    true
                );
            }
        }
        
        // Выводим результат (СОХРАНЯЕМ в статическую переменную)
        savedResultMessage = String.format("%s выдан игроку %s на %s за %s (%s)", 
            actionName, targetNickname, duration, rule.getCode(), rule.getReason());
        savedRealNickname = targetNickname;
        
        // ПРИМЕЧАНИЕ: Добавление в список выданных наказаний происходит автоматически
        // через ClientCommandMixin, который перехватывает отправку команды
        
        // МАШИННОЕ ОБУЧЕНИЕ: обучаемся на выданном муте
        if (selectedAction.equals("mute")) {
            com.whiterise.adminpanel.data.ViolationLearner.learnFromMute(targetNickname, rule.getCode());
        }
        
        // Закрываем список причин
        currentRules = null;
        selectedAction = "";
        selectedRule = null;
    }
    
    /**
     * Парсит ответ от /realname из чата
     * Формат: "c4shd4my это player222"
     */
    private String parseRealnameFromChat(String fakeNickname) {
        var logs = AdminPanelClient.getChatLogManager().getAllLogs();
        
        // Проверяем последние 5 сообщений
        int count = 0;
        for (var entry : logs) {
            if (count++ >= 5) break;
            
            String rawText = entry.getColoredText().getPlainText();
            
            // Ищем паттерн: "фейк_ник это оригинал_ник"
            if (rawText.contains(fakeNickname) && rawText.contains(" это ")) {
                String[] parts = rawText.split(" это ");
                if (parts.length == 2) {
                    String realNick = parts[1].trim();
                    // Очищаем от цветовых кодов и спецсимволов
                    realNick = realNick.replaceAll("§.", "");
                    realNick = realNick.replaceAll("[^A-Za-z0-9_]", "");
                    
                    if (isValidNickname(realNick)) {
                        return realNick;
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * Проверяет реальный никнейм через /realname и копирует в буфер обмена
     * Если реальный никнейм не найден - копирует исходный
     */
    private void checkRealnameAndCopyToClipboard(String nickname) {
        // Отправляем /realname для проверки
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage("/realname " + nickname);
        }
        
        // Ждем 500ms для получения ответа, затем копируем в буфер обмена
        new Thread(() -> {
            try {
                Thread.sleep(500);
                
                // Парсим ответ на главном потоке
                this.client.execute(() -> {
                    String realNickname = parseRealnameFromChat(nickname);
                    
                    // Если нашли реальный никнейм - копируем его, иначе копируем исходный
                    String nicknameToCopy = (realNickname != null) ? realNickname : nickname;
                    
                    // Копируем в буфер обмена
                    if (this.client != null && this.client.keyboard != null) {
                        this.client.keyboard.setClipboard(nicknameToCopy);
                    }
                    
                    // Обновляем уведомление если нашли реальный никнейм
                    if (realNickname != null && !realNickname.equals(nickname)) {
                        if (this.client.player != null) {
                            this.client.player.sendMessage(
                                Text.literal("§a✓ Реальный никнейм: §f" + realNickname + " §7(было: " + nickname + ")"), 
                                true
                            );
                        }
                    }
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    /**
     * Очищает текст от специальных символов и форматирования Minecraft
     */
    private String cleanText(String text) {
        if (text == null) return null;
        
        // Убираем цветовые коды Minecraft (§x)
        text = text.replaceAll("§.", "");
        
        // Убираем ВСЕ непечатные и специальные символы Unicode
        // Оставляем только: буквы, цифры, пробелы, точки, двоеточия, дефисы, слеши
        text = text.replaceAll("[^\\p{L}\\p{N}\\s.:\\-/]", "");
        
        // Убираем множественные пробелы
        text = text.replaceAll("\\s+", " ");
        
        return text.trim();
    }
    
    /**
     * Парсит ответ от /checkmute из чата
     * 
     * Новый формат (многострочный):
     * ☄ История наказания [WhiteRise]
     * 
     *     ● Наказуемый: carrion666
     * Наказавший: clownuxk
     * Причина наказания: 3.2.1
     * Выдано: 30.01.26 01:22:56
     * 
     *     ● Окончание через: 30.01.26 02:22:56
     * Блокировка по айпи: Нет
     * Блокировка навсегда: Нет
     * 
     * Формат "нет мута":
     * "[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но данный игрок НИКНЕЙМ не имеет блокировок чата"
     * 
     * Старый формат (одна строка):
     * "Проверка мута: НИКНЕЙМ ☐☐☐☑ Игрок НЕ замучен"
     */
    private String parseCheckMuteResponse(String nickname) {
        var logs = AdminPanelClient.getChatLogManager().getAllLogs();
        
        // Ищем в последних 30 строках
        java.util.List<String> recentLogs = new java.util.ArrayList<>();
        int count = 0;
        for (var entry : logs) {
            if (count++ >= 30) break;
            recentLogs.add(entry.getColoredText().getPlainText());
        }
        
        // Разворачиваем список чтобы идти от старых к новым
        java.util.Collections.reverse(recentLogs);
        
        // Ищем "История наказания" или "не имеет блокировок"
        int historyIndex = -1;
        int noMuteIndex = -1;
        
        for (int i = 0; i < recentLogs.size(); i++) {
            String text = recentLogs.get(i);
            if (text.contains("История наказания")) {
                historyIndex = i;
            }
            if (text.contains("не имеет блокировок")) {
                noMuteIndex = i;
            }
        }
        
        // ПРИОРИТЕТ: если есть "не имеет блокировок" И он ПОСЛЕ истории - игрок не замучен
        if (noMuteIndex > historyIndex) {
            return "✅ НЕ ЗАМУЧЕН\nЧат доступен";
        }
        
        // Если нашли историю наказания - парсим данные
        if (historyIndex >= 0) {
            String punishedPlayer = null;
            String punisher = null;
            String reason = null;
            String expiresDate = null;
            String issuedDate = null;
            
            // Парсим следующие 10 строк после "История наказания"
            for (int i = historyIndex + 1; i < Math.min(historyIndex + 11, recentLogs.size()); i++) {
                String text = recentLogs.get(i);
                
                if (text.contains("Наказуемый:")) {
                    int idx = text.indexOf("Наказуемый:");
                    punishedPlayer = cleanText(text.substring(idx + "Наказуемый:".length()));
                }
                else if (text.contains("Наказавший:")) {
                    int idx = text.indexOf("Наказавший:");
                    punisher = cleanText(text.substring(idx + "Наказавший:".length()));
                }
                else if (text.contains("Причина наказания:")) {
                    int idx = text.indexOf("Причина наказания:");
                    reason = cleanText(text.substring(idx + "Причина наказания:".length()));
                }
                else if (text.contains("Выдано:")) {
                    int idx = text.indexOf("Выдано:");
                    issuedDate = cleanText(text.substring(idx + "Выдано:".length()));
                }
                else if (text.contains("Окончание через:")) {
                    int idx = text.indexOf("Окончание через:");
                    expiresDate = cleanText(text.substring(idx + "Окончание через:".length()));
                }
            }
            
            // Если нашли данные - показываем мут
            if (punishedPlayer != null) {
                StringBuilder result = new StringBuilder();
                result.append("❌ ЗАМУЧЕН\n");
                
                if (punisher != null) {
                    result.append("Выдал: ").append(punisher).append("\n");
                }
                
                if (reason != null) {
                    result.append("Причина: ").append(reason).append("\n");
                }
                
                if (expiresDate != null) {
                    // Вычисляем оставшееся время
                    String timeLeft = calculateTimeLeft(expiresDate);
                    if (timeLeft != null) {
                        result.append("⏱ Осталось: ").append(timeLeft);
                    }
                }
                
                return result.toString();
            }
        }
        
        return "⚠ Нет ответа\nот сервера";
    }
    
    /**
     * Вычисляет оставшееся время до окончания мута
     * Формат входной даты: "30.01.26 22:31:15"
     */
    private String calculateTimeLeft(String expiresDateStr) {
        try {
            // Парсим дату окончания
            // Формат: "30.01.26 22:31:15" (день.месяц.год час:минута:секунда)
            String[] parts = expiresDateStr.split(" ");
            if (parts.length != 2) return null;
            
            String[] dateParts = parts[0].split("\\.");
            String[] timeParts = parts[1].split(":");
            
            if (dateParts.length != 3 || timeParts.length != 3) return null;
            
            int day = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]);
            int year = 2000 + Integer.parseInt(dateParts[2]); // 26 -> 2026
            
            int hour = Integer.parseInt(timeParts[0]);
            int minute = Integer.parseInt(timeParts[1]);
            int second = Integer.parseInt(timeParts[2]);
            
            // Создаем дату окончания
            java.time.LocalDateTime expiresDate = java.time.LocalDateTime.of(year, month, day, hour, minute, second);
            
            // Текущее время
            java.time.LocalDateTime now = java.time.LocalDateTime.now();
            
            // Вычисляем разницу
            java.time.Duration duration = java.time.Duration.between(now, expiresDate);
            
            if (duration.isNegative()) {
                return "Мут истек";
            }
            
            long totalSeconds = duration.getSeconds();
            long days = totalSeconds / 86400;
            long hours = (totalSeconds % 86400) / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            long seconds = totalSeconds % 60;
            
            // Форматируем результат
            StringBuilder result = new StringBuilder();
            if (days > 0) {
                result.append(days).append("д ");
            }
            if (hours > 0 || days > 0) {
                result.append(hours).append("ч ");
            }
            if (minutes > 0 || hours > 0 || days > 0) {
                result.append(minutes).append("м ");
            }
            result.append(seconds).append("с");
            
            return result.toString();
            
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Проверяет никнейм и выполняет размут
     */
    private void checkRealnameAndExecuteUnmute() {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            if (this.client.player != null) {
                this.client.player.sendMessage(Text.literal("§c✗ Введите никнейм"), true);
            }
            return;
        }
        
        // Отправляем /realname для проверки
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage("/realname " + nickname);
        }
        
        // Ждем 500ms для получения ответа, затем выполняем размут
        new Thread(() -> {
            try {
                Thread.sleep(500);
                
                this.client.execute(() -> {
                    String targetNickname = parseRealnameFromChat(nickname);
                    if (targetNickname == null) {
                        targetNickname = nickname;
                    }
                    
                    String command = String.format("/unmute %s", targetNickname);
                    
                    if (this.client.player != null) {
                        this.client.player.networkHandler.sendChatMessage(command);
                        
                        // ClientCommandMixin автоматически отслеживает команду
                    }
                    
                    currentRules = null;
                    selectedAction = "";
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    /**
     * Проверяет никнейм и выполняет разбан
     */
    private void checkRealnameAndExecuteUnban() {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            if (this.client.player != null) {
                this.client.player.sendMessage(Text.literal("§c✗ Введите никнейм"), true);
            }
            return;
        }
        
        // Отправляем /realname для проверки
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage("/realname " + nickname);
        }
        
        // Ждем 500ms для получения ответа, затем выполняем разбан
        new Thread(() -> {
            try {
                Thread.sleep(500);
                
                this.client.execute(() -> {
                    String targetNickname = parseRealnameFromChat(nickname);
                    if (targetNickname == null) {
                        targetNickname = nickname;
                    }
                    
                    String command = String.format("/unban %s", targetNickname);
                    
                    if (this.client.player != null) {
                        this.client.player.networkHandler.sendChatMessage(command);
                        
                        // ClientCommandMixin автоматически отслеживает команду
                    }
                    
                    currentRules = null;
                    selectedAction = "";
                });
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    /**
     * Выполняет наказание
     */
    private void executePunishment(PunishmentRule rule) {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            return;
        }
        
        // Формируем команду
        String command;
        if (selectedAction.equals("mute")) {
            command = String.format("/tempmute %s %s %s", nickname, rule.getDuration(), rule.getCode());
        } else if (selectedAction.equals("ban")) {
            command = String.format("/ban %s %s %s", nickname, rule.getDuration(), rule.getCode());
        } else {
            return;
        }
        
        // Отправляем команду на сервер
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage(command);
        }
        
        // Закрываем список причин
        currentRules = null;
        selectedAction = "";
    }
    
    /**
     * Выполняет размут
     */
    private void executeUnmute() {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            savedResultMessage = "Ошибка: Введите никнейм";
            savedRealNickname = null;
            return;
        }
        
        String command = String.format("/unmute %s", nickname);
        
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage(command);
        }
        
        savedResultMessage = String.format("Размут выдан игроку %s", nickname);
        savedRealNickname = nickname;
        
        currentRules = null;
        selectedAction = "";
    }
    
    /**
     * Выполняет разбан
     */
    private void executeUnban() {
        String nickname = nicknameField.getText().trim();
        
        if (nickname.isEmpty()) {
            savedResultMessage = "Ошибка: Введите никнейм";
            savedRealNickname = null;
            return;
        }
        
        String command = String.format("/unban %s", nickname);
        
        if (this.client.player != null) {
            this.client.player.networkHandler.sendChatMessage(command);
        }
        
        savedResultMessage = String.format("Разбан выдан игроку %s", nickname);
        savedRealNickname = nickname;
        
        currentRules = null;
        selectedAction = "";
    }
    
    
    @Override
    public void close() {
        // Закрываем GUI полностью (возврат в игру)
        this.client.setScreen(null);
    }
}


