package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Информация об игроке
 */
public class PlayerInfoHudElement extends HudElement {
    private static final int COLOR_BG = 0xE61A2332;
    private static final int COLOR_BG_GRADIENT = 0xE6161C26;
    private static final int COLOR_ACCENT = 0xFF00D9FF;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_SHADOW = 0x88000000;
    private static final int COLOR_BORDER = 0x40FFFFFF;
    
    public PlayerInfoHudElement() {
        super("player_info", "Игрок");
        setPosition(HudPosition.TOP_RIGHT);
        setOffsetY(150);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        if (client.player == null) {
            return;
        }
        
        String playerName = client.player.getName().getString();
        
        int width = getWidth();
        int height = getHeight();
        
        // Тень
        int shadowColor = applyOpacity(COLOR_SHADOW);
        RenderUtils.fillRounded(context, 2, 2, width, height, 8, shadowColor);
        
        // Фон с градиентом
        int bgColor = applyOpacity(COLOR_BG);
        int bgGradient = applyOpacity(COLOR_BG_GRADIENT);
        RenderUtils.fillRoundedGradient(context, 0, 0, width, height, 8, bgColor, bgGradient);
        
        // Тонкая светлая рамка
        int borderColor = applyOpacity(COLOR_BORDER);
        RenderUtils.drawRoundedBorder(context, 0, 0, width, height, 8, borderColor);
        
        // Иконка с фоном
        int iconBgColor = applyOpacity(0x3000D9FF);
        RenderUtils.fillRounded(context, 4, 4, 20, 20, 4, iconBgColor);
        context.drawText(client.textRenderer, "👤", 8, 9, COLOR_ACCENT, false);
        
        // Текст
        context.drawText(client.textRenderer, playerName, 30, 9, COLOR_TEXT, false);
    }
    
    @Override
    public int getWidth() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return 120;
        }
        int textWidth = client.textRenderer.getWidth(client.player.getName().getString());
        return Math.max(120, textWidth + 40);
    }
    
    @Override
    public int getHeight() {
        return 28;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
