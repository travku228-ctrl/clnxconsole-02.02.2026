package com.whiterise.adminpanel;

import com.whiterise.adminpanel.auth.PermissionChecker;
import com.whiterise.adminpanel.command.StatsCommand;
import com.whiterise.adminpanel.gui.AccessDeniedScreen;
import com.whiterise.adminpanel.gui.AdminPanelScreen;
import com.whiterise.adminpanel.manager.ChatLogManager;
import com.whiterise.adminpanel.manager.PlayerManager;
import com.whiterise.adminpanel.manager.PunishmentManager;
import com.whiterise.adminpanel.sound.SoundManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class AdminPanelClient implements ClientModInitializer {
    
    private static KeyBinding openMenuKey;
    private static PlayerManager playerManager;
    private static ChatLogManager chatLogManager;
    private static PunishmentManager punishmentManager;
    
    @Override
    public void onInitializeClient() {
        // Инициализация звуков
        SoundManager.init();
        
        // Инициализация HUD
        com.whiterise.adminpanel.hud.HudManager.getInstance().loadConfig();
        
        // Инициализация фоновых частиц для GUI (новая система)
        // Частицы создаются автоматически при открытии Screen
        // Рендер происходит через ScreenMixin с правильным Z-ORDER
        
        // Регистрация HUD рендеринга
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register(
            (context, tickCounter) -> {
                float tickDelta = tickCounter.getTickDelta(false);
                com.whiterise.adminpanel.hud.HudManager.getInstance().render(context, tickDelta);
            }
        );
        
        // Регистрация команд
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            StatsCommand.register(dispatcher);
        });
        
        // Регистрация клавиши Right Shift
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.whiterise_adminpanel.open_menu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.whiterise_adminpanel"
        ));
        
        // Инициализация менеджеров
        playerManager = new PlayerManager();
        chatLogManager = new ChatLogManager();
        punishmentManager = new PunishmentManager();
        
        // Регистрация обработчика тиков
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openMenuKey.wasPressed()) {
                // ПРОВЕРКА ПРАВ ПЕРЕД ОТКРЫТИЕМ МОДА
                PermissionChecker.checkPermission(
                    // onSuccess - есть права
                    () -> MinecraftClient.getInstance().setScreen(new AdminPanelScreen()),
                    
                    // onFailure - нет прав
                    () -> MinecraftClient.getInstance().setScreen(new AccessDeniedScreen())
                );
            }
            
            // Обновление списка игроков каждую секунду
            playerManager.tick();
        });
        
        // LIFECYCLE EVENTS ДЛЯ ЛОГОВ ЧАТА
        // При отключении от сервера - очищаем логи и сбрасываем кеш прав
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            chatLogManager.clear();
            PermissionChecker.resetCache();
        });
        
        // При закрытии клиента - очищаем логи
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            chatLogManager.clear();
            PermissionChecker.resetCache();
        });
    }
    
    public static PlayerManager getPlayerManager() {
        return playerManager;
    }
    
    public static ChatLogManager getChatLogManager() {
        return chatLogManager;
    }
    
    public static PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }
}
