package com.whiterise.adminpanel.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class SilentButtonWidget extends ButtonWidget {
    
    public SilentButtonWidget(int x, int y, int width, int height, Text message, PressAction onPress) {
        super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
    }
    
    @Override
    public void playDownSound(net.minecraft.client.sound.SoundManager soundManager) {
        // Не воспроизводим стандартный звук кнопки
    }
    
    @Override
    public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        // ИСПРАВЛЕНО: Рендерим кнопку БЕЗ текста
        // Текст будет отрисован отдельно в renderSidebarWithActiveState
        // Не вызываем super.renderButton(), чтобы избежать дублирования текста
    }
}
