package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.manager.AntiCheatSessionManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ConfirmActionScreen extends Screen {
    private final String targetPlayer;
    private final String action; // "release" или "ban"
    
    // Цветовая палитра
    private static final int COLOR_BG_DARK = 0xFF0a0e1a;
    private static final int COLOR_BG_CARD = 0xFF151b26;
    private static final int COLOR_SUCCESS = 0xFF10b981;
    private static final int COLOR_DANGER = 0xFFef4444;
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;
    private static final int COLOR_BORDER = 0xFF2a3441;
    
    public ConfirmActionScreen(String targetPlayer, String action) {
        super(Text.literal("Подтверждение"));
        this.targetPlayer = targetPlayer;
        this.action = action;
    }
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fill()
    }
    
    @Override
    protected void init() {
        // Кнопки рендерятся вручную для красивого вида
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Полупрозрачный темный фон (overlay)
        context.fill(0, 0, this.width, this.height, 0xCC000000);
        
        // Компактная карточка подтверждения
        int cardWidth = 450;
        int cardHeight = 200;
        int cardX = (this.width - cardWidth) / 2;
        int cardY = (this.height - cardHeight) / 2;
        
        // Тень карточки
        context.fill(cardX + 3, cardY + 3, cardX + cardWidth + 3, cardY + cardHeight + 3, 0x88000000);
        
        // Фон карточки - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, cardX, cardY, cardWidth, cardHeight, 12, COLOR_BG_CARD);
        
        // Границы - СКРУГЛЕННЫЕ
        RenderUtils.drawRoundedBorder(context, cardX, cardY, cardWidth, cardHeight, 12, COLOR_BORDER);
        
        // Цветная полоска сверху (зеленая для отпустить, красная для бана) - СКРУГЛЕННАЯ
        int accentColor = action.equals("release") ? COLOR_SUCCESS : COLOR_DANGER;
        RenderUtils.fillRounded(context, cardX, cardY, cardWidth, 4, 12, accentColor);
        
        // Заголовок
        String title = "⚠ Подтверждение действия";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, cardY + 25, COLOR_TEXT_PRIMARY, true);
        
        // Текст подтверждения
        String actionText = action.equals("release") ? "отпустить" : "забанить";
        String line1 = "Вы уверены, что хотите";
        String line2 = actionText + " игрока " + targetPlayer + "?";
        String line3 = "Это действие завершит проверку.";
        
        int line1Width = this.textRenderer.getWidth(line1);
        int line2Width = this.textRenderer.getWidth(line2);
        int line3Width = this.textRenderer.getWidth(line3);
        
        context.drawText(this.textRenderer, line1, (this.width - line1Width) / 2, cardY + 60, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, line2, (this.width - line2Width) / 2, cardY + 80, COLOR_TEXT_PRIMARY, true);
        context.drawText(this.textRenderer, line3, (this.width - line3Width) / 2, cardY + 100, COLOR_TEXT_SECONDARY, false);
        
        // Рендерим красивые кнопки
        renderCustomButtons(context, mouseX, mouseY);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рендерит красивые скругленные кнопки
     */
    private void renderCustomButtons(DrawContext context, int mouseX, int mouseY) {
        int buttonWidth = 160;
        int buttonHeight = 35;
        int startX = (this.width - (buttonWidth * 2 + 20)) / 2;
        int buttonY = this.height / 2 + 50;
        
        // Кнопка подтверждения (зеленая для отпустить, красная для бана)
        String confirmText = action.equals("release") ? "✓ Да, отпустить" : "✗ Да, забанить";
        int confirmColor = action.equals("release") ? COLOR_SUCCESS : COLOR_DANGER;
        
        boolean isConfirmHovered = mouseX >= startX && mouseX <= startX + buttonWidth && 
                                   mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        
        int confirmY = buttonY;
        if (isConfirmHovered) {
            confirmY -= 2;
            context.fill(startX + 2, confirmY + buttonHeight + 2, startX + buttonWidth + 2, confirmY + buttonHeight + 4, 0x88000000);
        }
        
        int finalConfirmColor = isConfirmHovered ? adjustBrightness(confirmColor, 1.15f) : confirmColor;
        RenderUtils.fillRounded(context, startX, confirmY, buttonWidth, buttonHeight, 8, finalConfirmColor);
        
        int confirmTextWidth = this.textRenderer.getWidth(confirmText);
        context.drawText(this.textRenderer, confirmText, 
            startX + (buttonWidth - confirmTextWidth) / 2, confirmY + (buttonHeight - 8) / 2, COLOR_TEXT_PRIMARY, true);
        
        // Кнопка отмены (серая)
        int cancelX = startX + buttonWidth + 20;
        boolean isCancelHovered = mouseX >= cancelX && mouseX <= cancelX + buttonWidth && 
                                 mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        
        int cancelY = buttonY;
        if (isCancelHovered) {
            cancelY -= 2;
            context.fill(cancelX + 2, cancelY + buttonHeight + 2, cancelX + buttonWidth + 2, cancelY + buttonHeight + 4, 0x88000000);
        }
        
        int cancelColor = 0xFF4a5568; // Серый
        int finalCancelColor = isCancelHovered ? adjustBrightness(cancelColor, 1.15f) : cancelColor;
        RenderUtils.fillRounded(context, cancelX, cancelY, buttonWidth, buttonHeight, 8, finalCancelColor);
        
        String cancelText = "Отмена";
        int cancelTextWidth = this.textRenderer.getWidth(cancelText);
        context.drawText(this.textRenderer, cancelText, 
            cancelX + (buttonWidth - cancelTextWidth) / 2, cancelY + (buttonHeight - 8) / 2, COLOR_TEXT_PRIMARY, false);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        
        int buttonWidth = 160;
        int buttonHeight = 35;
        int startX = (this.width - (buttonWidth * 2 + 20)) / 2;
        int buttonY = this.height / 2 + 50;
        
        // Кнопка подтверждения
        if (mouseX >= startX && mouseX <= startX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            if (action.equals("release")) {
                sendCommand("/check ally");
            } else if (action.equals("ban")) {
                sendCommand("/check ban");
            }
            
            // ЗАВЕРШАЕМ СЕССИЮ
            AntiCheatSessionManager.endSession();
            
            // Возвращаемся в главную панель
            this.client.setScreen(new AdminPanelScreen());
            return true;
        }
        
        // Кнопка отмены
        int cancelX = startX + buttonWidth + 20;
        if (mouseX >= cancelX && mouseX <= cancelX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            this.client.setScreen(new AntiCheatScreen(targetPlayer));
            return true;
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    

    
    private void sendCommand(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.networkHandler.sendChatCommand(command.substring(1));
        }
    }
}
