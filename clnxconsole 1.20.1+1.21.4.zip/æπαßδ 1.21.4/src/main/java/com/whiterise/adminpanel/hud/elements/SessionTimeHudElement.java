package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Время текущей сессии на сервере
 */
public class SessionTimeHudElement extends HudElement {
    private static final int COLOR_BG = 0xE61A2332;
    private static final int COLOR_BG_GRADIENT = 0xE6161C26;
    private static final int COLOR_ACCENT = 0xFF00D9FF;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_SHADOW = 0x88000000;
    private static final int COLOR_BORDER = 0x40FFFFFF;
    
    private long sessionStartTime = 0;
    
    public SessionTimeHudElement() {
        super("session_time", "Время сессии");
        setPosition(HudPosition.TOP_RIGHT);
        setOffsetY(80);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Инициализируем время начала сессии
        if (sessionStartTime == 0 && client.world != null) {
            sessionStartTime = System.currentTimeMillis();
        }
        
        // Сбрасываем при выходе с сервера
        if (client.world == null) {
            sessionStartTime = 0;
            return;
        }
        
        // Вычисляем время сессии
        long elapsed = System.currentTimeMillis() - sessionStartTime;
        String timeStr = formatTime(elapsed);
        
        int width = getWidth();
        int height = getHeight();
        
        // Тень
        int shadowColor = applyOpacity(COLOR_SHADOW);
        RenderUtils.fillRounded(context, 2, 2, width, height, 8, shadowColor);
        
        // Фон с градиентом
        int bgColor = applyOpacity(COLOR_BG);
        int bgGradient = applyOpacity(COLOR_BG_GRADIENT);
        RenderUtils.fillRoundedGradient(context, 0, 0, width, height, 8, bgColor, bgGradient);
        
        // Тонкая светлая рамка
        int borderColor = applyOpacity(COLOR_BORDER);
        RenderUtils.drawRoundedBorder(context, 0, 0, width, height, 8, borderColor);
        
        // Иконка с фоном
        int iconBgColor = applyOpacity(0x3000D9FF);
        RenderUtils.fillRounded(context, 4, 4, 20, 20, 4, iconBgColor);
        context.drawText(client.textRenderer, "⏱", 8, 9, COLOR_ACCENT, false);
        
        // Текст
        context.drawText(client.textRenderer, timeStr, 30, 9, COLOR_TEXT, false);
    }
    
    /**
     * Форматирует время в читаемый вид (ЧЧ:ММ:СС)
     */
    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, secs);
        } else {
            return String.format("%02d:%02d", minutes, secs);
        }
    }
    
    @Override
    public int getWidth() {
        return 100;
    }
    
    @Override
    public int getHeight() {
        return 28;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
