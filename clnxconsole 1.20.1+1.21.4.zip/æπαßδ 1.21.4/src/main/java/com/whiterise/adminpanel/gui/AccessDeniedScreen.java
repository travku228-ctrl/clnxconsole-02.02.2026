package com.whiterise.adminpanel.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.whiterise.adminpanel.auth.PermissionChecker;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Экран "Доступ ограничен"
 * Показывается когда у игрока нет прав для использования мода
 * Минималистичный дизайн без технических деталей
 */
public class AccessDeniedScreen extends Screen {
    
    // Иконка "Доступ запрещён"
    private static final Identifier ACCESS_DENIED_ICON = Identifier.of("whiterise_adminpanel", "textures/icons/accesdenied.png");
    
    // Цвета - мягкая тёмная палитра
    private static final int COLOR_BG_GRADIENT_TOP = 0xFF0a0e17;
    private static final int COLOR_BG_GRADIENT_BOTTOM = 0xFF1a1f2e;
    private static final int COLOR_CARD_BG = 0xFF1e2433;
    private static final int COLOR_CARD_BORDER = 0xFF2d3548;
    
    // Акцентные цвета
    private static final int COLOR_ACCENT_RED = 0xFFe74c3c;      // Только для заголовка
    private static final int COLOR_TEXT_WHITE = 0xFFffffff;      // Основной текст
    private static final int COLOR_TEXT_MUTED = 0xFF7f8c8d;      // Мелкий текст
    
    // Цвета кнопок
    private static final int COLOR_BUTTON_PRIMARY = 0xFF3498db;
    private static final int COLOR_BUTTON_PRIMARY_HOVER = 0xFF2980b9;
    private static final int COLOR_BUTTON_SECONDARY = 0xFF34495e;
    private static final int COLOR_BUTTON_SECONDARY_HOVER = 0xFF2c3e50;
    
    // Отслеживание hover состояния для звуков
    private boolean wasBackButtonHovered = false;
    private boolean wasRetryButtonHovered = false;
    
    public AccessDeniedScreen() {
        super(Text.literal("Доступ ограничен"));
    }
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fillGradient()
    }
    
    @Override
    protected void init() {
        super.init();
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Градиентный фон
        context.fillGradient(0, 0, this.width, this.height, COLOR_BG_GRADIENT_TOP, COLOR_BG_GRADIENT_BOTTOM);
        
        // Центральная карточка (уменьшена для минимализма)
        int cardWidth = 420;
        int cardHeight = 320;
        int cardX = (this.width - cardWidth) / 2;
        int cardY = (this.height - cardHeight) / 2;
        
        // Мягкая тень карточки - СКРУГЛЕННАЯ
        RenderUtils.fillRounded(context, cardX + 4, cardY + 4, cardWidth, cardHeight, 12, 0x66000000);
        
        // Фон карточки - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, cardX, cardY, cardWidth, cardHeight, 12, COLOR_CARD_BG);
        
        // Тонкая граница карточки - СКРУГЛЕННАЯ
        RenderUtils.drawRoundedBorder(context, cardX, cardY, cardWidth, cardHeight, 12, COLOR_CARD_BORDER);
        
        // === ИКОНКА "ДОСТУП ЗАПРЕЩЁН" ===
        int iconSize = 56;
        int iconX = cardX + (cardWidth - iconSize) / 2;
        int iconY = cardY + 20;
        
        RenderSystem.setShaderTexture(0, ACCESS_DENIED_ICON);
        RenderSystem.enableBlend();
        context.drawTexture(RenderLayer::getGuiTextured, ACCESS_DENIED_ICON, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        RenderSystem.disableBlend();
        
        // === ЗАГОЛОВОК (красный, крупный) ===
        String title = "Доступ ограничен";
        int titleY = iconY + iconSize + 20;
        drawCenteredTextScaled(context, title, cardX, cardWidth, titleY, COLOR_ACCENT_RED, 1.5f, true);
        
        // === ОСНОВНОЙ ТЕКСТ ===
        int textY = titleY + 40;
        int lineHeight = 14;
        
        drawCenteredText(context, "Для использования Админ-меню необходимо", cardX, cardWidth, textY, COLOR_TEXT_WHITE);
        textY += lineHeight;
        drawCenteredText(context, "быть сотрудником сервера.", cardX, cardWidth, textY, COLOR_TEXT_WHITE);
        textY += lineHeight + 20;
        
        // === ДОПОЛНИТЕЛЬНЫЙ ТЕКСТ (мелкий, серый) ===
        drawCenteredTextSmall(context, "Если вы считаете, что это ошибка — обратитесь к администрации сервера.", cardX, cardWidth, textY, COLOR_TEXT_MUTED);
        
        // === КНОПКИ ===
        int buttonWidth = 140;
        int buttonHeight = 35;
        int buttonSpacing = 15;
        int totalButtonWidth = buttonWidth * 2 + buttonSpacing;
        int buttonsY = cardY + cardHeight - 60;
        
        // Кнопка "Назад" (основная, слева)
        int backButtonX = cardX + (cardWidth - totalButtonWidth) / 2;
        boolean isBackHovered = mouseX >= backButtonX && mouseX <= backButtonX + buttonWidth && 
                               mouseY >= buttonsY && mouseY <= buttonsY + buttonHeight;
        
        // Звук hover для кнопки "Назад"
        if (isBackHovered && !wasBackButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasBackButtonHovered = isBackHovered;
        
        renderRoundedButton(context, backButtonX, buttonsY, buttonWidth, buttonHeight, "Назад", 
                    isBackHovered, COLOR_BUTTON_PRIMARY, COLOR_BUTTON_PRIMARY_HOVER);
        
        // Кнопка "Повторить проверку" (вторичная, справа)
        int retryButtonX = backButtonX + buttonWidth + buttonSpacing;
        boolean isRetryHovered = mouseX >= retryButtonX && mouseX <= retryButtonX + buttonWidth && 
                                mouseY >= buttonsY && mouseY <= buttonsY + buttonHeight;
        
        // Звук hover для кнопки "Повторить проверку"
        if (isRetryHovered && !wasRetryButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasRetryButtonHovered = isRetryHovered;
        
        renderRoundedButton(context, retryButtonX, buttonsY, buttonWidth, buttonHeight, "Повторить проверку", 
                    isRetryHovered, COLOR_BUTTON_SECONDARY, COLOR_BUTTON_SECONDARY_HOVER);
    }
    

    
    /**
     * Рисует кнопку с hover эффектом - СКРУГЛЕННУЮ
     */
    private void renderRoundedButton(DrawContext context, int x, int y, int width, int height, 
                              String text, boolean isHovered, int normalColor, int hoverColor) {
        // Тень при наведении
        if (isHovered) {
            RenderUtils.fillRounded(context, x + 3, y + 3, width, height, 8, 0x88000000);
        }
        
        // Фон кнопки - СКРУГЛЕННЫЙ
        int bgColor = isHovered ? hoverColor : normalColor;
        RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
        
        // Граница кнопки - СКРУГЛЕННАЯ
        int borderColor = isHovered ? COLOR_TEXT_WHITE : COLOR_CARD_BORDER;
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, borderColor);
        
        // Текст кнопки (центрированный)
        int textWidth = this.textRenderer.getWidth(text);
        int textX = x + (width - textWidth) / 2;
        int textY = y + (height - 8) / 2;
        context.drawText(this.textRenderer, text, textX, textY, COLOR_TEXT_WHITE, false);
    }
    
    /**
     * Рисует текст по центру
     */
    private void drawCenteredText(DrawContext context, String text, int cardX, int cardWidth, int y, int color) {
        int textWidth = this.textRenderer.getWidth(text);
        context.drawText(this.textRenderer, text, cardX + (cardWidth - textWidth) / 2, y, color, false);
    }
    
    /**
     * Рисует мелкий текст по центру (0.85x размер)
     */
    private void drawCenteredTextSmall(DrawContext context, String text, int cardX, int cardWidth, int y, int color) {
        context.getMatrices().push();
        context.getMatrices().scale(0.85f, 0.85f, 1.0f);
        
        float scale = 0.85f;
        int textWidth = (int)(this.textRenderer.getWidth(text) * scale);
        int scaledX = (int)((cardX + (cardWidth - textWidth) / 2) / scale);
        int scaledY = (int)(y / scale);
        
        context.drawText(this.textRenderer, text, scaledX, scaledY, color, false);
        context.getMatrices().pop();
    }
    
    /**
     * Рисует текст по центру с масштабированием
     */
    private void drawCenteredTextScaled(DrawContext context, String text, int cardX, int cardWidth, 
                                       int y, int color, float scale, boolean shadow) {
        context.getMatrices().push();
        context.getMatrices().scale(scale, scale, 1.0f);
        
        int textWidth = (int)(this.textRenderer.getWidth(text) * scale);
        int scaledX = (int)((cardX + (cardWidth - textWidth) / 2) / scale);
        int scaledY = (int)(y / scale);
        
        context.drawText(this.textRenderer, text, scaledX, scaledY, color, shadow);
        context.getMatrices().pop();
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        
        int cardWidth = 420;
        int cardHeight = 320;
        int cardX = (this.width - cardWidth) / 2;
        int cardY = (this.height - cardHeight) / 2;
        
        int buttonWidth = 140;
        int buttonHeight = 35;
        int buttonSpacing = 15;
        int totalButtonWidth = buttonWidth * 2 + buttonSpacing;
        int buttonsY = cardY + cardHeight - 60;
        
        // Кнопка "Назад"
        int backButtonX = cardX + (cardWidth - totalButtonWidth) / 2;
        if (mouseX >= backButtonX && mouseX <= backButtonX + buttonWidth && 
            mouseY >= buttonsY && mouseY <= buttonsY + buttonHeight) {
            SoundManager.playClickSound(); // Звук клика
            this.close();
            return true;
        }
        
        // Кнопка "Повторить проверку"
        int retryButtonX = backButtonX + buttonWidth + buttonSpacing;
        if (mouseX >= retryButtonX && mouseX <= retryButtonX + buttonWidth && 
            mouseY >= buttonsY && mouseY <= buttonsY + buttonHeight) {
            SoundManager.playClickSound(); // Звук клика
            retryPermissionCheck();
            return true;
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    /**
     * Повторная проверка прав без перезахода на сервер
     * Сбрасывает кеш и проверяет заново
     */
    private void retryPermissionCheck() {
        // Сбрасываем кеш проверки
        PermissionChecker.resetCache();
        
        // Выполняем новую проверку
        PermissionChecker.checkPermission(
            // onSuccess - есть права, открываем мод
            () -> {
                if (this.client != null) {
                    this.client.setScreen(new AdminPanelScreen());
                }
            },
            
            // onFailure - прав все еще нет, остаемся на этом экране
            () -> {
                // Просто остаемся на экране отказа
            }
        );
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // ESC закрывает экран
        if (keyCode == 256) { // 256 = ESC
            this.close();
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    public void close() {
        // Возвращаемся в игру
        if (this.client != null) {
            this.client.setScreen(null);
        }
    }
    
    @Override
    public boolean shouldPause() {
        return false;
    }
}
