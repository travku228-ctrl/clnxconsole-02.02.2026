package com.whiterise.adminpanel.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Modern smooth HUD renderer with antialiased textures (like in Figma)
 */
public class SmoothHudRenderer {
    private static final Identifier SMOOTH_PANEL = Identifier.of("whiterise_adminpanel", "textures/gui/smooth_panel.png");
    private static final Identifier SMOOTH_CORNER = Identifier.of("whiterise_adminpanel", "textures/gui/smooth_corner.png");
    
    /**
     * Draws smooth panel with 9-patch rendering
     * @param context DrawContext
     * @param x X position
     * @param y Y position
     * @param width Panel width
     * @param height Panel height
     * @param color Color (0xRRGGBB)
     * @param alpha Alpha (0.0 - 1.0)
     */
    public static void drawSmoothPanel(DrawContext context, int x, int y, int width, int height, int color, float alpha) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Enable smoothing
        context.getMatrices().push();
        context.getMatrices().translate(0, 0, 100); // On top of everything
        
        // Sizes for 9-patch
        int cornerSize = 16; // Must match radius in texture
        int centerWidth = width - 2 * cornerSize;
        int centerHeight = height - 2 * cornerSize;
        
        // Set color with alpha channel
        int alphaInt = MathHelper.clamp((int)(alpha * 255), 0, 255);
        int finalColor = (alphaInt << 24) | (color & 0xFFFFFF);
        
        // 1. CORNERS (use textures with smooth edges)
        // Top-left
        drawTexturedQuad(context, SMOOTH_PANEL,
                        x, y, cornerSize, cornerSize,
                        0, 0, cornerSize, cornerSize, 32, 32,
                        finalColor);
        
        // Top-right
        drawTexturedQuad(context, SMOOTH_PANEL,
                        x + width - cornerSize, y, cornerSize, cornerSize,
                        cornerSize, 0, cornerSize, cornerSize, 32, 32,
                        finalColor);
        
        // Bottom-left
        drawTexturedQuad(context, SMOOTH_PANEL,
                        x, y + height - cornerSize, cornerSize, cornerSize,
                        0, cornerSize, cornerSize, cornerSize, 32, 32,
                        finalColor);
        
        // Bottom-right
        drawTexturedQuad(context, SMOOTH_PANEL,
                        x + width - cornerSize, y + height - cornerSize, cornerSize, cornerSize,
                        cornerSize, cornerSize, cornerSize, cornerSize, 32, 32,
                        finalColor);
        
        // 2. EDGES (stretch center part of texture)
        // Top edge
        if (centerWidth > 0) {
            drawTexturedQuad(context, SMOOTH_PANEL,
                            x + cornerSize, y, centerWidth, cornerSize,
                            cornerSize, 0, 1, cornerSize, 32, 32,
                            finalColor);
        }
        
        // Bottom edge
        if (centerWidth > 0) {
            drawTexturedQuad(context, SMOOTH_PANEL,
                            x + cornerSize, y + height - cornerSize, centerWidth, cornerSize,
                            cornerSize, cornerSize, 1, cornerSize, 32, 32,
                            finalColor);
        }
        
        // Left edge
        if (centerHeight > 0) {
            drawTexturedQuad(context, SMOOTH_PANEL,
                            x, y + cornerSize, cornerSize, centerHeight,
                            0, cornerSize, cornerSize, 1, 32, 32,
                            finalColor);
        }
        
        // Right edge
        if (centerHeight > 0) {
            drawTexturedQuad(context, SMOOTH_PANEL,
                            x + width - cornerSize, y + cornerSize, cornerSize, centerHeight,
                            cornerSize, cornerSize, cornerSize, 1, 32, 32,
                            finalColor);
        }
        
        // 3. CENTER (stretch)
        if (centerWidth > 0 && centerHeight > 0) {
            drawTexturedQuad(context, SMOOTH_PANEL,
                            x + cornerSize, y + cornerSize, centerWidth, centerHeight,
                            cornerSize, cornerSize, 1, 1, 32, 32,
                            finalColor);
        }
        
        context.getMatrices().pop();
    }
    
    /**
     * Method for drawing texture with color and transparency
     */
    private static void drawTexturedQuad(DrawContext context, Identifier texture,
                                        int x, int y, int width, int height,
                                        int u, int v, int regionWidth, int regionHeight,
                                        int textureWidth, int textureHeight,
                                        int color) {
        float alpha = ((color >> 24) & 0xFF) / 255.0f;
        float red = ((color >> 16) & 0xFF) / 255.0f;
        float green = ((color >> 8) & 0xFF) / 255.0f;
        float blue = (color & 0xFF) / 255.0f;
        
        RenderSystem.setShaderColor(red, green, blue, alpha);
        context.drawTexture(RenderLayer::getGuiTextured, texture, x, y, u, v, width, height, textureWidth, textureHeight);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    /**
     * Draws text with smooth edges
     */
    public static void drawSmoothText(DrawContext context, String text, int x, int y, int color) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Draw shadow with slight offset for "smoothing"
        int shadowColor = 0x000000 | ((color >> 24) & 0xFF) << 24;
        
        for (float dx = -0.5f; dx <= 0.5f; dx += 0.5f) {
            for (float dy = -0.5f; dy <= 0.5f; dy += 0.5f) {
                if (dx != 0 || dy != 0) {
                    context.drawText(client.textRenderer, text,
                                     (int)(x + dx), (int)(y + dy),
                                     shadowColor, false);
                }
            }
        }
        
        // Main text
        context.drawText(client.textRenderer, text, x, y, color, false);
    }
    
    /**
     * Draws smooth decorative line (for dividers)
     */
    public static void drawSmoothLine(DrawContext context, int x1, int y1, int x2, int y2, int color, float alpha) {
        int alphaInt = MathHelper.clamp((int)(alpha * 255), 0, 255);
        int finalColor = (alphaInt << 24) | (color & 0xFFFFFF);
        
        // Draw line with gradient for smoothness
        if (y1 == y2) {
            // Horizontal line
            context.fill(x1, y1, x2, y2 + 1, finalColor);
        } else if (x1 == x2) {
            // Vertical line
            context.fill(x1, y1, x1 + 1, y2, finalColor);
        }
    }
    
    /**
     * Draws smooth highlight/glow effect
     */
    public static void drawGlow(DrawContext context, int x, int y, int width, int height, int color, float intensity) {
        // Draw multiple layers with decreasing alpha for glow effect
        for (int i = 0; i < 3; i++) {
            float alpha = intensity * (1.0f - i * 0.3f);
            int offset = i * 2;
            drawSmoothPanel(context, x - offset, y - offset, 
                          width + offset * 2, height + offset * 2, 
                          color, alpha * 0.3f);
        }
    }
}
