package com.whiterise.adminpanel.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

import java.awt.Color;

/**
 * Система рендеринга с использованием шейдеров
 * Адаптировано из spacemoderation для улучшенного качества отрисовки
 */
public class ShaderRenderer {
    
    /**
     * Рисует скругленный прямоугольник с использованием шейдера
     * @param matrix матрица трансформации
     * @param x позиция X
     * @param y позиция Y
     * @param width ширина
     * @param height высота
     * @param radius радиус скругления
     * @param color цвет
     */
    public static void drawRoundedRect(Matrix4f matrix, float x, float y, float width, float height, 
                                      float radius, Color color) {
        drawRoundedRect(matrix, x, y, width, height, radius, radius, radius, radius, color);
    }
    
    /**
     * Рисует скругленный прямоугольник с разными радиусами углов
     * @param matrix матрица трансформации
     * @param x позиция X
     * @param y позиция Y
     * @param width ширина
     * @param height высота
     * @param radius1 радиус верхнего левого угла
     * @param radius2 радиус нижнего левого угла
     * @param radius3 радиус нижнего правого угла
     * @param radius4 радиус верхнего правого угла
     * @param color цвет
     */
    public static void drawRoundedRect(Matrix4f matrix, float x, float y, float width, float height,
                                      float radius1, float radius2, float radius3, float radius4, Color color) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        
        // Используем стандартный шейдер позиции-цвета
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder builder = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        
        int argb = color.getRGB();
        
        // Рисуем прямоугольник как набор квадов
        builder.vertex(matrix, x, y, 0).color(argb);
        builder.vertex(matrix, x, y + height, 0).color(argb);
        builder.vertex(matrix, x + width, y + height, 0).color(argb);
        builder.vertex(matrix, x + width, y, 0).color(argb);
        
        net.minecraft.client.render.BufferRenderer.drawWithGlobalProgram(builder.end());
        
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
    
    /**
     * Рисует скругленный прямоугольник с градиентом
     * @param matrix матрица трансформации
     * @param x позиция X
     * @param y позиция Y
     * @param width ширина
     * @param height высота
     * @param radius радиус скругления
     * @param color1 цвет верхнего левого угла
     * @param color2 цвет нижнего левого угла
     * @param color3 цвет нижнего правого угла
     * @param color4 цвет верхнего правого угла
     */
    public static void drawRoundedGradient(Matrix4f matrix, float x, float y, float width, float height,
                                          float radius, Color color1, Color color2, Color color3, Color color4) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder builder = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        
        // Градиент по углам
        builder.vertex(matrix, x, y, 0).color(color1.getRGB());
        builder.vertex(matrix, x, y + height, 0).color(color2.getRGB());
        builder.vertex(matrix, x + width, y + height, 0).color(color3.getRGB());
        builder.vertex(matrix, x + width, y, 0).color(color4.getRGB());
        
        BufferRenderer.drawWithGlobalProgram(builder.end());
        
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
    
    /**
     * Рисует линию с заданной толщиной
     * @param matrix матрица трансформации
     * @param x1 начальная X
     * @param y1 начальная Y
     * @param x2 конечная X
     * @param y2 конечная Y
     * @param thickness толщина линии
     * @param color цвет
     */
    public static void drawLine(Matrix4f matrix, float x1, float y1, float x2, float y2, 
                               float thickness, Color color) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        
        // Вычисляем перпендикуляр для толщины
        float dx = x2 - x1;
        float dy = y2 - y1;
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        
        if (length == 0) return;
        
        float perpX = -dy / length * thickness / 2;
        float perpY = dx / length * thickness / 2;
        
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder builder = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        
        int argb = color.getRGB();
        
        builder.vertex(matrix, x1 + perpX, y1 + perpY, 0).color(argb);
        builder.vertex(matrix, x1 - perpX, y1 - perpY, 0).color(argb);
        builder.vertex(matrix, x2 - perpX, y2 - perpY, 0).color(argb);
        builder.vertex(matrix, x2 + perpX, y2 + perpY, 0).color(argb);
        
        BufferRenderer.drawWithGlobalProgram(builder.end());
        
        RenderSystem.disableBlend();
    }
    
    /**
     * Рисует круг
     * @param matrix матрица трансформации
     * @param centerX центр X
     * @param centerY центр Y
     * @param radius радиус
     * @param segments количество сегментов (больше = плавнее)
     * @param color цвет
     */
    public static void drawCircle(Matrix4f matrix, float centerX, float centerY, float radius, 
                                  int segments, Color color) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder builder = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        
        int argb = color.getRGB();
        
        // Центр круга
        builder.vertex(matrix, centerX, centerY, 0).color(argb);
        
        // Точки по окружности
        for (int i = 0; i <= segments; i++) {
            double angle = 2 * Math.PI * i / segments;
            float x = centerX + (float) (Math.cos(angle) * radius);
            float y = centerY + (float) (Math.sin(angle) * radius);
            builder.vertex(matrix, x, y, 0).color(argb);
        }
        
        BufferRenderer.drawWithGlobalProgram(builder.end());
        
        RenderSystem.disableBlend();
    }
}
