package com.whiterise.adminpanel.hud;

import com.whiterise.adminpanel.AdminPanelClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;
import net.minecraft.client.render.RenderLayer;

/**
 * Единый горизонтальный HUD бар - ТОЧНАЯ КОПИЯ ДИЗАЙНА ИЗ FIGMA
 */
public class UnifiedHudBar {
    // ЦВЕТА ИЗ FIGMA
    private static final int COLOR_BG = 0xFF312541;           // Фон бара
    private static final int COLOR_STROKE = 0x40B700FF;       // Обводка (25% opacity)
    private static final int COLOR_TEXT = 0xFFE17FE3;         // Текст (розовый)
    private static final int COLOR_DIVIDER = 0x408D00C8;      // Разделители (25% opacity)
    private static final int COLOR_SHADOW = 0x40000000;       // Тень M3/Elevation Light/1
    
    // ИКОНКИ (PNG текстуры)
    private static final Identifier ICON_LOGO = Identifier.of("whiterise_adminpanel", "textures/icons/logo.png");
    private static final Identifier ICON_PLAYER = Identifier.of("whiterise_adminpanel", "textures/icons/player.png");
    private static final Identifier ICON_FPS = Identifier.of("whiterise_adminpanel", "textures/icons/fps.png");
    private static final Identifier ICON_PING = Identifier.of("whiterise_adminpanel", "textures/icons/ping.png");
    private static final Identifier ICON_TIME = Identifier.of("whiterise_adminpanel", "textures/icons/time.png");
    private static final Identifier ICON_PUNISH = Identifier.of("whiterise_adminpanel", "textures/icons/punishment.png");
    
    // Режим рендеринга: true = гладкие текстуры (Figma style), false = геометрия
    private static final boolean USE_SMOOTH_RENDERING = true;
    
    // РАЗМЕРЫ ИЗ FIGMA
    private static final int BAR_HEIGHT = 20;                 // Высота бара
    private static final int CORNER_RADIUS = 10;              // Скругление правой стороны
    private static final int DIVIDER_WIDTH = 1;               // Толщина разделителя
    private static final int DIVIDER_HEIGHT = 14;             // Высота разделителя
    private static final int PADDING_LEFT = 8;                // Отступ слева (увеличен)
    private static final int PADDING_RIGHT = 8;               // Отступ справа (увеличен)
    private static final int ITEM_SPACING = 12;               // Расстояние между элементами (увеличено)
    private static final int ICON_SIZE = 12;                  // Размер иконки (меньше)
    
    // ФИКСИРОВАННЫЕ ШИРИНЫ для элементов (уменьшены)
    private static final int FPS_WIDTH = 30;                  // Фиксированная ширина для FPS (уменьшена)
    private static final int PING_WIDTH = 26;                 // Фиксированная ширина для пинга (уменьшена)
    
    // Настройки отображения элементов
    private boolean showPlayer = true;
    private boolean showFps = true;
    private boolean showPing = true;
    private boolean showTime = true;
    private boolean showPunishments = true;
    private float scale = 1.0f; // Масштаб бара
    
    // Анимационные эффекты - ОПТИМИЗИРОВАННАЯ ГЛОБАЛЬНАЯ СИНХРОНИЗАЦИЯ
    private static final long GLOBAL_ANIMATION_START = System.currentTimeMillis();
    private static final float PULSE_SPEED = 0.003f;
    private static final float SHIMMER_SPEED = 0.001f;
    private static final float PULSE_RANGE = 0.02f; // Диапазон пульсации (2%)
    private static final float PULSE_BASE = 1.0f - PULSE_RANGE * 0.5f; // Базовое значение
    private static final float SHIMMER_RANGE = 0.6f; // Диапазон мерцания (60%)
    private static final float SHIMMER_BASE = 0.4f; // Базовое значение мерцания
    
    // Кэш для анимационных значений (обновляется раз в кадр)
    private static long lastAnimationUpdate = 0;
    private static float cachedShimmerAlpha = 1.0f;
    private static float cachedPulseScale = 1.0f;
    
    /**
     * ОПТИМИЗИРОВАННОЕ получение синхронизированных анимационных значений
     * Кэширует вычисления на один кадр для повышения производительности
     */
    private static void updateAnimationCache() {
        long currentTime = System.currentTimeMillis();
        
        // Обновляем кэш только если прошло время (избегаем повторных вычислений в одном кадре)
        if (currentTime != lastAnimationUpdate) {
            lastAnimationUpdate = currentTime;
            
            float animationTime = (currentTime - GLOBAL_ANIMATION_START) * SHIMMER_SPEED;
            float pulseTime = (currentTime - GLOBAL_ANIMATION_START) * PULSE_SPEED;
            
            // Вычисляем значения один раз за кадр
            cachedShimmerAlpha = SHIMMER_BASE + SHIMMER_RANGE * (0.5f + 0.5f * (float)Math.sin(animationTime));
            cachedPulseScale = PULSE_BASE + PULSE_RANGE * (0.5f + 0.5f * (float)Math.sin(pulseTime));
        }
    }
    
    /**
     * Получает кэшированное значение мерцания (вызывается для каждой иконки)
     */
    private static float getSynchronizedShimmerAlpha() {
        return cachedShimmerAlpha;
    }
    
    /**
     * Получает кэшированное значение пульсации логотипа
     */
    private static float getSynchronizedPulseScale() {
        return cachedPulseScale;
    }
    
    private long sessionStartTime = 0;
    private boolean enabled = true;
    private float opacity = 1.0f;
    private boolean isPreviewMode = false; // Флаг режима предпросмотра
    
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        if (!enabled) return;
        
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden && !isPreviewMode) return;
        
        // ОПТИМИЗАЦИЯ: Обновляем кэш анимации один раз за кадр
        updateAnimationCache();
        
        // Инициализируем время сессии
        if (sessionStartTime == 0 && client.world != null) {
            sessionStartTime = System.currentTimeMillis();
        }
        if (client.world == null) {
            sessionStartTime = 0;
            return;
        }
        
        // ОПТИМИЗАЦИЯ: Собираем данные один раз
        RenderData data = collectRenderData(client);
        
        // Вычисляем позиции один раз
        int barWidth = calculateDynamicWidth(client, data);
        int barX = 10;
        int barY = 10;
        
        // Применяем масштаб
        context.getMatrices().push();
        context.getMatrices().scale(scale, scale, 1.0f);
        
        int scaledX = (int)(barX / scale);
        int scaledY = (int)(barY / scale);
        
        // Рендерим фон и контур
        renderBackground(context, scaledX, scaledY, barWidth);
        
        // Рендерим содержимое
        renderContent(context, scaledX, scaledY, barWidth, client, data);
        
        context.getMatrices().pop();
    }
    
    /**
     * Структура для хранения данных рендеринга (избегаем повторных вычислений)
     */
    private static class RenderData {
        final String playerName;
        final int fps;
        final int ping;
        final String sessionTime;
        final int punishments;
        
        RenderData(String playerName, int fps, int ping, String sessionTime, int punishments) {
            this.playerName = playerName;
            this.fps = fps;
            this.ping = ping;
            this.sessionTime = sessionTime;
            this.punishments = punishments;
        }
    }
    
    /**
     * ОПТИМИЗИРОВАННЫЙ сбор данных для рендеринга
     */
    private RenderData collectRenderData(MinecraftClient client) {
        String playerName = client.player != null ? client.player.getName().getString() : "Player";
        int fps = client.getCurrentFps();
        int ping = getPing(client);
        String sessionTime = formatTime(System.currentTimeMillis() - sessionStartTime);
        int punishments = getPunishmentsCount();
        
        return new RenderData(playerName, fps, ping, sessionTime, punishments);
    }
    
    /**
     * ОПТИМИЗИРОВАННЫЙ рендеринг фона и контура
     */
    private void renderBackground(DrawContext context, int x, int y, int width) {
        if (USE_SMOOTH_RENDERING) {
            // Многослойная тень
            drawLayeredShadow(context, x, y, width, BAR_HEIGHT, 8, opacity);
            
            // Фон с закруглением справа
            int bgAlpha = (int) (0xE6 * opacity);
            int bgColor = (bgAlpha << 24) | 0x312541;
            
            context.fill(x, y, x + width - CORNER_RADIUS, y + BAR_HEIGHT, bgColor);
            com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, x + width - CORNER_RADIUS * 2, y, CORNER_RADIUS * 2, BAR_HEIGHT, CORNER_RADIUS, bgColor);
            
            // Единый контур
            int outlineAlpha = (int) (0x66 * opacity);
            int outlineColor = (outlineAlpha << 24) | 0x8D00C8;
            drawUnifiedOutline(context, x, y, width, BAR_HEIGHT, CORNER_RADIUS, outlineColor);
        } else {
            // Fallback рендеринг
            renderBackgroundFallback(context, x, y, width);
        }
    }
    
    /**
     * Fallback рендеринг для совместимости
     */
    private void renderBackgroundFallback(DrawContext context, int x, int y, int width) {
        int shadowAlpha = (int) (0x40 * opacity);
        int shadowColor = (shadowAlpha << 24) | 0x000000;
        
        context.fill(x, y + 1, x + width - CORNER_RADIUS, y + 1 + BAR_HEIGHT, shadowColor);
        com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, x + width - CORNER_RADIUS * 2, y + 1, CORNER_RADIUS * 2, BAR_HEIGHT, CORNER_RADIUS, shadowColor);
        
        int bgAlpha = (int) (0xFF * opacity);
        int bgColor = (bgAlpha << 24) | 0x312541;
        
        context.fill(x, y, x + width - CORNER_RADIUS, y + BAR_HEIGHT, bgColor);
        com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, x + width - CORNER_RADIUS * 2, y, CORNER_RADIUS * 2, BAR_HEIGHT, CORNER_RADIUS, bgColor);
        
        int strokeAlpha = (int) (0x40 * opacity);
        int strokeColor = (strokeAlpha << 24) | 0xB700FF;
        drawUnifiedOutline(context, x, y, width, BAR_HEIGHT, CORNER_RADIUS, strokeColor);
    }
    
    /**
     * ОПТИМИЗИРОВАННЫЙ рендеринг содержимого
     */
    private void renderContent(DrawContext context, int x, int y, int width, MinecraftClient client, RenderData data) {
        context.getMatrices().push();
        context.getMatrices().translate(0, 0, 1);
        
        // Scissor только если нужно
        if (!isPreviewMode) {
            context.enableScissor(x + 8, y, x + width - 8, y + BAR_HEIGHT);
        }
        
        int currentX = x + PADDING_LEFT + 2;
        
        // Рендерим элементы
        currentX = renderLogo(context, currentX, y, client);
        currentX = renderPlayerElement(context, currentX, y, client, data.playerName);
        currentX = renderFpsElement(context, currentX, y, client, data.fps);
        currentX = renderPingElement(context, currentX, y, client, data.ping);
        currentX = renderTimeElement(context, currentX, y, client, data.sessionTime);
        renderPunishmentsElement(context, currentX, y, client, data.punishments);
        
        if (!isPreviewMode) {
            context.disableScissor();
        }
        
        context.getMatrices().pop();
    }
    
    // ОПТИМИЗИРОВАННЫЕ методы рендеринга элементов (возвращают новую позицию X)
    private int renderLogo(DrawContext context, int x, int y, MinecraftClient client) {
        renderLogoIcon(context, x, y, client);
        return x + (ICON_SIZE + 4) + ITEM_SPACING;
    }
    
    private int renderPlayerElement(DrawContext context, int x, int y, MinecraftClient client, String playerName) {
        if (!showPlayer) return x;
        
        renderDivider(context, x, y);
        x += DIVIDER_WIDTH + ITEM_SPACING;
        renderIconWithText(context, x, y, ICON_PLAYER, playerName, client, 0);
        return x + ICON_SIZE + 4 + client.textRenderer.getWidth(playerName) + ITEM_SPACING;
    }
    
    private int renderFpsElement(DrawContext context, int x, int y, MinecraftClient client, int fps) {
        if (!showFps) return x;
        
        renderDivider(context, x, y);
        x += DIVIDER_WIDTH + ITEM_SPACING;
        renderIconWithText(context, x, y, ICON_FPS, "fps " + fps, client, 1);
        return x + ICON_SIZE + 4 + FPS_WIDTH + ITEM_SPACING;
    }
    
    private int renderPingElement(DrawContext context, int x, int y, MinecraftClient client, int ping) {
        if (!showPing) return x;
        
        renderDivider(context, x, y);
        x += DIVIDER_WIDTH + ITEM_SPACING;
        renderIconWithText(context, x, y, ICON_PING, ping + " ms", client, 2);
        return x + ICON_SIZE + 4 + PING_WIDTH + ITEM_SPACING;
    }
    
    private int renderTimeElement(DrawContext context, int x, int y, MinecraftClient client, String sessionTime) {
        if (!showTime) return x;
        
        renderDivider(context, x, y);
        x += DIVIDER_WIDTH + ITEM_SPACING;
        renderIconWithText(context, x, y, ICON_TIME, sessionTime, client, 3);
        return x + ICON_SIZE + 4 + client.textRenderer.getWidth(sessionTime) + ITEM_SPACING;
    }
    
    private int renderPunishmentsElement(DrawContext context, int x, int y, MinecraftClient client, int punishments) {
        if (!showPunishments) return x;
        
        renderDivider(context, x, y);
        x += DIVIDER_WIDTH + ITEM_SPACING;
        renderIconWithText(context, x, y, ICON_PUNISH, String.valueOf(punishments), client, 4);
        return x + ICON_SIZE + 4 + client.textRenderer.getWidth(String.valueOf(punishments)) + ITEM_SPACING;
    }
    /**
     * ОПТИМИЗИРОВАННЫЙ рендеринг логотипа с кэшированной пульсацией
     */
    private void renderLogoIcon(DrawContext context, int x, int y, MinecraftClient client) {
        int iconSize = ICON_SIZE + 4;
        int iconY = y + (BAR_HEIGHT - iconSize) / 2;
        
        // Используем кэшированное значение пульсации
        float pulseScale = getSynchronizedPulseScale();
        
        // Применяем пульсацию только если она значительна (избегаем лишних матричных операций)
        if (Math.abs(pulseScale - 1.0f) > 0.001f) {
            context.getMatrices().push();
            
            float centerX = x + iconSize / 2.0f;
            float centerY = iconY + iconSize / 2.0f;
            context.getMatrices().translate(centerX, centerY, 0);
            context.getMatrices().scale(pulseScale, pulseScale, 1.0f);
            context.getMatrices().translate(-centerX, -centerY, 0);
            
            renderIconTexture(context, ICON_LOGO, x + 1, iconY, iconSize, opacity);
            
            context.getMatrices().pop();
        } else {
            // Рендерим без матричных операций если пульсация минимальна
            renderIconTexture(context, ICON_LOGO, x + 1, iconY, iconSize, opacity);
        }
    }
    
    /**
     * ОПТИМИЗИРОВАННЫЙ рендеринг текстуры иконки
     */
    private void renderIconTexture(DrawContext context, Identifier texture, int x, int y, int size, float alpha) {
        if (alpha < 0.01f) return; // Не рендерим если почти прозрачно
        
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
        
        context.drawTexture(RenderLayer::getGuiTextured, texture, x, y, 0, 0, size, size, size, size);
        
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
    }
    
    /**
     * ОПТИМИЗИРОВАННЫЙ рендеринг иконки с текстом и синхронизированным мерцанием
     */
    private void renderIconWithText(DrawContext context, int x, int y, Identifier icon, String text, MinecraftClient client, int iconIndex) {
        int iconSize = ICON_SIZE;
        int iconY = y + (BAR_HEIGHT - iconSize) / 2;
        
        // Используем кэшированное значение мерцания
        float shimmerAlpha = getSynchronizedShimmerAlpha();
        
        // Рендерим иконку с мерцанием
        renderIconTexture(context, icon, x, iconY, iconSize, opacity * shimmerAlpha);
        
        // Рендерим текст с тем же мерцанием
        int textX = x + iconSize + 4;
        int textY = y + (BAR_HEIGHT - 8) / 2;
        
        int baseTextColor = applyOpacity(COLOR_TEXT);
        int alpha = (int)((baseTextColor >> 24 & 0xFF) * shimmerAlpha);
        int textColor = (alpha << 24) | (baseTextColor & 0x00FFFFFF);
        
        if (USE_SMOOTH_RENDERING) {
            com.whiterise.adminpanel.util.SmoothHudRenderer.drawSmoothText(context, text, textX, textY, textColor);
        } else {
            context.drawText(client.textRenderer, text, textX, textY, textColor, false);
        }
    }
    
    /**
     * Рендерит вертикальный разделитель (гладкий) с учётом прозрачности
     */
    private void renderDivider(DrawContext context, int x, int y) {
        int dividerY = y + (BAR_HEIGHT - DIVIDER_HEIGHT) / 2;
        
        if (USE_SMOOTH_RENDERING) {
            // Гладкий разделитель с градиентом и прозрачностью
            for (int i = 0; i < DIVIDER_HEIGHT; i++) {
                float alpha = 1.0f - Math.abs(i - DIVIDER_HEIGHT / 2.0f) / (DIVIDER_HEIGHT / 2.0f);
                int alphaInt = (int)(alpha * 64 * opacity); // 25% максимум с учётом opacity
                int color = (alphaInt << 24) | 0x8D00C8;
                context.fill(x, dividerY + i, x + DIVIDER_WIDTH, dividerY + i + 1, color);
            }
        } else {
            // Обычный разделитель с прозрачностью
            int dividerColor = applyOpacity(COLOR_DIVIDER);
            context.fill(x, dividerY, x + DIVIDER_WIDTH, dividerY + DIVIDER_HEIGHT, dividerColor);
        }
    }
    
    /**
     * ОПТИМИЗИРОВАННОЕ вычисление динамической ширины бара
     */
    private int calculateDynamicWidth(MinecraftClient client, RenderData data) {
        int width = PADDING_LEFT + PADDING_RIGHT;
        
        // Логотип (всегда показывается)
        width += (ICON_SIZE + 4) + ITEM_SPACING;
        
        // Остальные элементы
        if (showPlayer) {
            width += DIVIDER_WIDTH + ITEM_SPACING + ICON_SIZE + 4 + client.textRenderer.getWidth(data.playerName) + ITEM_SPACING;
        }
        if (showFps) {
            width += DIVIDER_WIDTH + ITEM_SPACING + ICON_SIZE + 4 + FPS_WIDTH + ITEM_SPACING;
        }
        if (showPing) {
            width += DIVIDER_WIDTH + ITEM_SPACING + ICON_SIZE + 4 + PING_WIDTH + ITEM_SPACING;
        }
        if (showTime) {
            width += DIVIDER_WIDTH + ITEM_SPACING + ICON_SIZE + 4 + client.textRenderer.getWidth(data.sessionTime) + ITEM_SPACING;
        }
        if (showPunishments) {
            width += DIVIDER_WIDTH + ITEM_SPACING + ICON_SIZE + 4 + client.textRenderer.getWidth(String.valueOf(data.punishments)) + ITEM_SPACING;
        }
        
        return width;
    }
    
    /**
     * Получает пинг игрока
     */
    private int getPing(MinecraftClient client) {
        if (client.player == null) return 0;
        
        PlayerListEntry playerEntry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        if (playerEntry != null) {
            return playerEntry.getLatency();
        }
        return 0;
    }
    
    /**
     * Получает количество наказаний
     */
    private int getPunishmentsCount() {
        return (int) AdminPanelClient.getPunishmentManager().getPunishmentHistory().stream()
            .filter(record -> record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE 
                           && record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN)
            .count();
    }
    
    /**
     * Форматирует время
     */
    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, secs);
        } else {
            return String.format("%02d:%02d", minutes, secs);
        }
    }
    
    /**
     * Рисует многослойную падающую тень с оптимизацией
     */
    private void drawLayeredShadow(DrawContext context, int x, int y, int width, int height, int radius, float opacity) {
        if (opacity < 0.1f) return; // Не рисуем тень если слишком прозрачно
        
        int shadow1Alpha = (int) (0x10 * opacity);
        int shadow2Alpha = (int) (0x15 * opacity);
        int shadow3Alpha = (int) (0x20 * opacity);
        
        // Используем стандартный fillRounded вместо специального fillRoundedRight
        com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, x + 1, y + 2, width, height, radius, (shadow1Alpha << 24) | 0x000000);
        com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, x + 1, y + 3, width, height, radius, (shadow2Alpha << 24) | 0x000000);
        com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, x + 2, y + 4, width, height, radius, (shadow3Alpha << 24) | 0x000000);
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setOpacity(float opacity) {
        this.opacity = Math.max(0.0f, Math.min(1.0f, opacity));
    }
    
    /**
     * Применяет текущую прозрачность к цвету
     */
    private int applyOpacity(int color) {
        int alpha = (color >> 24) & 0xFF;
        int newAlpha = (int) (alpha * opacity);
        return (newAlpha << 24) | (color & 0x00FFFFFF);
    }
    
    public float getOpacity() {
        return opacity;
    }
    
    // Геттеры и сеттеры для элементов
    public boolean isShowPlayer() {
        return showPlayer;
    }
    
    public void setShowPlayer(boolean showPlayer) {
        this.showPlayer = showPlayer;
    }
    
    public boolean isShowFps() {
        return showFps;
    }
    
    public void setShowFps(boolean showFps) {
        this.showFps = showFps;
    }
    
    public boolean isShowPing() {
        return showPing;
    }
    
    public void setShowPing(boolean showPing) {
        this.showPing = showPing;
    }
    
    public boolean isShowTime() {
        return showTime;
    }
    
    public void setShowTime(boolean showTime) {
        this.showTime = showTime;
    }
    
    public boolean isShowPunishments() {
        return showPunishments;
    }
    
    public void setShowPunishments(boolean showPunishments) {
        this.showPunishments = showPunishments;
    }
    
    public float getScale() {
        return scale;
    }
    
    public void setScale(float scale) {
        this.scale = Math.max(0.5f, Math.min(2.0f, scale));
    }
    
    public boolean isPreviewMode() {
        return isPreviewMode;
    }
    
    public void setPreviewMode(boolean previewMode) {
        this.isPreviewMode = previewMode;
    }
    
    /**
     * ОПТИМИЗИРОВАННЫЙ рендеринг единого контура с закруглением справа
     */
    private void drawUnifiedOutline(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        // Левая и горизонтальные границы (прямые линии)
        context.fill(x, y, x + 1, y + height, color); // Левая
        context.fill(x, y, x + width - radius, y + 1, color); // Верхняя
        context.fill(x, y + height - 1, x + width - radius, y + height, color); // Нижняя
        
        // ОПТИМИЗИРОВАННОЕ закругление - используем готовый метод RenderUtils
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, x + width - radius * 2, y, radius * 2, height, radius, color);
    }
}
