package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.util.DrawHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.awt.Color;

/**
 * Современный слайдер с красивым дизайном
 * Использует улучшенную систему рендеринга из DrawHelper
 */
public class ModernSliderWidget extends SliderWidget {
    private final double minValue;
    private final double maxValue;
    private final double step;
    private final ValueChangeCallback callback;
    
    // Цвета
    private static final int COLOR_BG = 0xFF2a3441;
    private static final int COLOR_FILL = 0xFF00D9FF;
    private static final int COLOR_THUMB = 0xFFFFFFFF;
    private static final int COLOR_THUMB_SHADOW = 0x50000000;
    private static final int COLOR_THUMB_HOVER = 0x30FFFFFF;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    
    public interface ValueChangeCallback {
        void onValueChanged(double value);
    }
    
    public ModernSliderWidget(int x, int y, int width, int height, 
                             double minValue, double maxValue, double initialValue, 
                             double step, ValueChangeCallback callback) {
        super(x, y, width, height, Text.empty(), (initialValue - minValue) / (maxValue - minValue));
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.step = step;
        this.callback = callback;
        updateMessage();
    }
    
    @Override
    protected void updateMessage() {
        // Не показываем сообщение, значение будет справа от слайдера
        setMessage(Text.empty());
    }
    
    @Override
    protected void applyValue() {
        // Применяем шаг
        double rawValue = minValue + (maxValue - minValue) * value;
        double steppedValue = Math.round(rawValue / step) * step;
        this.value = (steppedValue - minValue) / (maxValue - minValue);
        
        // Вызываем callback
        if (callback != null) {
            callback.onValueChanged(getCurrentValue());
        }
    }
    
    @Override
    public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        int x = getX();
        int y = getY();
        
        // Используем улучшенный DrawHelper для рендеринга слайдера
        Color trackColor = new Color(117, 117, 117); // Серая дорожка
        Color fillColor = ColorManager.getC5(); // Акцентный цвет из схемы
        Color thumbColor = Color.WHITE;
        
        DrawHelper.drawSlider(context, 
            x, y, 
            width, height, 
            value, 
            trackColor, fillColor, thumbColor);
        
        // Деления шкалы (маленькие черточки)
        if (width > 120) {
            for (int i = 0; i <= 4; i++) {
                int markX = x + (width * i / 4);
                context.fill(markX, y + height, markX + 1, y + height + 4, 0x88FFFFFF);
            }
        }
    }
    
    /**
     * Получает текущее значение слайдера
     */
    public double getCurrentValue() {
        return minValue + (maxValue - minValue) * value;
    }
    
    /**
     * Устанавливает значение слайдера
     */
    public void setCurrentValue(double newValue) {
        this.value = (newValue - minValue) / (maxValue - minValue);
        applyValue();
    }
    
    /**
     * Проверяет, перетаскивается ли слайдер
     */
    private boolean isDragging() {
        // В SliderWidget нет публичного метода для проверки, но мы можем проверить через hovered
        return this.hovered && this.active;
    }
}
