package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Информация о сервере
 */
public class ServerInfoHudElement extends HudElement {
    private static final int COLOR_BG = 0xCC1A2332;
    private static final int COLOR_ACCENT = 0xFF00D9FF;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    
    public ServerInfoHudElement() {
        super("server_info", "Сервер");
        setPosition(HudPosition.TOP_RIGHT);
        setOffsetY(10);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Получаем адрес сервера
        String serverAddress = "Неизвестно";
        if (client.getCurrentServerEntry() != null) {
            serverAddress = client.getCurrentServerEntry().address;
        }
        
        // Фон
        int width = getWidth();
        int height = getHeight();
        int bgColor = applyOpacity(COLOR_BG);
        
        RenderUtils.fillRounded(context, 0, 0, width, height, 6, bgColor);
        
        // Иконка
        context.drawText(client.textRenderer, "🌐", 6, 11, COLOR_ACCENT, false);
        
        // Текст
        String displayAddress = serverAddress;
        if (client.textRenderer.getWidth(displayAddress) > width - 30) {
            displayAddress = client.textRenderer.trimToWidth(displayAddress, width - 35) + "...";
        }
        context.drawText(client.textRenderer, displayAddress, 24, 11, COLOR_TEXT, false);
    }
    
    @Override
    public int getWidth() {
        return 200;
    }
    
    @Override
    public int getHeight() {
        return 28;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
