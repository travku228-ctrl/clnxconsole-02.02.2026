package com.whiterise.adminpanel.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public class AnimatedToggle extends ClickableWidget {
    private boolean enabled;
    private float animationProgress; // 0.0f (OFF) → 1.0f (ON)
    
    public AnimatedToggle(int x, int y, int width, int height, boolean initialState) {
        super(x, y, width, height, Text.empty());
        this.enabled = initialState;
        this.animationProgress = initialState ? 1.0f : 0.0f;
    }
    
    @Override
    public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        // Плавная анимация
        float target = enabled ? 1.0f : 0.0f;
        animationProgress += (target - animationProgress) * delta * 10.0f;
        
        // Цвет фона с интерполяцией
        int colorFrom = 0xFF757575; // Серый
        int colorTo = 0xFF4CAF50;   // Зеленый
        int red = (int)(0x75 + (0x4C - 0x75) * animationProgress);
        int green = (int)(0x75 + (0xAF - 0x75) * animationProgress);
        int blue = (int)(0x75 + (0x50 - 0x75) * animationProgress);
        int bgColor = 0xFF000000 | (red << 16) | (green << 8) | blue;
        
        context.fill(getX(), getY(), getX() + width, getY() + height, bgColor);
        
        // Анимированный ползунок
        int sliderSize = height - 6;
        int maxSlide = width - 6 - sliderSize;
        int sliderX = getX() + 3 + (int)(maxSlide * animationProgress);
        int sliderY = getY() + 3;
        
        context.fill(sliderX, sliderY, sliderX + sliderSize, sliderY + sliderSize, 0xFFFFFFFF);
        
        // Галочка при включении
        if (animationProgress > 0.8f) {
            var mc = MinecraftClient.getInstance();
            int checkX = sliderX + sliderSize/2 - 3;
            int checkY = sliderY + sliderSize/2 - 3;
            context.drawText(mc.textRenderer, "✓", checkX, checkY, 0xFF4CAF50, false);
        }
    }
    
    @Override
    public void onClick(double mouseX, double mouseY) {
        this.enabled = !enabled;
        
        // Звук клика
        var mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.3f, enabled ? 1.2f : 0.8f);
        }
    }
    
    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE, 
            Text.literal("Toggle: " + (enabled ? "ON" : "OFF")));
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}
