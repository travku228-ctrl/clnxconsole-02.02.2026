package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.manager.AntiCheatSessionManager;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.render.RenderLayer;

public class AntiCheatScreen extends Screen {
    private final String targetPlayer;
    
    // Цветовая палитра - ЗАМЕНЕНЫ НА ColorManager (кроме кнопок и текста)
    private int COLOR_BG_DARK() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    // ФИКСИРОВАННЫЕ цвета (не зависят от темы)
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;    // Белый всегда
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;  // Светло-серый всегда
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;      // Серый всегда
    private static final int COLOR_ACCENT_FIXED = 0xFF00D9FF;
    private static final int COLOR_SUCCESS_FIXED = 0xFF10b981;
    private static final int COLOR_WARNING_FIXED = 0xFFf59e0b;
    private static final int COLOR_DANGER_FIXED = 0xFFef4444;
    
    // Иконки для кнопок
    private static final Identifier ICON_START_CHECK = Identifier.of("whiterise_adminpanel", "textures/icons/start_check.png");
    private static final Identifier ICON_TELEPORT = Identifier.of("whiterise_adminpanel", "textures/icons/teleport.png");
    private static final Identifier ICON_ADD_TIME = Identifier.of("whiterise_adminpanel", "textures/icons/add_time.png");
    private static final Identifier ICON_FREEZE_TIME = Identifier.of("whiterise_adminpanel", "textures/icons/freeze_time.png");
    private static final Identifier ICON_CHECK_GREEN = Identifier.of("whiterise_adminpanel", "textures/icons/check_green.png");
    private static final Identifier ICON_CROSS_RED = Identifier.of("whiterise_adminpanel", "textures/icons/cross_red.png");
    
    public AntiCheatScreen(String targetPlayer) {
        super(Text.literal("Проверка - " + targetPlayer));
        this.targetPlayer = targetPlayer;
    }
    
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // НЕ вызываем super.renderBackground() чтобы избежать блюра
        // Фон рисуется в методе render() через fillGradient()
    }
    
    @Override
    protected void init() {
        // Кнопка "Назад" будет рендериться вручную в стиле GUI
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Фон в стиле GUI (темный градиент)
        context.fillGradient(0, 0, this.width, this.height, COLOR_BG_DARK(), 0xFF0f1419);
        
        // КНОПКА "НАЗАД" В СТИЛЕ GUI
        int backButtonWidth = 100;
        int backButtonHeight = 30;
        int backButtonX = 20;
        int backButtonY = 20;
        
        boolean isBackHovered = mouseX >= backButtonX && mouseX <= backButtonX + backButtonWidth && 
                               mouseY >= backButtonY && mouseY <= backButtonY + backButtonHeight;
        
        int backButtonColor = isBackHovered ? adjustBrightness(COLOR_BG_CARD(), 1.2f) : COLOR_BG_CARD();
        RenderUtils.fillRounded(context, backButtonX, backButtonY, backButtonWidth, backButtonHeight, 8, backButtonColor);
        RenderUtils.drawRoundedBorder(context, backButtonX, backButtonY, backButtonWidth, backButtonHeight, 8, COLOR_BORDER());
        
        String backText = "← Назад";
        int backTextWidth = this.textRenderer.getWidth(backText);
        context.drawText(this.textRenderer, backText, 
            backButtonX + (backButtonWidth - backTextWidth) / 2, 
            backButtonY + (backButtonHeight - 8) / 2, COLOR_TEXT_PRIMARY, false);
        
        boolean hasSession = AntiCheatSessionManager.hasActiveSession();
        
        // Карточка с информацией
        int cardWidth = 600;
        int cardHeight = hasSession ? 350 : 220; // УМЕНЬШЕНО: меньше высота
        int cardX = (this.width - cardWidth) / 2;
        int cardY = (this.height - cardHeight) / 2 - 50;
        
        // Тень карточки
        context.fill(cardX + 2, cardY + 2, cardX + cardWidth + 2, cardY + cardHeight + 2, 0x44000000);
        
        // Фон карточки - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, cardX, cardY, cardWidth, cardHeight, 12, COLOR_BG_CARD());
        
        // Границы - СКРУГЛЕННЫЕ
        RenderUtils.drawRoundedBorder(context, cardX, cardY, cardWidth, cardHeight, 12, COLOR_BORDER());
        
        // КОМПАКТНЫЙ ЗАГОЛОВОК (меньше, без акцента)
        String title = "Проверка игрока";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, cardY + 20, COLOR_TEXT_SECONDARY, false);
        
        // КРУПНЫЙ НИК ИГРОКА (основной фокус)
        int playerInfoY = cardY + 45;
        int playerNameWidth = this.textRenderer.getWidth(targetPlayer);
        context.getMatrices().push();
        context.getMatrices().scale(1.5f, 1.5f, 1.0f);
        context.drawText(this.textRenderer, targetPlayer, 
            (int)((this.width - playerNameWidth * 1.5f) / (2 * 1.5f)), 
            (int)(playerInfoY / 1.5f), COLOR_TEXT_PRIMARY, true);
        context.getMatrices().pop();
        
        if (hasSession) {
            var session = AntiCheatSessionManager.getActiveSession();
            
            // КОМПАКТНЫЙ СТАТУС-БЕЙДЖ
            int statusY = cardY + 80;
            String statusText = "● Активна";
            int statusWidth = this.textRenderer.getWidth(statusText);
            int statusX = (this.width - statusWidth) / 2 - 5;
            
            // Фон бейджа - СКРУГЛЕННЫЙ (меньше)
            RenderUtils.fillRounded(context, statusX - 4, statusY - 2, statusWidth + 14, 14, 6, COLOR_SUCCESS_FIXED);
            context.drawText(this.textRenderer, statusText, statusX, statusY, COLOR_TEXT_PRIMARY, false);
            
            // ТАЙМЕР (отдельная строка, без лишних слов)
            int timerY = cardY + 110;
            if (!session.isTimeExpired()) {
                String timer = session.getFormattedRemainingTime();
                int timerWidth = this.textRenderer.getWidth(timer);
                context.drawText(this.textRenderer, timer, (this.width - timerWidth) / 2, timerY, COLOR_ACCENT_FIXED, false);
            } else {
                String timer = "Время истекло";
                int timerWidth = this.textRenderer.getWidth(timer);
                context.drawText(this.textRenderer, timer, (this.width - timerWidth) / 2, timerY, COLOR_DANGER_FIXED, false);
            }
            
            // ПРЕДУПРЕЖДЕНИЕ (компактное, с иконкой, без яркого желтого)
            int warningY = cardHeight + cardY - 35;
            String warning = "⚠ Закрытие GUI не завершает проверку";
            int warningWidth = this.textRenderer.getWidth(warning);
            context.drawText(this.textRenderer, warning, (this.width - warningWidth) / 2, warningY, COLOR_TEXT_MUTED, false);
            
        } else {
            // Краткая инструкция для начала проверки
            int instructY = cardY + 90;
            String instr = "Нажмите кнопку ниже для начала проверки";
            int instrWidth = this.textRenderer.getWidth(instr);
            context.drawText(this.textRenderer, instr, (this.width - instrWidth) / 2, instructY, COLOR_TEXT_SECONDARY, false);
        }
        
        super.render(context, mouseX, mouseY, delta);
        
        // Рендерим красивые кнопки поверх всего
        renderCustomButtons(context, mouseX, mouseY);
    }
    
    /**
     * Рендерит красивые скругленные кнопки
     * УЛУЧШЕНО: упрощенная структура - телепорт центральный, управление временем второстепенное, завершение внизу
     */
    private void renderCustomButtons(DrawContext context, int mouseX, int mouseY) {
        boolean hasSession = AntiCheatSessionManager.hasActiveSession();
        
        if (!hasSession) {
            // Кнопка "Начать проверку" (ГЛАВНАЯ, ЦЕНТРАЛЬНАЯ)
            int buttonWidth = 200;
            int buttonHeight = 40; // Увеличено для акцента
            int buttonX = (this.width - buttonWidth) / 2;
            int buttonY = this.height / 2 - 10;
            
            boolean isHovered = mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                               mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
            
            // Hover эффект
            if (isHovered) {
                buttonY -= 2;
                context.fill(buttonX + 2, buttonY + buttonHeight + 2, buttonX + buttonWidth + 2, buttonY + buttonHeight + 4, 0x88000000);
            }
            
            int buttonColor = isHovered ? adjustBrightness(COLOR_SUCCESS_FIXED, 1.15f) : COLOR_SUCCESS_FIXED;
            RenderUtils.fillRounded(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonColor);
            
            String btnText = "Начать проверку";
            int btnTextWidth = this.textRenderer.getWidth(btnText);
            
            // Иконка слева от текста (текст по центру)
            int iconSize = 16;
            int textX = buttonX + (buttonWidth - btnTextWidth) / 2;
            int iconX = textX - iconSize - 6;
            int iconY = buttonY + (buttonHeight - iconSize) / 2;
            
            context.drawTexture(RenderLayer::getGuiTextured, ICON_START_CHECK, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            context.drawText(this.textRenderer, btnText, textX, buttonY + (buttonHeight - 8) / 2, COLOR_TEXT_PRIMARY, true);
        } else {
            // АКТИВНАЯ СЕССИЯ - упрощенная структура кнопок
            
            // ЦЕНТРАЛЬНАЯ КНОПКА: Телепортация (ГЛАВНОЕ ДЕЙСТВИЕ)
            int mainButtonWidth = 240;
            int mainButtonHeight = 40;
            int teleportY = this.height / 2 - 90;
            int buttonX = (this.width - mainButtonWidth) / 2;
            
            boolean isTeleportHovered = mouseX >= buttonX && mouseX <= buttonX + mainButtonWidth && 
                                       mouseY >= teleportY && mouseY <= teleportY + mainButtonHeight;
            
            if (isTeleportHovered) {
                teleportY -= 2;
                context.fill(buttonX + 2, teleportY + mainButtonHeight + 2, buttonX + mainButtonWidth + 2, teleportY + mainButtonHeight + 4, 0x88000000);
            }
            
            int teleportColor = isTeleportHovered ? adjustBrightness(COLOR_ACCENT_FIXED, 1.15f) : COLOR_ACCENT_FIXED;
            RenderUtils.fillRounded(context, buttonX, teleportY, mainButtonWidth, mainButtonHeight, 8, teleportColor);
            
            String teleportText = "Телепортироваться";
            int teleportTextWidth = this.textRenderer.getWidth(teleportText);
            
            // Иконка слева от текста (текст по центру)
            int iconSize = 16;
            int textX = buttonX + (mainButtonWidth - teleportTextWidth) / 2;
            int iconX = textX - iconSize - 6;
            int iconY = teleportY + (mainButtonHeight - iconSize) / 2;
            
            context.drawTexture(RenderLayer::getGuiTextured, ICON_TELEPORT, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            context.drawText(this.textRenderer, teleportText, textX, teleportY + (mainButtonHeight - 8) / 2, COLOR_TEXT_PRIMARY, true);
            
            // ВТОРОСТЕПЕННЫЕ КНОПКИ: Управление временем (меньше, в ряд)
            int buttonWidth2 = 160;
            int buttonHeight2 = 32;
            int startX = (this.width - (buttonWidth2 * 2 + 15)) / 2;
            int buttonY = this.height / 2 - 25;
            
            // Кнопка "Продлить"
            boolean isAddTimeHovered = mouseX >= startX && mouseX <= startX + buttonWidth2 && 
                                      mouseY >= buttonY && mouseY <= buttonY + buttonHeight2;
            
            int addTimeY = buttonY;
            if (isAddTimeHovered) {
                addTimeY -= 2;
                context.fill(startX + 2, addTimeY + buttonHeight2 + 2, startX + buttonWidth2 + 2, addTimeY + buttonHeight2 + 4, 0x88000000);
            }
            
            int addTimeColor = isAddTimeHovered ? adjustBrightness(COLOR_WARNING_FIXED, 1.15f) : COLOR_WARNING_FIXED;
            RenderUtils.fillRounded(context, startX, addTimeY, buttonWidth2, buttonHeight2, 8, addTimeColor);
            
            String addTimeText = "Продлить";
            int addTimeTextWidth = this.textRenderer.getWidth(addTimeText);
            
            // Иконка слева от текста (текст по центру)
            textX = startX + (buttonWidth2 - addTimeTextWidth) / 2;
            iconX = textX - iconSize - 6;
            iconY = addTimeY + (buttonHeight2 - iconSize) / 2;
            
            context.drawTexture(RenderLayer::getGuiTextured, ICON_ADD_TIME, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            context.drawText(this.textRenderer, addTimeText, textX, addTimeY + (buttonHeight2 - 8) / 2, COLOR_TEXT_PRIMARY, false);
            
            // Кнопка "Заморозить"
            int stopTimeX = startX + buttonWidth2 + 15;
            boolean isStopTimeHovered = mouseX >= stopTimeX && mouseX <= stopTimeX + buttonWidth2 && 
                                       mouseY >= buttonY && mouseY <= buttonY + buttonHeight2;
            
            int stopTimeY = buttonY;
            if (isStopTimeHovered) {
                stopTimeY -= 2;
                context.fill(stopTimeX + 2, stopTimeY + buttonHeight2 + 2, stopTimeX + buttonWidth2 + 2, stopTimeY + buttonHeight2 + 4, 0x88000000);
            }
            
            int stopTimeColor = isStopTimeHovered ? adjustBrightness(COLOR_ACCENT_FIXED, 1.15f) : COLOR_ACCENT_FIXED;
            RenderUtils.fillRounded(context, stopTimeX, stopTimeY, buttonWidth2, buttonHeight2, 8, stopTimeColor);
            
            String stopTimeText = "Заморозить";
            int stopTimeTextWidth = this.textRenderer.getWidth(stopTimeText);
            
            // Иконка слева от текста (текст по центру)
            textX = stopTimeX + (buttonWidth2 - stopTimeTextWidth) / 2;
            iconX = textX - iconSize - 6;
            iconY = stopTimeY + (buttonHeight2 - iconSize) / 2;
            
            context.drawTexture(RenderLayer::getGuiTextured, ICON_FREEZE_TIME, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            context.drawText(this.textRenderer, stopTimeText, textX, stopTimeY + (buttonHeight2 - 8) / 2, COLOR_TEXT_PRIMARY, false);
            
            // НИЖНЯЯ ЗОНА: Завершение проверки (ОТДЕЛЕНО, больше отступ)
            buttonY += 70; // Больше отступ для визуального разделения
            
            // Кнопка "Завершить"
            boolean isReleaseHovered = mouseX >= startX && mouseX <= startX + buttonWidth2 && 
                                      mouseY >= buttonY && mouseY <= buttonY + buttonHeight2;
            
            int releaseY = buttonY;
            if (isReleaseHovered) {
                releaseY -= 2;
                context.fill(startX + 2, releaseY + buttonHeight2 + 2, startX + buttonWidth2 + 2, releaseY + buttonHeight2 + 4, 0x88000000);
            }
            
            int releaseColor = isReleaseHovered ? adjustBrightness(COLOR_SUCCESS_FIXED, 1.15f) : COLOR_SUCCESS_FIXED;
            RenderUtils.fillRounded(context, startX, releaseY, buttonWidth2, buttonHeight2, 8, releaseColor);
            
            String releaseText = "Завершить";
            int releaseTextWidth = this.textRenderer.getWidth(releaseText);
            
            // Иконка слева от текста (текст по центру)
            textX = startX + (buttonWidth2 - releaseTextWidth) / 2;
            iconX = textX - iconSize - 6;
            iconY = releaseY + (buttonHeight2 - iconSize) / 2;
            
            context.drawTexture(RenderLayer::getGuiTextured, ICON_CHECK_GREEN, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            context.drawText(this.textRenderer, releaseText, textX, releaseY + (buttonHeight2 - 8) / 2, COLOR_TEXT_PRIMARY, false);
            
            // Кнопка "Забанить"
            int banX = startX + buttonWidth2 + 15;
            boolean isBanHovered = mouseX >= banX && mouseX <= banX + buttonWidth2 && 
                                  mouseY >= buttonY && mouseY <= buttonY + buttonHeight2;
            
            int banY = buttonY;
            if (isBanHovered) {
                banY -= 2;
                context.fill(banX + 2, banY + buttonHeight2 + 2, banX + buttonWidth2 + 2, banY + buttonHeight2 + 4, 0x88000000);
            }
            
            int banColor = isBanHovered ? adjustBrightness(COLOR_DANGER_FIXED, 1.15f) : COLOR_DANGER_FIXED;
            RenderUtils.fillRounded(context, banX, banY, buttonWidth2, buttonHeight2, 8, banColor);
            
            String banText = "Забанить";
            int banTextWidth = this.textRenderer.getWidth(banText);
            
            // Иконка слева от текста (текст по центру)
            textX = banX + (buttonWidth2 - banTextWidth) / 2;
            iconX = textX - iconSize - 6;
            iconY = banY + (buttonHeight2 - iconSize) / 2;
            
            context.drawTexture(RenderLayer::getGuiTextured, ICON_CROSS_RED, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
            context.drawText(this.textRenderer, banText, textX, banY + (buttonHeight2 - 8) / 2, COLOR_TEXT_PRIMARY, false);
        }
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    private void sendCommand(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.networkHandler.sendChatCommand(command.substring(1));
        }
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        
        // Кнопка "Назад"
        int backButtonWidth = 100;
        int backButtonHeight = 30;
        int backButtonX = 20;
        int backButtonY = 20;
        
        if (mouseX >= backButtonX && mouseX <= backButtonX + backButtonWidth && 
            mouseY >= backButtonY && mouseY <= backButtonY + backButtonHeight) {
            this.client.setScreen(new AdminPanelScreen());
            return true;
        }
        
        boolean hasSession = AntiCheatSessionManager.hasActiveSession();
        
        if (!hasSession) {
            // Кнопка "Начать проверку"
            int buttonWidth = 200;
            int buttonHeight = 40;
            int buttonX = (this.width - buttonWidth) / 2;
            int buttonY = this.height / 2 - 10;
            
            if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                sendCommand("/check start " + targetPlayer);
                AntiCheatSessionManager.startSession(targetPlayer);
                this.clearAndInit();
                return true;
            }
        } else {
            // АКТИВНАЯ СЕССИЯ - обработка кликов по кнопкам управления
            
            // Кнопка телепортации (ЦЕНТРАЛЬНАЯ)
            int mainButtonWidth = 240;
            int mainButtonHeight = 40;
            int teleportY = this.height / 2 - 90;
            int buttonX = (this.width - mainButtonWidth) / 2;
            
            if (mouseX >= buttonX && mouseX <= buttonX + mainButtonWidth && 
                mouseY >= teleportY && mouseY <= teleportY + mainButtonHeight) {
                sendCommand("/tp " + targetPlayer);
                return true;
            }
            
            // Управление временем
            int buttonWidth2 = 160;
            int buttonHeight2 = 32;
            int startX = (this.width - (buttonWidth2 * 2 + 15)) / 2;
            int buttonY = this.height / 2 - 25;
            
            // Кнопка "Продлить"
            if (mouseX >= startX && mouseX <= startX + buttonWidth2 && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight2) {
                sendCommand("/check addtime");
                return true;
            }
            
            // Кнопка "Заморозить"
            int stopTimeX = startX + buttonWidth2 + 15;
            if (mouseX >= stopTimeX && mouseX <= stopTimeX + buttonWidth2 && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight2) {
                sendCommand("/check stoptime");
                return true;
            }
            
            // Завершение проверки
            buttonY += 70;
            
            // Кнопка "Завершить"
            if (mouseX >= startX && mouseX <= startX + buttonWidth2 && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight2) {
                this.client.setScreen(new ConfirmActionScreen(targetPlayer, "release"));
                return true;
            }
            
            // Кнопка "Забанить"
            int banX = startX + buttonWidth2 + 15;
            if (mouseX >= banX && mouseX <= banX + buttonWidth2 && 
                mouseY >= buttonY && mouseY <= buttonY + buttonHeight2) {
                this.client.setScreen(new ConfirmActionScreen(targetPlayer, "ban"));
                return true;
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    

}

