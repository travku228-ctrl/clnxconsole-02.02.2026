package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.AdminPanelClient;
import com.whiterise.adminpanel.data.PunishmentRule;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class PunishmentScreen extends Screen {
    private static final Identifier ICON_CHECK_GREEN = new Identifier("whiterise_adminpanel", "textures/icons/check_green.png");
    
    // Цвета - интегрированы с ColorManager
    private int COLOR_BG_DARKEST() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_DARK() { return ColorManager.getC2().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BG_HOVER() { return adjustBrightness(ColorManager.getC3().getRGB(), 1.15f); }
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    // ФИКСИРОВАННЫЕ цвета (не зависят от темы)
    private static final int COLOR_ACCENT_FIXED = 0xFF00D9FF;
    private static final int COLOR_SUCCESS_FIXED = 0xFF10b981;
    private static final int COLOR_WARNING_FIXED = 0xFFf59e0b;
    private static final int COLOR_DANGER_FIXED = 0xFFef4444;
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;
    
    private final String targetPlayer;
    private int scrollOffset = 0;
    private String selectedCategory = "mutes"; // mutes, bans (убрали unmute и other)
    private int hoveredItemIndex = -1; // Для отслеживания наведения
    
    public PunishmentScreen(String targetPlayer) {
        super(Text.literal("Наказания - " + targetPlayer));
        this.targetPlayer = targetPlayer;
    }
    
    @Override
    protected void init() {
        // Кнопка назад - рендерится вручную для красивого вида
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Градиентный фон (современный стиль)
        context.fillGradient(0, 0, this.width, this.height/2, COLOR_BG_DARKEST(), COLOR_BG_DARK());
        context.fillGradient(0, this.height/2, this.width, this.height, COLOR_BG_DARK(), COLOR_BG_DARKEST());
        
        // Заголовок (без CAPS)
        String title = "Игрок: " + targetPlayer;
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, 30, COLOR_TEXT_PRIMARY, true);
        
        // Рендер красивой кнопки "Назад"
        renderBackButton(context, mouseX, mouseY);
        
        // Рендер кнопок категорий (вручную, т.к. SilentButtonWidget не рендерит)
        renderCategoryTabs(context, mouseX, mouseY);
        
        // Рендер правил
        int contentY = 100;
        renderPunishmentRules(context, contentY, mouseX, mouseY);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рендерит красивую кнопку "Назад" - СКРУГЛЕННУЮ
     */
    private void renderBackButton(DrawContext context, int mouseX, int mouseY) {
        int buttonWidth = 100;
        int buttonHeight = 30;
        int buttonX = 20;
        int buttonY = 20;
        
        boolean isHovered = mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                           mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        
        // Hover эффект
        if (isHovered) {
            buttonY -= 2;
            context.fill(buttonX + 2, buttonY + buttonHeight + 2, buttonX + buttonWidth + 2, buttonY + buttonHeight + 4, 0x88000000);
        }
        
        // Фон кнопки с градиентом - СКРУГЛЕННЫЙ
        int buttonColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_CARD();
        int buttonColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonColor, 0.95f);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonColor, buttonColorDarker);
        
        // Границы с улучшенным эффектом - СКРУГЛЕННЫЕ
        int borderColor = isHovered ? COLOR_ACCENT_FIXED : COLOR_BORDER();
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, borderColor);
        
        // Свечение при hover
        if (isHovered) {
            int glowColor = (COLOR_ACCENT_FIXED & 0x00FFFFFF) | 0x22000000;
            com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, glowColor, 2);
        }
        
        // Текст
        String text = "← Назад";
        int textWidth = this.textRenderer.getWidth(text);
        int textColor = isHovered ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
        context.drawText(this.textRenderer, text, buttonX + (buttonWidth - textWidth) / 2, 
                        buttonY + (buttonHeight - 8) / 2, textColor, isHovered);
    }
    
    /**
     * Рендерит кнопки категорий (Муты, Размут, Баны, Другое) - СКРУГЛЕННЫЕ
     */
    private void renderCategoryTabs(DrawContext context, int mouseX, int mouseY) {
        int tabWidth = 150; // Увеличено с 120 до 150, так как теперь только 2 вкладки
        int startX = (this.width - (tabWidth * 2 + 5)) / 2; // Только 2 вкладки
        int tabY = 60;
        int tabHeight = 25;
        
        String[] categories = {"mutes", "bans"}; // Убрали "unmute" и "other"
        String[] labels = {"Муты", "Баны"}; // Убрали "Размут" и "Другое"
        
        for (int i = 0; i < categories.length; i++) {
            int tabX = startX + i * (tabWidth + 5);
            boolean isActive = selectedCategory.equals(categories[i]);
            boolean isHovered = mouseX >= tabX && mouseX <= tabX + tabWidth &&
                               mouseY >= tabY && mouseY <= tabY + tabHeight;
            
            // Фон кнопки - СКРУГЛЕННЫЙ
            int bgColor;
            if (isActive) {
                bgColor = COLOR_ACCENT_FIXED; // Активная - бирюзовая
            } else if (isHovered) {
                bgColor = COLOR_BG_HOVER(); // Hover - светлее
            } else {
                bgColor = COLOR_BG_CARD(); // Обычная - темная
            }
            
            // Фон с градиентом
            int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
            com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, tabX, tabY, tabWidth, tabHeight, 8, bgColor, bgColorDarker);
            
            // Граница с улучшенным эффектом - СКРУГЛЕННАЯ
            int borderColor = isActive ? COLOR_ACCENT_FIXED : COLOR_BORDER();
            com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, tabX, tabY, tabWidth, tabHeight, 8, borderColor);
            
            // Свечение при активности
            if (isActive) {
                int glowColor = (COLOR_ACCENT_FIXED & 0x00FFFFFF) | 0x22000000;
                com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, tabX, tabY, tabWidth, tabHeight, 8, glowColor, 2);
            }
            
            // Текст (центрированный)
            int textColor = isActive ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
            int textWidth = this.textRenderer.getWidth(labels[i]);
            int textX = tabX + (tabWidth - textWidth) / 2;
            int textY = tabY + (tabHeight - 8) / 2;
            context.drawText(this.textRenderer, labels[i], textX, textY, textColor, isActive);
        }
    }
    
    private void renderPunishmentRules(DrawContext context, int startY, int mouseX, int mouseY) {
        List<PunishmentRule> rules = getRulesForCategory();
        int y = startY - scrollOffset;
        int index = 0;
        int itemWidth = 700;
        int itemHeight = 36; // Немного выше для лучшей читаемости
        int itemX = (this.width - itemWidth) / 2;
        
        for (PunishmentRule rule : rules) {
            if (y >= startY && y < this.height - 20) {
                boolean isHovered = mouseX >= itemX && mouseX <= itemX + itemWidth &&
                                   mouseY >= y && mouseY <= y + itemHeight;
                
                // Фон карточки с градиентом (современный стиль) - СКРУГЛЕННЫЙ
                int bgColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_CARD();
                int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
                com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, itemX, y, itemWidth, itemHeight, 10, bgColor, bgColorDarker);
                
                // Свечение при hover
                if (isHovered) {
                    int glowColor = (getButtonColorForCategory() & 0x00FFFFFF) | 0x22000000;
                    com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, itemX, y, itemWidth, itemHeight, 10, glowColor, 2);
                }
                
                // Тонкая рамка убрана для чистого вида
                
                // НОВЫЙ ФОРМАТ: "Код + Название + Длительность"
                int textY = y + (itemHeight - 8) / 2;
                
                // Код правила (оранжевый, жирный)
                String codeText = rule.getCode();
                context.drawText(this.textRenderer, codeText, itemX + 20, textY, COLOR_WARNING_FIXED, true);
                
                // Название (белый)
                int codeWidth = this.textRenderer.getWidth(codeText);
                context.drawText(this.textRenderer, rule.getReason(), itemX + 20 + codeWidth + 15, textY, COLOR_TEXT_PRIMARY, false);
                
                // Длительность (серый, справа от названия)
                String durationText = formatDuration(rule.getDuration());
                int nameWidth = this.textRenderer.getWidth(rule.getReason());
                context.drawText(this.textRenderer, durationText, itemX + 20 + codeWidth + 15 + nameWidth + 20, textY, COLOR_TEXT_MUTED, false);
                
                // Кнопка "Применить" (справа) - СКРУГЛЕННАЯ
                int buttonX = itemX + itemWidth - 115;
                int buttonY = y + 6;
                int buttonWidth = 100;
                int buttonHeight = 24;
                
                // Цвет кнопки по категории
                int buttonColor = getButtonColorForCategory();
                int buttonHoverColor = adjustBrightness(buttonColor, 1.2f);
                int buttonBg = isHovered ? buttonHoverColor : buttonColor;
                int buttonBgDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonBg, 0.85f);
                
                // Фон кнопки с градиентом
                com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, buttonX, buttonY, buttonWidth, buttonHeight, 6, buttonBg, buttonBgDarker);
                
                // Граница кнопки
                int buttonBorderColor = isHovered ? com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonBg, 1.3f) : COLOR_BORDER();
                com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, buttonX, buttonY, buttonWidth, buttonHeight, 6, buttonBorderColor);
                
                // Свечение при hover
                if (isHovered) {
                    int glowColor = (buttonBg & 0x00FFFFFF) | 0x22000000;
                    com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, buttonX, buttonY, buttonWidth, buttonHeight, 6, glowColor, 2);
                }
                
                // Текст кнопки (центрированный)
                String buttonText = "Применить";
                int buttonTextWidth = this.textRenderer.getWidth(buttonText);
                int buttonTextX = buttonX + (buttonWidth - buttonTextWidth) / 2;
                int buttonTextY = buttonY + (buttonHeight - 8) / 2;
                context.drawText(this.textRenderer, buttonText, buttonTextX, buttonTextY, COLOR_TEXT_PRIMARY, false);
            }
            y += itemHeight + 4; // Небольшой отступ между карточками
            index++;
        }
    }
    
    /**
     * Форматирует длительность для отображения
     */
    private String formatDuration(String duration) {
        // Преобразуем английские обозначения в русские
        if (duration.contains("minute")) return duration.replace("minute", "мин").replace("s", "");
        if (duration.contains("hour")) return duration.replace("hour", "ч").replace("s", "");
        if (duration.contains("day")) return duration.replace("day", "д").replace("s", "");
        if (duration.contains("Навсегда")) return duration;
        if (duration.contains("Forever")) return "Навсегда";
        return duration;
    }
    
    /**
     * Возвращает цвет кнопки в зависимости от категории
     */
    private int getButtonColorForCategory() {
        switch (selectedCategory) {
            case "mutes":
                return COLOR_WARNING_FIXED; // Желтый для мутов
            case "unmute":
                return COLOR_SUCCESS_FIXED; // Зеленый для размута
            case "bans":
                return COLOR_DANGER_FIXED; // Красный для банов
            default:
                return COLOR_ACCENT_FIXED; // Синий для остального
        }
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    private List<PunishmentRule> getRulesForCategory() {
        switch (selectedCategory) {
            case "mutes":
                return PunishmentRule.getMuteRules();
            case "bans":
                return PunishmentRule.getBanRules();
            default:
                return List.of();
        }
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Воспроизводим звук клика
        SoundManager.playClickSound();
        
        // 1. ПРИОРИТЕТ: Клик по кнопке "Назад"
        int backButtonWidth = 100;
        int backButtonHeight = 30;
        int backButtonX = 20;
        int backButtonY = 20;
        
        if (mouseX >= backButtonX && mouseX <= backButtonX + backButtonWidth && 
            mouseY >= backButtonY && mouseY <= backButtonY + backButtonHeight) {
            this.client.setScreen(new ConsoleScreen(null));
            return true;
        }
        
        // 2. Клик по кнопкам категорий
        int tabWidth = 150; // Увеличено с 120 до 150, так как теперь только 2 вкладки
        int startX = (this.width - (tabWidth * 2 + 5)) / 2; // Только 2 вкладки
        int tabY = 60;
        int tabHeight = 25;
        
        String[] categories = {"mutes", "bans"}; // Убрали "unmute" и "other"
        
        for (int i = 0; i < categories.length; i++) {
            int tabX = startX + i * (tabWidth + 5);
            
            if (mouseX >= tabX && mouseX <= tabX + tabWidth &&
                mouseY >= tabY && mouseY <= tabY + tabHeight) {
                selectedCategory = categories[i];
                scrollOffset = 0; // Сбрасываем скролл при смене категории
                return true;
            }
        }
        
        // 3. Клик по правилам наказаний
        List<PunishmentRule> rules = getRulesForCategory();
        int contentY = 100;
        int y = contentY - scrollOffset;
        int itemWidth = 700;
        int itemHeight = 36; // Обновлено под новую высоту
        int itemX = (this.width - itemWidth) / 2;
        
        for (PunishmentRule rule : rules) {
            if (y >= contentY && y < this.height - 20) {
                int buttonX = itemX + itemWidth - 115;
                int buttonY = y + 6;
                int buttonWidth = 100;
                int buttonHeight = 24;
                
                if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                    mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                    
                    applyPunishment(rule);
                    return true;
                }
            }
            y += itemHeight + 4; // Обновлено под новый отступ
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    private void applyPunishment(PunishmentRule rule) {
        if (rule.getCode().equals("2.4")) {
            // Особый случай - выбор времени для читов
            this.client.setScreen(new CheatBanDurationScreen(targetPlayer));
        } else if (selectedCategory.equals("mutes")) {
            AdminPanelClient.getPunishmentManager().issueMute(targetPlayer, rule.getDuration(), rule.getCode());
            this.client.setScreen(new AdminPanelScreen());
        } else if (selectedCategory.equals("bans")) {
            AdminPanelClient.getPunishmentManager().issueBan(targetPlayer, rule.getDuration(), rule.getCode());
            this.client.setScreen(new AdminPanelScreen());
        } else if (rule.getCode().equals("unmute")) {
            AdminPanelClient.getPunishmentManager().issueUnmute(targetPlayer);
            this.client.setScreen(new AdminPanelScreen());
        } else if (rule.getCode().equals("ipban")) {
            AdminPanelClient.getPunishmentManager().issueIPBan(targetPlayer, rule.getDuration(), "IP-Ban");
            this.client.setScreen(new AdminPanelScreen());
        }
    }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        List<PunishmentRule> rules = getRulesForCategory();
        
        // Вычисляем максимальный скролл
        int itemHeight = 36;
        int itemSpacing = 4;
        int contentY = 100;
        int totalHeight = rules.size() * (itemHeight + itemSpacing);
        int visibleHeight = this.height - contentY - 20;
        int maxScroll = Math.max(0, totalHeight - visibleHeight);
        
        // Применяем скролл с ограничениями
        scrollOffset -= (int) (amount * 20);
        if (scrollOffset < 0) scrollOffset = 0;
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        
        return true;
    }
    
    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        // Проверяем наведение на элементы списка
        List<PunishmentRule> rules = getRulesForCategory();
        int contentY = 100;
        int y = contentY - scrollOffset;
        int itemWidth = 700;
        int itemHeight = 36; // Обновлено под новую высоту
        int itemX = (this.width - itemWidth) / 2;
        int index = 0;
        
        for (PunishmentRule rule : rules) {
            if (y >= contentY && y < this.height - 20) {
                if (mouseX >= itemX && mouseX <= itemX + itemWidth && 
                    mouseY >= y && mouseY <= y + itemHeight) {
                    if (hoveredItemIndex != index) {
                        hoveredItemIndex = index;
                        SoundManager.playHoverSound();
                    }
                    super.mouseMoved(mouseX, mouseY);
                    return;
                }
            }
            y += itemHeight + 4; // Обновлено под новый отступ
            index++;
        }
        
        hoveredItemIndex = -1;
        super.mouseMoved(mouseX, mouseY);
    }
}

