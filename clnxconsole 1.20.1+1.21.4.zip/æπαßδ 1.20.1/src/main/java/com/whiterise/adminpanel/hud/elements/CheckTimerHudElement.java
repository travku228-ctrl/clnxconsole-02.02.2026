package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import com.whiterise.adminpanel.manager.AntiCheatSessionManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Таймер проверки
 */
public class CheckTimerHudElement extends HudElement {
    private static final int COLOR_BG = 0xCC1A2332;
    private static final int COLOR_ACCENT = 0xFF10b981; // Зеленый
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    
    public CheckTimerHudElement() {
        super("check_timer", "Время проверки");
        setPosition(HudPosition.TOP_LEFT);
        setOffsetY(90);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        // Проверяем есть ли активная проверка
        if (!AntiCheatSessionManager.hasActiveSession()) {
            return;
        }
        
        var session = AntiCheatSessionManager.getActiveSession();
        String timer = session.getFormattedRemainingTime();
        
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Фон
        int width = getWidth();
        int height = getHeight();
        int bgColor = applyOpacity(COLOR_BG);
        
        fillRounded(context, 0, 0, width, height, 6, bgColor);
        
        // Иконка
        context.drawText(client.textRenderer, "⏱", 6, 6, COLOR_ACCENT, false);
        
        // Текст
        context.drawText(client.textRenderer, "Начало проверки:", 24, 6, COLOR_TEXT, false);
        context.drawText(client.textRenderer, timer, 24, 18, COLOR_ACCENT, false);
    }
    
    @Override
    public int getWidth() {
        return 160;
    }
    
    @Override
    public int getHeight() {
        return 32;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
    
    private void fillRounded(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        context.fill(x + radius, y, x + width - radius, y + height, color);
        context.fill(x, y + radius, x + radius, y + height - radius, color);
        context.fill(x + width - radius, y + radius, x + width, y + height - radius, color);
        
        for (int i = 0; i < radius; i++) {
            for (int j = 0; j < radius; j++) {
                if (i * i + j * j <= radius * radius) {
                    context.fill(x + radius - i, y + radius - j, x + radius - i + 1, y + radius - j + 1, color);
                    context.fill(x + width - radius + i, y + radius - j, x + width - radius + i + 1, y + radius - j + 1, color);
                    context.fill(x + radius - i, y + height - radius + j, x + radius - i + 1, y + height - radius + j + 1, color);
                    context.fill(x + width - radius + i, y + height - radius + j, x + width - radius + i + 1, y + height - radius + j + 1, color);
                }
            }
        }
    }
}
