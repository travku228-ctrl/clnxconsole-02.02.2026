package com.whiterise.adminpanel.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Экран редактирования HUD-элементов
 * Открывается при нажатии клавиши чата (T) если включен режим редактирования
 */
public class HudEditorScreen extends Screen {
    private HudElement draggedElement = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;
    
    private static final int COLOR_OVERLAY = 0x80000000;
    private static final int COLOR_BORDER = 0xFF00D9FF;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_HINT_BG = 0xCC1A2332;
    
    public HudEditorScreen() {
        super(Text.literal("Редактор HUD"));
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Полупрозрачный оверлей
        context.fill(0, 0, this.width, this.height, COLOR_OVERLAY);
        
        // Рендерим все HUD-элементы с границами
        for (HudElement element : HudManager.getInstance().getAllElements()) {
            if (!element.isEnabled()) {
                continue;
            }
            
            context.getMatrices().push();
            
            int x = element.getX(this.width);
            int y = element.getY(this.height);
            float scale = element.getScale();
            
            context.getMatrices().translate(x, y, 0);
            context.getMatrices().scale(scale, scale, 1.0f);
            
            // Рендерим элемент
            element.render(context, this.width, this.height, delta);
            
            // Рамка вокруг элемента
            int elementWidth = element.getWidth();
            int elementHeight = element.getHeight();
            
            boolean isHovered = mouseX >= x && mouseX <= x + elementWidth * scale && 
                               mouseY >= y && mouseY <= y + elementHeight * scale;
            
            int borderColor = (element == draggedElement || isHovered) ? COLOR_BORDER : 0x88FFFFFF;
            
            // Рисуем рамку (без масштаба)
            context.getMatrices().scale(1.0f / scale, 1.0f / scale, 1.0f);
            drawBorder(context, 0, 0, (int)(elementWidth * scale), (int)(elementHeight * scale), borderColor);
            
            context.getMatrices().pop();
        }
        
        // Подсказка внизу экрана
        renderHint(context);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рисует рамку вокруг элемента
     */
    private void drawBorder(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x, y, x + width, y + 2, color); // Верх
        context.fill(x, y + height - 2, x + width, y + height, color); // Низ
        context.fill(x, y, x + 2, y + height, color); // Лево
        context.fill(x + width - 2, y, x + width, y + height, color); // Право
    }
    
    /**
     * Рендерит подсказку
     */
    private void renderHint(DrawContext context) {
        String hint = "Перетащите элементы мышью для изменения позиции • ESC для выхода";
        int hintWidth = this.textRenderer.getWidth(hint);
        int hintX = (this.width - hintWidth) / 2;
        int hintY = this.height - 30;
        
        // Фон подсказки
        context.fill(hintX - 10, hintY - 5, hintX + hintWidth + 10, hintY + 15, COLOR_HINT_BG);
        
        // Текст
        context.drawText(this.textRenderer, hint, hintX, hintY, COLOR_TEXT, false);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        
        // Проверяем клик по элементам (в обратном порядке, чтобы верхние были приоритетнее)
        var elements = HudManager.getInstance().getAllElements();
        for (int i = elements.size() - 1; i >= 0; i--) {
            HudElement element = elements.get(i);
            
            if (!element.isEnabled()) {
                continue;
            }
            
            int x = element.getX(this.width);
            int y = element.getY(this.height);
            float scale = element.getScale();
            int width = (int)(element.getWidth() * scale);
            int height = (int)(element.getHeight() * scale);
            
            if (mouseX >= x && mouseX <= x + width && 
                mouseY >= y && mouseY <= y + height) {
                // Начинаем перетаскивание
                draggedElement = element;
                dragOffsetX = (int)(mouseX - x);
                dragOffsetY = (int)(mouseY - y);
                return true;
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggedElement != null) {
            // Обновляем позицию элемента
            int newX = (int)(mouseX - dragOffsetX);
            int newY = (int)(mouseY - dragOffsetY);
            
            // Ограничиваем в пределах экрана
            newX = Math.max(0, Math.min(this.width - (int)(draggedElement.getWidth() * draggedElement.getScale()), newX));
            newY = Math.max(0, Math.min(this.height - (int)(draggedElement.getHeight() * draggedElement.getScale()), newY));
            
            // Устанавливаем свободную позицию
            draggedElement.setPosition(HudElement.HudPosition.FREE);
            draggedElement.setOffsetX(newX);
            draggedElement.setOffsetY(newY);
            
            return true;
        }
        
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }
    
    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (draggedElement != null) {
            // Сохраняем изменения
            HudManager.getInstance().saveConfig();
            draggedElement = null;
            return true;
        }
        
        return super.mouseReleased(mouseX, mouseY, button);
    }
    
    @Override
    public void close() {
        // Сохраняем при закрытии
        HudManager.getInstance().saveConfig();
        super.close();
    }
    
    @Override
    public boolean shouldPause() {
        return false; // Не ставим игру на паузу
    }
}
