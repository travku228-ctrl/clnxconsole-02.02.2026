package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.data.ChatMessage;
import com.whiterise.adminpanel.data.PunishmentRecord;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class PunishmentDetailsScreen extends Screen {
    private final PunishmentRecord record;
    
    // Цветовая палитра - интегрирована с ColorManager
    private int COLOR_BG_DARK() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    // ФИКСИРОВАННЫЕ цвета (не зависят от темы)
    private static final int COLOR_ACCENT_FIXED = 0xFF00D9FF;
    private static final int COLOR_WARNING_FIXED = 0xFFf59e0b;
    private static final int COLOR_DANGER_FIXED = 0xFFef4444;
    private static final int COLOR_SUCCESS_FIXED = 0xFF10b981;
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;
    
    private static final Identifier ICON_CHAT = new Identifier("whiterise_adminpanel", "textures/icons/chat.png");
    
    private int scrollOffset = 0;
    
    public PunishmentDetailsScreen(PunishmentRecord record) {
        super(Text.literal("Детали наказания"));
        this.record = record;
    }
    
    @Override
    protected void init() {
        // Кнопка назад
        this.addDrawableChild(ButtonWidget.builder(Text.literal("← Назад"), button -> {
            this.client.setScreen(new AdminPanelScreen());
        }).dimensions(20, 20, 100, 25).build());
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Фон
        context.fillGradient(0, 0, this.width, this.height, COLOR_BG_DARK(), adjustBrightness(COLOR_BG_DARK(), 0.9f));
        
        // Основная карточка
        int cardWidth = 700;
        int cardX = (this.width - cardWidth) / 2;
        int cardY = 80;
        
        // Заголовок
        String title = "Детали наказания";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, 50, COLOR_TEXT_PRIMARY, true);
        
        // Информация о наказании
        renderPunishmentInfo(context, cardX, cardY, cardWidth);
        
        // Последние сообщения игрока
        renderLastMessages(context, cardX, cardY + 150, cardWidth);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    private void renderPunishmentInfo(DrawContext context, int x, int y, int width) {
        int cardHeight = 130;
        
        // Тень
        context.fill(x + 2, y + 2, x + width + 2, y + cardHeight + 2, 0x44000000);
        
        // Фон карточки - СКРУГЛЕННЫЙ
        RenderUtils.fillRounded(context, x, y, width, cardHeight, 12, COLOR_BG_CARD());
        
        // Границы - СКРУГЛЕННЫЕ
        RenderUtils.drawRoundedBorder(context, x, y, width, cardHeight, 12, COLOR_BORDER());
        
        // Цветная полоска сверху (зависит от типа наказания)
        int accentColor = getAccentColorForType(record.getType());
        context.fill(x, y, x + width, y + 4, accentColor);
        
        // Содержимое
        int contentY = y + 20;
        int lineHeight = 18;
        
        // Игрок
        context.drawText(this.textRenderer, "Игрок:", x + 30, contentY, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, record.getUsername(), x + 120, contentY, COLOR_TEXT_PRIMARY, true);
        contentY += lineHeight;
        
        // Тип наказания
        context.drawText(this.textRenderer, "Наказание:", x + 30, contentY, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, record.getType().getDisplayName(), x + 120, contentY, accentColor, true);
        contentY += lineHeight;
        
        // Длительность
        context.drawText(this.textRenderer, "Длительность:", x + 30, contentY, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, record.getDuration(), x + 120, contentY, COLOR_TEXT_PRIMARY, false);
        contentY += lineHeight;
        
        // Причина
        context.drawText(this.textRenderer, "Причина:", x + 30, contentY, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, record.getReason(), x + 120, contentY, COLOR_TEXT_PRIMARY, false);
        contentY += lineHeight;
        
        // Время выдачи
        context.drawText(this.textRenderer, "Выдано:", x + 30, contentY, COLOR_TEXT_SECONDARY, false);
        String timeAgo = formatTimeAgo(System.currentTimeMillis() - record.getTimestamp());
        context.drawText(this.textRenderer, timeAgo, x + 120, contentY, COLOR_TEXT_MUTED, false);
    }
    
    private void renderLastMessages(DrawContext context, int x, int y, int width) {
        // Заголовок секции
        context.drawText(this.textRenderer, "Последние сообщения игрока (до наказания):", x, y - 25, COLOR_TEXT_SECONDARY, true);
        
        List<ChatMessage> messages = record.getLastMessages();
        
        // УБИРАЕМ ПУСТОЙ БЛОК - если нет сообщений, просто не рендерим ничего
        if (messages.isEmpty()) {
            return;
        }
        
        // Карточки сообщений
        int cardHeight = 50;
        int itemY = y - scrollOffset;
        int maxVisibleHeight = this.height - y - 40;
        
        for (ChatMessage msg : messages) {
            if (itemY >= y - cardHeight && itemY < y + maxVisibleHeight) {
                // Тень
                context.fill(x + 2, itemY + 2, x + width + 2, itemY + cardHeight + 2, 0x22000000);
                
                // Фон карточки - СКРУГЛЕННЫЙ
                RenderUtils.fillRounded(context, x, itemY, width, cardHeight, 8, COLOR_BG_CARD());
                
                // Верхняя граница
                RenderUtils.drawRoundedBorder(context, x, itemY, width, cardHeight, 8, COLOR_BORDER());
                
                // Иконка сообщения
                context.drawTexture(ICON_CHAT, x + 15, itemY + 8, 0, 0, 16, 16, 16, 16);
                
                // Имя игрока (должно совпадать с наказанным)
                context.drawText(this.textRenderer, msg.getUsername(), x + 40, itemY + 10, COLOR_ACCENT_FIXED, true);
                
                // Время
                long timeDiff = record.getTimestamp() - msg.getTimestamp();
                String timeAgo = formatTimeAgo(timeDiff) + " до наказания";
                int timeWidth = this.textRenderer.getWidth(timeAgo);
                context.drawText(this.textRenderer, timeAgo, x + width - timeWidth - 15, itemY + 10, COLOR_TEXT_MUTED, false);
                
                // Сообщение
                String message = msg.getMessage();
                int maxWidth = width - 60;
                
                if (this.textRenderer.getWidth(message) > maxWidth) {
                    message = this.textRenderer.trimToWidth(message, maxWidth - 20) + "...";
                }
                
                context.drawText(this.textRenderer, message, x + 40, itemY + 30, COLOR_TEXT_SECONDARY, false);
            }
            itemY += cardHeight + 5;
        }
        
        // Скроллбар (если нужен)
        int totalHeight = messages.size() * (cardHeight + 5);
        if (totalHeight > maxVisibleHeight) {
            renderScrollbar(context, x, y, width, maxVisibleHeight, totalHeight - maxVisibleHeight);
        }
    }
    
    private void renderScrollbar(DrawContext context, int contentX, int contentY, int contentWidth, int contentHeight, int maxScroll) {
        if (maxScroll <= 0) return;
        
        int scrollbarX = contentX + contentWidth + 5;
        int scrollbarY = contentY;
        int scrollbarWidth = 6;
        int scrollbarHeight = contentHeight;
        
        // Фон скроллбара
        context.fill(scrollbarX, scrollbarY, scrollbarX + scrollbarWidth, scrollbarY + scrollbarHeight, adjustBrightness(COLOR_BG_CARD(), 0.8f));
        
        // Ползунок
        float scrollPercentage = (float) scrollOffset / maxScroll;
        int thumbHeight = Math.max(20, (int) (scrollbarHeight * ((float) scrollbarHeight / (scrollbarHeight + maxScroll))));
        int thumbY = scrollbarY + (int) ((scrollbarHeight - thumbHeight) * scrollPercentage);
        
        // Ползунок с фиксированным цветом
        context.fill(scrollbarX + 1, thumbY, scrollbarX + scrollbarWidth - 1, thumbY + thumbHeight, COLOR_ACCENT_FIXED);
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        List<ChatMessage> messages = record.getLastMessages();
        if (messages.isEmpty()) return true;
        
        int cardHeight = 50;
        int y = 230;
        int maxVisibleHeight = this.height - y - 40;
        int totalHeight = messages.size() * (cardHeight + 5);
        int maxScroll = Math.max(0, totalHeight - maxVisibleHeight);
        
        scrollOffset -= (int) (amount * 20);
        
        if (scrollOffset < 0) scrollOffset = 0;
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        
        return true;
    }
    
    private int getAccentColorForType(PunishmentRecord.PunishmentType type) {
        switch (type) {
            case MUTE:
                return COLOR_WARNING_FIXED;
            case BAN:
            case IP_BAN:
                return COLOR_DANGER_FIXED;
            case UNMUTE:
                return COLOR_SUCCESS_FIXED;
            default:
                return COLOR_ACCENT_FIXED;
        }
    }
    
    private String formatTimeAgo(long milliseconds) {
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        
        if (days > 0) {
            return days + "д назад";
        } else if (hours > 0) {
            return hours + "ч назад";
        } else if (minutes > 0) {
            return minutes + "м назад";
        } else {
            return seconds + "с назад";
        }
    }
}
