package com.whiterise.adminpanel.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Система машинного обучения для автоматического обнаружения нарушений
 * Обучается на основе ваших действий модерирования
 */
public class ViolationLearner {
    private static final Path LEARNING_DATA_FILE = Paths.get("config/clnxconsole/learning_data.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    
    // Хранилище обученных паттернов: код нарушения -> список паттернов
    private static final Map<String, List<LearnedPattern>> learnedPatterns = new ConcurrentHashMap<>();
    
    // Временное хранилище последних сообщений игроков для обучения
    private static final Map<String, List<RecentMessage>> recentMessages = new ConcurrentHashMap<>();
    
    // Максимальное количество сообщений для хранения
    private static final int MAX_RECENT_MESSAGES = 10;
    
    // Время жизни сообщения (5 минут)
    private static final long MESSAGE_LIFETIME = 300000;
    
    // Минимальная схожесть для обнаружения (70%)
    private static final double SIMILARITY_THRESHOLD = 0.7;
    
    static {
        loadLearningData();
    }
    
    /**
     * Добавляет сообщение игрока для возможного обучения
     */
    public static void addPlayerMessage(String username, String message) {
        if (username == null || message == null || message.isEmpty()) {
            return;
        }
        
        long now = System.currentTimeMillis();
        
        // Получаем или создаем список сообщений игрока
        List<RecentMessage> messages = recentMessages.computeIfAbsent(username, k -> new ArrayList<>());
        
        // Удаляем старые сообщения
        messages.removeIf(msg -> now - msg.timestamp > MESSAGE_LIFETIME);
        
        // Добавляем новое сообщение
        messages.add(new RecentMessage(message, now));
        
        // Ограничиваем размер списка
        if (messages.size() > MAX_RECENT_MESSAGES) {
            messages.remove(0);
        }
    }
    
    /**
     * Обучается на основе выданного мута
     * @param username Никнейм игрока
     * @param violationCode Код нарушения (например "3.3")
     */
    public static void learnFromMute(String username, String violationCode) {
        if (username == null || violationCode == null) {
            return;
        }
        
        // Получаем последние сообщения игрока
        List<RecentMessage> messages = recentMessages.get(username);
        if (messages == null || messages.isEmpty()) {
            System.out.println("[ViolationLearner] Нет сообщений для обучения от " + username);
            return;
        }
        
        // УЛУЧШЕННАЯ ЛОГИКА: Обучаемся на ВСЕХ последних сообщениях
        // Это помогает когда игрок написал несколько нарушающих сообщений
        int learnedCount = 0;
        
        for (RecentMessage message : messages) {
            // Создаем паттерн из каждого сообщения
            LearnedPattern pattern = createPattern(message.message, violationCode);
            
            // Добавляем паттерн в базу знаний
            List<LearnedPattern> patterns = learnedPatterns.computeIfAbsent(violationCode, k -> new ArrayList<>());
            
            // Проверяем что такого паттерна еще нет (схожесть 90%)
            boolean exists = patterns.stream()
                .anyMatch(p -> p.isSimilar(pattern, 0.9));
            
            if (!exists) {
                patterns.add(pattern);
                learnedCount++;
                
                System.out.println("[ViolationLearner] Обучение: " + violationCode + " -> \"" + message.message + "\"");
            }
        }
        
        if (learnedCount > 0) {
            saveLearningData();
            System.out.println("[ViolationLearner] Обучено " + learnedCount + " паттернов для " + username);
        } else {
            System.out.println("[ViolationLearner] Все паттерны уже известны для " + username);
        }
    }
    
    /**
     * Проверяет сообщение на нарушения используя обученные паттерны
     * @param message Текст сообщения
     * @return Код нарушения если обнаружено, иначе null
     */
    public static String detectViolation(String message) {
        if (message == null || message.isEmpty()) {
            return null;
        }
        
        // Проверяем все обученные паттерны
        for (Map.Entry<String, List<LearnedPattern>> entry : learnedPatterns.entrySet()) {
            String violationCode = entry.getKey();
            List<LearnedPattern> patterns = entry.getValue();
            
            for (LearnedPattern pattern : patterns) {
                if (pattern.matches(message, SIMILARITY_THRESHOLD)) {
                    return violationCode;
                }
            }
        }
        
        return null;
    }
    
    /**
     * Создает паттерн из сообщения
     */
    private static LearnedPattern createPattern(String message, String violationCode) {
        // Извлекаем ключевые слова
        List<String> keywords = extractKeywords(message);
        
        // Вычисляем характеристики
        int length = message.length();
        double capsRatio = calculateCapsRatio(message);
        double repeatRatio = calculateRepeatRatio(message);
        boolean hasRepeatingPattern = hasRepeatingPattern(message);
        
        return new LearnedPattern(
            message,
            violationCode,
            keywords,
            length,
            capsRatio,
            repeatRatio,
            hasRepeatingPattern,
            System.currentTimeMillis()
        );
    }
    
    /**
     * Извлекает ключевые слова из сообщения
     */
    private static List<String> extractKeywords(String message) {
        List<String> keywords = new ArrayList<>();
        
        // Разбиваем на слова
        String[] words = message.toLowerCase().split("\\s+");
        
        // Берем слова длиннее 3 символов
        for (String word : words) {
            String cleaned = word.replaceAll("[^a-zа-я0-9]", "");
            if (cleaned.length() > 3) {
                keywords.add(cleaned);
            }
        }
        
        return keywords;
    }
    
    /**
     * Вычисляет процент заглавных букв
     */
    private static double calculateCapsRatio(String message) {
        int totalLetters = 0;
        int upperCaseLetters = 0;
        
        for (char c : message.toCharArray()) {
            if (Character.isLetter(c)) {
                totalLetters++;
                if (Character.isUpperCase(c)) {
                    upperCaseLetters++;
                }
            }
        }
        
        return totalLetters > 0 ? (double) upperCaseLetters / totalLetters : 0;
    }
    
    /**
     * Вычисляет процент повторяющихся символов
     */
    private static double calculateRepeatRatio(String message) {
        if (message.isEmpty()) {
            return 0;
        }
        
        Map<Character, Integer> charFrequency = new HashMap<>();
        for (char c : message.toCharArray()) {
            charFrequency.put(c, charFrequency.getOrDefault(c, 0) + 1);
        }
        
        int maxFrequency = 0;
        for (int freq : charFrequency.values()) {
            if (freq > maxFrequency) {
                maxFrequency = freq;
            }
        }
        
        return (double) maxFrequency / message.length();
    }
    
    /**
     * Проверяет наличие повторяющихся паттернов
     */
    private static boolean hasRepeatingPattern(String message) {
        if (message.length() < 12) {
            return false;
        }
        
        for (int patternLength = 2; patternLength <= 4; patternLength++) {
            if (message.length() < patternLength * 3) {
                continue;
            }
            
            String pattern = message.substring(0, patternLength);
            int repeatCount = 1;
            int pos = patternLength;
            
            while (pos + patternLength <= message.length()) {
                String nextChunk = message.substring(pos, pos + patternLength);
                if (nextChunk.equals(pattern)) {
                    repeatCount++;
                    pos += patternLength;
                } else {
                    break;
                }
            }
            
            if (repeatCount >= 4) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Сохраняет данные обучения в файл
     */
    private static void saveLearningData() {
        try {
            // Создаем директорию если не существует
            Files.createDirectories(LEARNING_DATA_FILE.getParent());
            
            // Сохраняем данные
            try (Writer writer = new FileWriter(LEARNING_DATA_FILE.toFile())) {
                GSON.toJson(learnedPatterns, writer);
            }
            
            System.out.println("[ViolationLearner] Данные обучения сохранены: " + learnedPatterns.size() + " кодов нарушений");
        } catch (IOException e) {
            System.err.println("[ViolationLearner] Ошибка сохранения данных: " + e.getMessage());
        }
    }
    
    /**
     * Загружает данные обучения из файла
     */
    private static void loadLearningData() {
        if (!Files.exists(LEARNING_DATA_FILE)) {
            System.out.println("[ViolationLearner] Файл данных не найден, начинаем с пустой базы");
            return;
        }
        
        try (Reader reader = new FileReader(LEARNING_DATA_FILE.toFile())) {
            Type type = new TypeToken<Map<String, List<LearnedPattern>>>(){}.getType();
            Map<String, List<LearnedPattern>> loaded = GSON.fromJson(reader, type);
            
            if (loaded != null) {
                learnedPatterns.clear();
                learnedPatterns.putAll(loaded);
                
                int totalPatterns = learnedPatterns.values().stream()
                    .mapToInt(List::size)
                    .sum();
                
                System.out.println("[ViolationLearner] Загружено " + totalPatterns + " паттернов для " + learnedPatterns.size() + " кодов нарушений");
            }
        } catch (IOException e) {
            System.err.println("[ViolationLearner] Ошибка загрузки данных: " + e.getMessage());
        }
    }
    
    /**
     * Очищает все данные обучения
     */
    public static void clearLearningData() {
        learnedPatterns.clear();
        recentMessages.clear();
        saveLearningData();
    }
    
    /**
     * Возвращает статистику обучения
     */
    public static String getStatistics() {
        int totalPatterns = learnedPatterns.values().stream()
            .mapToInt(List::size)
            .sum();
        
        StringBuilder stats = new StringBuilder();
        stats.append("=== Статистика обучения ===\n");
        stats.append("Всего паттернов: ").append(totalPatterns).append("\n");
        stats.append("Кодов нарушений: ").append(learnedPatterns.size()).append("\n\n");
        
        if (learnedPatterns.isEmpty()) {
            stats.append("Мод еще не обучен. Выдайте несколько мутов чтобы начать обучение.\n");
        } else {
            stats.append("Детали по кодам:\n");
            for (Map.Entry<String, List<LearnedPattern>> entry : learnedPatterns.entrySet()) {
                String code = entry.getKey();
                List<LearnedPattern> patterns = entry.getValue();
                
                stats.append("\n").append(code).append(": ").append(patterns.size()).append(" паттернов\n");
                
                // Показываем первые 3 примера
                int count = 0;
                for (LearnedPattern pattern : patterns) {
                    if (count >= 3) {
                        stats.append("  ... и еще ").append(patterns.size() - 3).append("\n");
                        break;
                    }
                    stats.append("  - \"").append(pattern.originalMessage).append("\"\n");
                    count++;
                }
            }
        }
        
        return stats.toString();
    }
    
    /**
     * Выводит статистику в консоль
     */
    public static void printStatistics() {
        System.out.println(getStatistics());
    }
    
    /**
     * Обученный паттерн нарушения
     */
    private static class LearnedPattern {
        String originalMessage;
        String violationCode;
        List<String> keywords;
        int length;
        double capsRatio;
        double repeatRatio;
        boolean hasRepeatingPattern;
        long learnedAt;
        
        LearnedPattern(String originalMessage, String violationCode, List<String> keywords,
                      int length, double capsRatio, double repeatRatio,
                      boolean hasRepeatingPattern, long learnedAt) {
            this.originalMessage = originalMessage;
            this.violationCode = violationCode;
            this.keywords = keywords;
            this.length = length;
            this.capsRatio = capsRatio;
            this.repeatRatio = repeatRatio;
            this.hasRepeatingPattern = hasRepeatingPattern;
            this.learnedAt = learnedAt;
        }
        
        /**
         * Проверяет соответствует ли сообщение этому паттерну
         */
        boolean matches(String message, double threshold) {
            double similarity = calculateSimilarity(message);
            return similarity >= threshold;
        }
        
        /**
         * Проверяет похожесть с другим паттерном
         */
        boolean isSimilar(LearnedPattern other, double threshold) {
            return calculateSimilarity(other.originalMessage) >= threshold;
        }
        
        /**
         * Вычисляет схожесть сообщения с паттерном
         */
        private double calculateSimilarity(String message) {
            double score = 0;
            int checks = 0;
            
            // 1. Схожесть по длине (вес 0.1)
            double lengthDiff = Math.abs(message.length() - this.length) / (double) Math.max(message.length(), this.length);
            score += (1 - lengthDiff) * 0.1;
            checks++;
            
            // 2. Схожесть по ключевым словам (вес 0.4)
            List<String> messageKeywords = extractKeywords(message);
            int matchingKeywords = 0;
            for (String keyword : this.keywords) {
                if (messageKeywords.contains(keyword)) {
                    matchingKeywords++;
                }
            }
            if (!this.keywords.isEmpty()) {
                score += ((double) matchingKeywords / this.keywords.size()) * 0.4;
                checks++;
            }
            
            // 3. Схожесть по CAPS (вес 0.2)
            double messageCapsRatio = calculateCapsRatio(message);
            double capsDiff = Math.abs(messageCapsRatio - this.capsRatio);
            score += (1 - capsDiff) * 0.2;
            checks++;
            
            // 4. Схожесть по повторяющимся символам (вес 0.2)
            double messageRepeatRatio = calculateRepeatRatio(message);
            double repeatDiff = Math.abs(messageRepeatRatio - this.repeatRatio);
            score += (1 - repeatDiff) * 0.2;
            checks++;
            
            // 5. Наличие повторяющихся паттернов (вес 0.1)
            boolean messageHasPattern = hasRepeatingPattern(message);
            if (messageHasPattern == this.hasRepeatingPattern) {
                score += 0.1;
            }
            checks++;
            
            return score;
        }
    }
    
    /**
     * Недавнее сообщение игрока
     */
    private static class RecentMessage {
        String message;
        long timestamp;
        
        RecentMessage(String message, long timestamp) {
            this.message = message;
            this.timestamp = timestamp;
        }
    }
}
