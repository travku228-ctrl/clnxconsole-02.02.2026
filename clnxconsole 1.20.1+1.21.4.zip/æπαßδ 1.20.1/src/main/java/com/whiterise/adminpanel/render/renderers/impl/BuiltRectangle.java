package com.whiterise.adminpanel.render.renderers.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import com.whiterise.adminpanel.render.builders.states.QuadColorState;
import com.whiterise.adminpanel.render.builders.states.QuadRadiusState;
import com.whiterise.adminpanel.render.builders.states.SizeState;
import com.whiterise.adminpanel.render.renderers.IRenderer;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public record BuiltRectangle(SizeState size, QuadRadiusState radius, QuadColorState color, float smoothness) implements IRenderer {

   public BuiltRectangle(SizeState size, QuadRadiusState radius, QuadColorState color, float smoothness) {
      this.size = size;
      this.radius = radius;
      this.color = color;
      this.smoothness = smoothness;
   }

   public void render(Matrix4f matrix, float x, float y, float z) {
      try {
         // Пробуем использовать GPU-рендеринг (если доступен)
         renderGPU(matrix, x, y, z);
      } catch (Exception e) {
         // Fallback на CPU-рендеринг
         renderCPU(matrix, x, y, z);
      }
   }

   private void renderGPU(Matrix4f matrix, float x, float y, float z) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      
      float width = this.size.width();
      float height = this.size.height();
      
      // Используем стандартный шейдер для совместимости с 1.20.1
      Tessellator tessellator = Tessellator.getInstance();
      BufferBuilder builder = tessellator.getBuffer();
      builder.begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      
      // Рендерим как обычный прямоугольник с цветами углов
      builder.vertex(matrix, x, y, z).color(this.color.color1()).next();
      builder.vertex(matrix, x, y + height, z).color(this.color.color2()).next();
      builder.vertex(matrix, x + width, y + height, z).color(this.color.color3()).next();
      builder.vertex(matrix, x + width, y, z).color(this.color.color4()).next();
      
      tessellator.draw();
      
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   private void renderCPU(Matrix4f matrix, float x, float y, float z) {
      // Fallback на простой CPU-рендеринг
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      
      float width = this.size.width();
      float height = this.size.height();
      float avgRadius = (this.radius.radius1() + this.radius.radius2() + this.radius.radius3() + this.radius.radius4()) / 4.0f;
      
      // Используем усредненный цвет
      int avgColor = averageColor();
      
      // Простое закругление через CPU (как fallback)
      renderRoundedRectCPU(matrix, x, y, width, height, avgRadius, avgColor);
      
      RenderSystem.disableBlend();
   }

   private void renderRoundedRectCPU(Matrix4f matrix, float x, float y, float width, float height, float radius, int color) {
      Tessellator tessellator = Tessellator.getInstance();
      BufferBuilder builder = tessellator.getBuffer();
      builder.begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      
      // Основной прямоугольник
      builder.vertex(matrix, x + radius, y, 0).color(color).next();
      builder.vertex(matrix, x + radius, y + height, 0).color(color).next();
      builder.vertex(matrix, x + width - radius, y + height, 0).color(color).next();
      builder.vertex(matrix, x + width - radius, y, 0).color(color).next();
      
      // Левая часть
      builder.vertex(matrix, x, y + radius, 0).color(color).next();
      builder.vertex(matrix, x, y + height - radius, 0).color(color).next();
      builder.vertex(matrix, x + radius, y + height - radius, 0).color(color).next();
      builder.vertex(matrix, x + radius, y + radius, 0).color(color).next();
      
      // Правая часть
      builder.vertex(matrix, x + width - radius, y + radius, 0).color(color).next();
      builder.vertex(matrix, x + width - radius, y + height - radius, 0).color(color).next();
      builder.vertex(matrix, x + width, y + height - radius, 0).color(color).next();
      builder.vertex(matrix, x + width, y + radius, 0).color(color).next();
      
      tessellator.draw();
      
      // Углы (упрощенно)
      renderCornersCPU(matrix, x, y, width, height, radius, color);
   }

   private void renderCornersCPU(Matrix4f matrix, float x, float y, float width, float height, float radius, int color) {
      if (radius <= 0) return;
      
      Tessellator tessellator = Tessellator.getInstance();
      BufferBuilder builder = tessellator.getBuffer();
      builder.begin(DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
      
      int segments = Math.max(4, (int)(radius / 2)); // Адаптивное количество сегментов
      
      // Верхний левый угол
      renderCornerSegment(builder, matrix, x + radius, y + radius, radius, Math.PI, Math.PI * 1.5, segments, color);
      
      // Верхний правый угол
      renderCornerSegment(builder, matrix, x + width - radius, y + radius, radius, Math.PI * 1.5, Math.PI * 2, segments, color);
      
      // Нижний правый угол
      renderCornerSegment(builder, matrix, x + width - radius, y + height - radius, radius, 0, Math.PI * 0.5, segments, color);
      
      // Нижний левый угол
      renderCornerSegment(builder, matrix, x + radius, y + height - radius, radius, Math.PI * 0.5, Math.PI, segments, color);
      
      tessellator.draw();
   }

   private void renderCornerSegment(BufferBuilder builder, Matrix4f matrix, float centerX, float centerY, 
                                   float radius, double startAngle, double endAngle, int segments, int color) {
      double angleStep = (endAngle - startAngle) / segments;
      
      for (int i = 0; i < segments; i++) {
         double angle1 = startAngle + i * angleStep;
         double angle2 = startAngle + (i + 1) * angleStep;
         
         // Центр
         builder.vertex(matrix, centerX, centerY, 0).color(color).next();
         
         // Первая точка
         float x1 = centerX + (float)(Math.cos(angle1) * radius);
         float y1 = centerY + (float)(Math.sin(angle1) * radius);
         builder.vertex(matrix, x1, y1, 0).color(color).next();
         
         // Вторая точка
         float x2 = centerX + (float)(Math.cos(angle2) * radius);
         float y2 = centerY + (float)(Math.sin(angle2) * radius);
         builder.vertex(matrix, x2, y2, 0).color(color).next();
      }
   }

   private int averageColor() {
      int a = ((this.color.color1() >> 24 & 0xFF) + (this.color.color2() >> 24 & 0xFF) + 
               (this.color.color3() >> 24 & 0xFF) + (this.color.color4() >> 24 & 0xFF)) / 4;
      int r = ((this.color.color1() >> 16 & 0xFF) + (this.color.color2() >> 16 & 0xFF) + 
               (this.color.color3() >> 16 & 0xFF) + (this.color.color4() >> 16 & 0xFF)) / 4;
      int g = ((this.color.color1() >> 8 & 0xFF) + (this.color.color2() >> 8 & 0xFF) + 
               (this.color.color3() >> 8 & 0xFF) + (this.color.color4() >> 8 & 0xFF)) / 4;
      int b = ((this.color.color1() & 0xFF) + (this.color.color2() & 0xFF) + 
               (this.color.color3() & 0xFF) + (this.color.color4() & 0xFF)) / 4;
      
      return (a << 24) | (r << 16) | (g << 8) | b;
   }

   public SizeState size() {
      return this.size;
   }

   public QuadRadiusState radius() {
      return this.radius;
   }

   public QuadColorState color() {
      return this.color;
   }

   public float smoothness() {
      return this.smoothness;
   }
}