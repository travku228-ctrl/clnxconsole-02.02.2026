package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.util.AnimationUtil;
import com.whiterise.adminpanel.util.DrawHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.function.Consumer;

/**
 * Современный анимированный переключатель с плавной анимацией
 * Использует улучшенную систему анимации из DrawHelper
 */
public class ModernToggleWidget extends ClickableWidget {
    // Размеры (округляем для пиксель-перфект)
    private static final int OUTER_WIDTH = 32;      // 31.5 → 32
    private static final int OUTER_HEIGHT = 15;     // 15
    private static final int OUTER_RADIUS = 7;      // 15/2 = 7.5 → 7
    
    private static final int INNER_WIDTH = 28;      // 28.5 → 28
    private static final int INNER_HEIGHT = 12;     // 12.5 → 12
    private static final int INNER_RADIUS = 6;      // 12/2 = 6
    
    private static final int CIRCLE_SIZE = 12;      // 12
    
    // Цвета
    private static final int OUTER_COLOR = 0xFF28364D;    // #28364D
    private static final int INNER_COLOR = 0xFF575757;    // #575757
    private static final int CIRCLE_COLOR_OFF = 0xFF600000; // #600000
    private static final int CIRCLE_COLOR_ON = 0xFF009957;  // #009957
    
    // Состояния
    private boolean value;
    private final Consumer<Boolean> onChange;
    private final String label;
    
    // Анимация: линейная интерполяция за фиксированное время
    private float animationProgress = 0.0f; // от 0.0 (выкл) до 1.0 (вкл)
    private static final float ANIMATION_DURATION = 0.2f; // 200ms
    private long lastUpdateTime = System.currentTimeMillis();
    
    public ModernToggleWidget(int x, int y, String label, boolean initialValue, Consumer<Boolean> onChange) {
        super(x, y, OUTER_WIDTH, OUTER_HEIGHT, Text.literal(label));
        this.label = label;
        this.value = initialValue;
        this.onChange = onChange;
        this.animationProgress = initialValue ? 1.0f : 0.0f;
        this.lastUpdateTime = System.currentTimeMillis();
    }
    
    @Override
    public void renderButton(DrawContext context, int mouseX, int mouseY, float delta) {
        // Используем улучшенный DrawHelper для рендеринга
        boolean isHovered = isHovered() && active;
        
        DrawHelper.drawToggle(context, 
            getX(), getY(), 
            OUTER_WIDTH, OUTER_HEIGHT, 
            value, isHovered, false);
    }
    

    
    @Override
    public void onClick(double mouseX, double mouseY) {
        if (!active) return;
        
        // Меняем состояние
        this.value = !this.value;
        
        // Звук с разной высотой тона
        float pitch = value ? 1.2f : 0.8f;
        var mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.3f, pitch);
        }
        
        // Колбэк
        if (onChange != null) {
            onChange.accept(value);
        }
        
        super.onClick(mouseX, mouseY);
    }
    
    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE,
            Text.literal(label + ": " + (value ? "включено" : "выключено")));
    }
    

    
    // Геттеры и сеттеры
    public boolean getValue() {
        return value;
    }
    
    public void setValue(boolean value) {
        this.value = value;
        this.animationProgress = value ? 1.0f : 0.0f;
    }
    
    public String getLabel() {
        return label;
    }
    
    /**
     * Принудительно завершает анимацию
     */
    public void finishAnimation() {
        animationProgress = value ? 1.0f : 0.0f;
    }
}
