package com.whiterise.adminpanel.hud;

import com.whiterise.adminpanel.hud.elements.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Менеджер HUD-элементов
 */
public class HudManager {
    private static HudManager instance;
    private final List<HudElement> elements;
    private final MinecraftClient client;
    private final UnifiedHudBar unifiedBar; // НОВОЕ: единый HUD бар
    private boolean useUnifiedBar = true; // По умолчанию используем единый бар
    
    private HudManager() {
        this.client = MinecraftClient.getInstance();
        this.elements = new ArrayList<>();
        this.unifiedBar = new UnifiedHudBar();
        registerElements();
    }
    
    public static HudManager getInstance() {
        if (instance == null) {
            instance = new HudManager();
        }
        return instance;
    }
    
    /**
     * Регистрирует все HUD-элементы
     */
    private void registerElements() {
        // Старые отдельные элементы больше не используются - всё в Unified HUD Bar
        // elements.add(new FpsHudElement());
        // elements.add(new PingHudElement());
        // elements.add(new SessionTimeHudElement());
        // elements.add(new PunishmentsCountHudElement());
        // elements.add(new PlayerInfoHudElement());
    }
    
    /**
     * Рендерит все активные HUD-элементы
     */
    public void render(DrawContext context, float delta) {
        if (client.options.hudHidden) {
            return; // Не рендерим если HUD скрыт (F1)
        }
        
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();
        
        // НОВОЕ: рендерим единый бар вместо отдельных элементов
        if (useUnifiedBar) {
            unifiedBar.render(context, screenWidth, screenHeight, delta);
        } else {
            // Старый режим: отдельные элементы
            for (HudElement element : elements) {
                if (element.isEnabled()) {
                    context.getMatrices().push();
                    
                    // Применяем масштаб
                    float scale = element.getScale();
                    int x = element.getX(screenWidth);
                    int y = element.getY(screenHeight);
                    
                    context.getMatrices().translate(x, y, 0);
                    context.getMatrices().scale(scale, scale, 1.0f);
                    
                    // Рендерим элемент
                    element.render(context, screenWidth, screenHeight, delta);
                    
                    context.getMatrices().pop();
                }
            }
        }
    }
    
    /**
     * Получает элемент по ID
     */
    public HudElement getElement(String id) {
        return elements.stream()
            .filter(e -> e.getId().equals(id))
            .findFirst()
            .orElse(null);
    }
    
    /**
     * Получает все элементы
     */
    public List<HudElement> getAllElements() {
        return new ArrayList<>(elements);
    }
    
    /**
     * Получает единый HUD бар
     */
    public UnifiedHudBar getUnifiedBar() {
        return unifiedBar;
    }
    
    /**
     * Переключает режим HUD (единый бар / отдельные элементы)
     */
    public void setUseUnifiedBar(boolean useUnifiedBar) {
        this.useUnifiedBar = useUnifiedBar;
    }
    
    public boolean isUseUnifiedBar() {
        return useUnifiedBar;
    }
    
    /**
     * Загружает настройки из конфига
     */
    public void loadConfig() {
        HudConfig.load(this);
    }
    
    /**
     * Сохраняет настройки в конфиг
     */
    public void saveConfig() {
        HudConfig.save(this);
    }
}
