package com.whiterise.adminpanel.mixin;

import com.whiterise.adminpanel.AdminPanelClient;
import com.whiterise.adminpanel.auth.PermissionChecker;
import com.whiterise.adminpanel.data.SpamDetector;
import com.whiterise.adminpanel.data.ViolationLearner;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ЕДИНСТВЕННЫЙ хук для перехвата чата
 * Ловит ВСЕ сообщения, приходящие на клиент
 */
@Mixin(ChatHud.class)
public class ChatHudMixin {
    
    /**
     * Извлекает текст с цветовыми кодами из Text объекта
     * Конвертирует цвета в формат &#RRGGBB
     */
    private String extractLiteralWithCodes(Text text) {
        StringBuilder result = new StringBuilder();
        
        text.visit((style, content) -> {
            // Добавляем цветовой код если есть
            if (style.getColor() != null) {
                int color = style.getColor().getRgb();
                result.append(String.format("&#%06X", color & 0xFFFFFF));
            }
            
            // Добавляем текст
            result.append(content);
            
            return java.util.Optional.empty();
        }, net.minecraft.text.Style.EMPTY);
        
        return result.toString();
    }
    
    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V", at = @At("HEAD"))
    private void onChatMessage(Text message, MessageSignatureData signature, MessageIndicator indicator, CallbackInfo ci) {
        try {
            // Берем текст БЕЗ форматирования для логики
            String rawText = message.getString();
            
            // Пытаемся получить литеральный текст с кодами
            String literalText = extractLiteralWithCodes(message);
            
            if (rawText == null || rawText.isEmpty()) {
                return;
            }
            
            // ФИЛЬТРАЦИЯ: пустые сообщения (только пробелы)
            if (rawText.trim().isEmpty()) {
                return;
            }
            
            // ФИЛЬТРАЦИЯ: пропускаем системные сообщения сервера
            if (isSystemMessage(rawText)) {
                return;
            }
            
            // ДЕТЕКТОР СПАМА: проверяем сообщения игроков (ДО добавления в логи)
            detectSpam(rawText);
            
            // Передаем в ChatLogManager - сохраняем с цветовыми кодами
            AdminPanelClient.getChatLogManager().addRawMessage(literalText);
            
            // Передаем в PermissionChecker для проверки ошибок доступа
            PermissionChecker.onChatMessage(message);
            
            // ОТСЛЕЖИВАНИЕ НАКАЗАНИЙ: парсим команды наказаний из чата
            trackPunishmentFromChat(rawText);
            
            // МАШИННОЕ ОБУЧЕНИЕ: добавляем сообщение для возможного обучения
            addMessageForLearning(rawText);
            
        } catch (Exception e) {
            // Игнорируем ошибки
        }
    }
    
    /**
     * Детектор спама в чате
     * Отслеживает повторяющиеся сообщения от игроков
     */
    private void detectSpam(String rawText) {
        try {
            // Парсим никнейм и сообщение из чата
            // Формат: [время] [ранг] [префикс] никнейм » сообщение
            // Пример: [20:35:47] [+] [⚡ император Lowqq] » мой ах
            
            String[] parts = rawText.split(" » ");
            if (parts.length < 2) {
                return; // Не сообщение игрока
            }
            
            String messagePart = parts[parts.length - 1]; // Само сообщение
            String beforeMessage = parts[0]; // Все до »
            
            // Извлекаем никнейм (последнее слово перед »)
            String[] beforeParts = beforeMessage.split(" ");
            if (beforeParts.length == 0) {
                return;
            }
            
            String username = beforeParts[beforeParts.length - 1];
            
            // Очищаем никнейм от спецсимволов
            username = username.replaceAll("[^A-Za-z0-9_]", "");
            
            if (username.isEmpty() || username.length() < 3 || username.length() > 16) {
                return; // Невалидный никнейм
            }
            
            // Добавляем сообщение в детектор спама
            SpamDetector.addMessage(username, messagePart);
            
        } catch (Exception e) {
            // Игнорируем ошибки парсинга
        }
    }
    
    /**
     * Добавляет сообщение в систему машинного обучения
     */
    private void addMessageForLearning(String rawText) {
        try {
            // Парсим никнейм и сообщение
            String[] parts = rawText.split(" » ");
            if (parts.length < 2) {
                return;
            }
            
            String messagePart = parts[parts.length - 1];
            String beforeMessage = parts[0];
            
            String[] beforeParts = beforeMessage.split(" ");
            if (beforeParts.length == 0) {
                return;
            }
            
            String username = beforeParts[beforeParts.length - 1];
            username = username.replaceAll("[^A-Za-z0-9_]", "");
            
            if (username.isEmpty() || username.length() < 3 || username.length() > 16) {
                return;
            }
            
            // Добавляем в систему обучения
            ViolationLearner.addPlayerMessage(username, messagePart);
            
        } catch (Exception e) {
            // Игнорируем ошибки
        }
    }
    
    /**
     * Отслеживает наказания, выданные через чат (не через мод)
     * Парсит команды: /mute, /tempmute, /ban, /tempban, /banip, /unmute, /unban
     * И сообщения сервера о наказаниях
     */
    private void trackPunishmentFromChat(String rawText) {
        try {
            // 1. ПАРСИНГ КОМАНД (если вводим команду вручную)
            if (rawText.startsWith("/")) {
                parseCommandPunishment(rawText);
                return;
            }
            
            // 2. ПАРСИНГ СООБЩЕНИЙ СЕРВЕРА О НАКАЗАНИЯХ
            parseServerPunishmentMessage(rawText);
            
        } catch (Exception e) {
            // Игнорируем ошибки парсинга
        }
    }
    
    // Временные переменные для парсинга многострочных сообщений о наказаниях
    private String lastPunishmentTarget = null;
    private com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType lastPunishmentType = null;
    private String lastPunishmentReason = "-";
    private String lastPunishmentDuration = "-";
    
    /**
     * Парсит команды наказаний (когда вводим вручную)
     */
    private void parseCommandPunishment(String rawText) {
        String[] parts = rawText.split(" ");
        if (parts.length < 2) {
            return; // Недостаточно аргументов
        }
        
        String command = parts[0].toLowerCase();
        String targetNickname = parts[1];
        
        // Определяем тип наказания
        com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType type = null;
        String duration = "-";
        String reason = "-";
        
        switch (command) {
            case "/mute":
            case "/tempmute":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.MUTE;
                if (parts.length >= 3) {
                    duration = parts[2]; // Время
                }
                if (parts.length >= 4) {
                    reason = String.join(" ", java.util.Arrays.copyOfRange(parts, 3, parts.length));
                }
                break;
                
            case "/ban":
            case "/tempban":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.BAN;
                if (parts.length >= 3) {
                    duration = parts[2];
                }
                if (parts.length >= 4) {
                    reason = String.join(" ", java.util.Arrays.copyOfRange(parts, 3, parts.length));
                }
                break;
                
            case "/banip":
            case "/ipban":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.IP_BAN;
                if (parts.length >= 3) {
                    duration = parts[2];
                }
                if (parts.length >= 4) {
                    reason = String.join(" ", java.util.Arrays.copyOfRange(parts, 3, parts.length));
                }
                break;
                
            case "/unmute":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE;
                break;
                
            case "/unban":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN;
                break;
                
            default:
                return; // Не команда наказания
        }
        
        // Добавляем в историю наказаний
        if (type != null) {
            AdminPanelClient.getPunishmentManager().getPunishmentHistory().add(
                new com.whiterise.adminpanel.data.PunishmentRecord(
                    targetNickname,
                    type,
                    duration,
                    reason,
                    new java.util.ArrayList<>()
                )
            );
        }
    }
    
    /**
     * Парсит сообщения сервера о наказаниях
     * Формат: "Администратор X заблокировал чат игроку Y"
     */
    private void parseServerPunishmentMessage(String rawText) {
        // Убираем форматирование и цвета
        String cleanText = rawText.replaceAll("§[0-9a-fk-or]", "");
        
        com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType type = null;
        String targetNickname = null;
        
        // Определяем тип наказания по тексту
        if (cleanText.contains("заблокировал чат игроку")) {
            type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.MUTE;
            // Извлекаем никнейм: "Администратор X заблокировал чат игроку NICKNAME"
            String[] parts = cleanText.split("заблокировал чат игроку");
            if (parts.length >= 2) {
                targetNickname = parts[1].trim();
            }
        } else if (cleanText.contains("разблокировал чат игроку")) {
            type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE;
            String[] parts = cleanText.split("разблокировал чат игроку");
            if (parts.length >= 2) {
                targetNickname = parts[1].trim();
            }
        } else if (cleanText.contains("заблокировал игрока")) {
            type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.BAN;
            String[] parts = cleanText.split("заблокировал игрока");
            if (parts.length >= 2) {
                targetNickname = parts[1].trim();
            }
        } else if (cleanText.contains("разблокировал игрока")) {
            type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN;
            String[] parts = cleanText.split("разблокировал игрока");
            if (parts.length >= 2) {
                targetNickname = parts[1].trim();
            }
        } else if (cleanText.contains("заблокировал IP игрока")) {
            type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.IP_BAN;
            String[] parts = cleanText.split("заблокировал IP игрока");
            if (parts.length >= 2) {
                targetNickname = parts[1].trim();
            }
        }
        
        // Если нашли наказание - сохраняем для следующих строк
        if (type != null && targetNickname != null) {
            // Сохраняем временно для парсинга следующих строк (причина, срок)
            lastPunishmentType = type;
            lastPunishmentTarget = targetNickname;
            lastPunishmentReason = "-";
            lastPunishmentDuration = "-";
            return;
        }
        
        // Парсим дополнительную информацию (причина, срок)
        if (lastPunishmentTarget != null) {
            if (cleanText.contains("По причине:")) {
                String[] parts = cleanText.split("По причине:");
                if (parts.length >= 2) {
                    lastPunishmentReason = parts[1].trim();
                }
            } else if (cleanText.contains("Срок блокировки:")) {
                String[] parts = cleanText.split("Срок блокировки:");
                if (parts.length >= 2) {
                    lastPunishmentDuration = parts[1].trim();
                }
            } else if (cleanText.contains("Выдано:")) {
                // Последняя строка - добавляем наказание в историю
                AdminPanelClient.getPunishmentManager().getPunishmentHistory().add(
                    new com.whiterise.adminpanel.data.PunishmentRecord(
                        lastPunishmentTarget,
                        lastPunishmentType,
                        lastPunishmentDuration,
                        lastPunishmentReason,
                        new java.util.ArrayList<>()
                    )
                );
                
                // Сбрасываем временные данные
                lastPunishmentTarget = null;
                lastPunishmentType = null;
                lastPunishmentReason = null;
                lastPunishmentDuration = null;
            }
        }
    }
    
    /**
     * Проверяет, является ли сообщение системным (которое нужно скрыть)
     */
    private boolean isSystemMessage(String text) {
        // Сообщения о движении игроков
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] »") && (
            text.contains("⇑ Прямо") ||
            text.contains("⇖ Прямо налево") ||
            text.contains("⇐ Налево") ||
            text.contains("⇙ Назад налево") ||
            text.contains("⇓ Назад") ||
            text.contains("⇘ Назад направо") ||
            text.contains("⇒ Направо")
        )) {
            return true;
        }
        
        // Реклама бота и бонусов
        if (text.contains("╔ Мечтаете увеличить получаемые награды?") ||
            text.contains("╠ Напишите нашему боту, и он выдаст для вас инструкцию") ||
            text.contains("╚ Наш телеграм бот с бонусами: @wrfreebot") ||
            text.contains("➥ Нажмите, сюда чтобы перейти в бота")) {
            return true;
        }
        
        // Авто-шахта
        if (text.contains("« Авто-Шахта »") ||
            text.contains("╔ Успешно обновлена, редкость:") ||
            text.contains("╠ До обновлений следующей шахты") ||
            text.contains("╚ Быстрее вскопай пока не забрали все (/warp mine)") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно обновили шахту")) {
            return true;
        }
        
        // PvP сообщения
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » О господи") && 
            text.contains("разорвал в клочья") &&
            text.contains("кровавая битва окончилась победой")) {
            return true;
        }
        
        // Набор в команду
        if (text.contains("╔ Мы также открыли набор в команду нашего проекта") ||
            text.contains("╠ Присоединяйтесь к нашему дискорд серверу, чтобы") ||
            text.contains("╠ Подать заявку и пройти процесс рассмотрения") ||
            text.contains("╚ Ссылка на дискорд: dd.whiterise.su") ||
            text.contains("➥ Нажмите, сюда чтобы перейти в дискорд")) {
            return true;
        }
        
        // Скидки и промоакции
        if (text.contains("╔ Прямо сейчас на нашем ресурсе - грандиозная скидка") ||
            text.contains("╠ Масштабные промоакции уже доступны на сайте") ||
            text.contains("╚ Перейти к предложению: www.whiterise.su") ||
            text.contains("➥ Нажмите, сюда чтобы перейти на сайт")) {
            return true;
        }
        
        // Ивенты
        if (text.contains("Ивент ▷ Устрашающий Бокс") ||
            text.contains("Уже начался!") ||
            text.contains("Уровень лута: не ясен") ||
            text.contains("Скорее беги лутать его!") ||
            text.contains("● Узнать координаты - /box gps")) {
            return true;
        }
        
        // Ошибки команд
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Правильное использование: /history [ник]")) {
            return true;
        }
        
        // Режимы бога и полета
        if (text.contains("Режим бога включён.") ||
            text.contains("Режим бога выключен.") ||
            text.contains("Режим бога выключено.") ||
            text.contains("Режим полёта включён для") ||
            text.contains("Режим полёта выключено для")) {
            return true;
        }
        
        // События
        if (text.contains("╔ На нашем проекте регулярно проходят") ||
            text.contains("╠ Эксклюзивные мероприятия и события") ||
            text.contains("╚ Подробности по команде: /events")) {
            return true;
        }
        
        // Продажа предметов
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно продали на") && text.contains("⛂")) {
            return true;
        }
        
        // Наказания за выход из боя
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Данный игрок") && 
            text.contains("покинул игру во время битвы и был наказан")) {
            return true;
        }
        
        // Кики администратора
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Администратор Консоль кикнул игрока") &&
            text.contains("[ПОДРОБНЕЕ]")) {
            return true;
        }
        
        // Сессия активна
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Ваша сессия активна продолжайте игру")) {
            return true;
        }
        
        // Приветствие
        if (text.contains("• ☁ ᴍᴄ.ᴡʜɪᴛᴇʀɪsᴇ.sᴜ ☁ •") ||
            text.contains("Добро пожаловать на сервер!") ||
            text.contains("Вайп был") ||
            text.contains("Новичок? Введи /menu    поможет!") ||
            text.contains("Бесплатные хорошие награды,") ||
            text.contains("➥ Подробнее: /free")) {
            return true;
        }
        
        // Починка предметов
        if (text.contains("Вы успешно починили:") ||
            text.startsWith("Вы успешно починили ") ||
            text.contains("Ошибка: Нуждающиеся в починке предметы не найдены.")) {
            return true;
        }
        
        // Открытие кейсов
        if ((text.contains("╔ Данный игрок") && (
                text.contains("открыл бесплатный кейс,") ||
                text.contains("открыл рублевой кейс,") ||
                text.contains("открыл монетный кейс,")
            )) ||
            text.contains("╠ И выбил с данного кейса:") ||
            text.contains("╚ Покупка на сайте ᴡᴡᴡ.ᴡʜɪᴛᴇʀɪsᴇ.sᴜ")) {
            return true;
        }
        
        // Телепортация
        if (text.startsWith("Телепортация на ") && !text.contains(":")) {
            return true;
        }
        
        // Забрать ресурсы
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » У вас есть 30 сек чтобы забрать ресурсы")) {
            return true;
        }
        
        // Отладка хитбоксов
        if (text.contains("[Отладка]: Хитбоксы: вкл.") ||
            text.contains("[Отладка]: Хитбоксы: выкл.")) {
            return true;
        }
        
        // Двухфакторная защита
        if (text.contains("╔ Боитесь, что ваш аккаунт станет целью взлома?") ||
            text.contains("╠ Активируйте двухфакторную защиту") ||
            text.contains("╚ Для этого напишите нашему боту: @wrlinkbot") ||
            text.contains("➥ Нажмите, сюда чтобы перейти в бота")) {
            return true;
        }
        
        // Проверка игрока (AntiCheat)
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Проверка игрока завершена без наказания") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы начали проверку игрока") ||
            (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Данный игрок") && 
             text.contains("запросил слежку за собой") &&
             text.contains("(Нажмите чтобы телепортироваться)"))) {
            return true;
        }
        
        // Телепортация к игроку
        if (text.startsWith("Телепортация к ") && text.endsWith(".")) {
            return true;
        }
        
        // Установка режима игры
        if (text.contains("Установлен режим игры выживание для игрока") ||
            text.contains("Установлен режим игры наблюдатель для игрока")) {
            return true;
        }
        
        // Сообщения от Консоли с таймером
        if (text.matches("\\[⚠ \\d+\\.\\d+ \\(\\d+h\\)\\]") ||
            text.matches("\\[⚠ \\d+ \\(\\d+h\\)\\]") ||
            text.matches("\\[\\d{2}:\\d{2}:\\d{2}\\] Консоль:")) {
            return true;
        }
        
        // Игроки рядом
        if (text.equals("Игроки рядом:") || text.equals("Никого рядом нету")) {
            return true;
        }
        
        // Зарплата и рубли
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно получили свою зарплату") ||
            text.matches("\\d+ было зачислено на ваш счёт\\.") ||
            text.matches("\\[ᴡʜɪᴛᴇʀɪsᴇ\\] » Вы получили \\d+ рублей") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно получили рубли")) {
            return true;
        }
        
        // AFK сообщения
        if (text.equals("Вы отошли.") || text.equals("Вы вернулись.")) {
            return true;
        }
        
        // Самоубийство
        if (text.contains("покончил жизнь самоубийством.") ||
            text.equals("Прощай жестокий мир...")) {
            return true;
        }
        
        // Наборы
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно получили набор") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно получили награду")) {
            return true;
        }
        
        // Получение сообщений
        if (text.equals("Получение сообщений отключено.") ||
            text.equals("Получение сообщений включено.")) {
            return true;
        }
        
        // Ошибки команд checkban
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Правильное использование: /checkban [ник]") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но у вас недостаточно ключей для открытия") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но какой-то игрок уже открывает кейс")) {
            return true;
        }
        
        // Телепортация
        if (text.equals("Телепортация наверх.") ||
            text.equals("Возвращение на прежнюю локацию.")) {
            return true;
        }
        
        // Шары и партиклы
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно получили шар") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно включили партиклы") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно выключили партиклы") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно включили звуки") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Вы успешно выключили звуки")) {
            return true;
        }
        
        // CustomRune команды
        if (text.startsWith("/customrune particle") ||
            text.startsWith("/customrune sound") ||
            text.startsWith("/customrune giveshard")) {
            return true;
        }
        
        // Недостаточно прав
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » У вас недостаточно прав")) {
            return true;
        }
        
        // FAWE (WorldEdit) сообщения
        if (text.startsWith("(FAWE)") && (
            text.contains("Left click: select pos") ||
            text.contains("First position set to") ||
            text.contains("Second position set to")
        )) {
            return true;
        }
        
        // FAWE - ВСЕ сообщения от FastAsyncWorldEdit
        if (text.contains("(FAWE)")) {
            return true;
        }
        
        // СоцШпион
        if (text.contains("СоцШпион для") && (
            text.contains("выключено") || text.contains("включён")
        )) {
            return true;
        }
        
        // Действия администраторов (баны/муты с [ПОДРОБНЕЕ])
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Администратор") && text.contains("[ПОДРОБНЕЕ]") && (
            text.contains("заблокировал чат игроку") ||
            text.contains("забанил игрока")
        )) {
            return true;
        }
        
        // Попытка забаненного игрока зайти
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Данный игрок") && 
            text.contains("попытался зайти, но он забанен:")) {
            return true;
        }
        
        // Игрок не существует
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но данный игрок не существует")) {
            return true;
        }
        
        // Статистика администратора (многострочная)
        if (text.matches("╔ Банов за день: \\(\\d+/\\d+\\)") ||
            text.matches("╠ Мутов за день: \\(\\d+/\\d+\\)") ||
            text.matches("╠ Банов за неделю: \\d+") ||
            text.matches("╠ Мутов за неделю: \\d+") ||
            text.matches("╠ Банов за месяц: \\d+") ||
            text.matches("╠ Мутов за месяц: \\d+") ||
            text.matches("╠ Отыграно за день: \\d+ часов") ||
            text.contains("╠ Отыграно за день:") ||
            text.contains("╠ Отыграно за неделю:") ||
            text.contains("╠ До сброса статистки:") ||
            text.startsWith("╠ Группа игрока:") ||
            text.startsWith("╠ Ник игрока:") ||
            text.equals("╚ Норма: Не выполнена")) {
            return true;
        }
        
        // Проверка реального никнейма (realname)
        if (text.matches(".+ это .+")) {
            // Формат: "НИКНЕЙМ это НИКНЕЙМ"
            String[] parts = text.split(" это ");
            if (parts.length == 2 && !text.contains(" ")) {
                return true;
            }
        }
        
        // Попытка написать в мут
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Данный игрок") && 
            text.contains("попытался что-то написать, но его замутили")) {
            return true;
        }
        
        // Ошибка подбора ресурсов
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но вы не можете подбирать ресурсы") ||
            text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но вы не можете использовать эндер-перл")) {
            return true;
        }
        
        // Ошибка поиска игрока
        if (text.equals("Ошибка: Игрок не найден.")) {
            return true;
        }
        
        // Несуществующая команда
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Данной команды не существует. Воспользуйтесь /menu")) {
            return true;
        }
        
        // Граница мира
        if (text.contains("[!] Извините, но вы дошли до конца границы мира")) {
            return true;
        }
        
        // Предупреждение о спаме
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Хватит спамить если вы не прекратите вас может кикнуть")) {
            return true;
        }
        
        // Копирование никнейма
        if (text.startsWith("Ник скопирован: ")) {
            return true;
        }
        
        // Сообщение о копировании в буфер обмена
        if (text.equals("The message has been copied to your clipboard.")) {
            return true;
        }
        
        // Команды /grant и привилегии
        if (text.contains("При помощи команды {/grant}") ||
            text.contains("Привилегию") && text.contains("навсегда")) {
            return true;
        }
        
        // Донат сообщения
        if (text.contains("Донатер") && text.contains("подарил игроку")) {
            return true;
        }
        
        // Скорость ходьбы
        if (text.contains("Скорость ходьбы установлена на") && text.contains("для игрока")) {
            return true;
        }
        
        // Ошибка использования команд
        if (text.contains("[ᴡʜɪᴛᴇʀɪsᴇ] » Увы, но вы не можете использовать команды") ||
            text.contains("[WHITERISE] » Увы, но вы не можете использовать команды")) {
            return true;
        }
        
        return false;
    }
}
