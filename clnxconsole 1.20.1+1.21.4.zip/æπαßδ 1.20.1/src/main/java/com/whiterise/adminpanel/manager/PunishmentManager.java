package com.whiterise.adminpanel.manager;

import com.whiterise.adminpanel.data.PunishmentRecord;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class PunishmentManager {
    private static final int MAX_HISTORY = 1000; // Ограничение истории наказаний
    private final List<PunishmentRecord> punishmentHistory = new ArrayList<>();
    
    public void issueMute(String username, String duration, String reason) {
        String command = String.format("/tempmute %s %s %s", username, duration, reason);
        sendCommand(command);
        // ClientCommandMixin теперь отслеживает все команды автоматически
    }
    
    public void issueBan(String username, String duration, String reason) {
        // Если бан на 999d - делаем перманентный бан без времени
        String command;
        if ("999d".equals(duration)) {
            command = String.format("/ban %s %s", username, reason);
        } else {
            command = String.format("/ban %s %s %s", username, duration, reason);
        }
        sendCommand(command);
        // ClientCommandMixin теперь отслеживает все команды автоматически
    }
    
    public void issueIPBan(String username, String duration, String reason) {
        String command = String.format("/banip %s %s %s", username, duration, reason);
        sendCommand(command);
        // ClientCommandMixin теперь отслеживает все команды автоматически
    }
    
    public void issueUnmute(String username) {
        String command = String.format("/unmute %s", username);
        sendCommand(command);
        // ClientCommandMixin теперь отслеживает все команды автоматически
    }
    
    public void issueUnban(String username) {
        String command = String.format("/unban %s", username);
        sendCommand(command);
        // ClientCommandMixin теперь отслеживает все команды автоматически
    }
    
    private void sendCommand(String command) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.networkHandler.sendChatCommand(command.substring(1));
        }
    }
    
    public List<PunishmentRecord> getPunishmentHistory() {
        return punishmentHistory; // Возвращаем оригинальный список, а не копию
    }
    
    /**
     * Добавляет наказание в историю
     */
    public void addPunishment(PunishmentRecord record) {
        punishmentHistory.add(0, record); // Добавляем в начало (новые сверху)
        
        // Ограничиваем размер истории
        if (punishmentHistory.size() > MAX_HISTORY) {
            punishmentHistory.remove(punishmentHistory.size() - 1);
        }
    }
    
    /**
     * Очищает историю наказаний
     * Вызывается при disconnect
     */
    public void clear() {
        punishmentHistory.clear();
    }
    
    /**
     * Возвращает количество записей в истории
     */
    public int getHistorySize() {
        return punishmentHistory.size();
    }
}
