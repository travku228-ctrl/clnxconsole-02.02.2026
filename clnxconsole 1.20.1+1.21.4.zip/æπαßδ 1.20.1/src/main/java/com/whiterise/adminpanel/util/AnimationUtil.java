package com.whiterise.adminpanel.util;

/**
 * Утилиты для плавных анимаций UI элементов
 * Портировано из spacemoderation для улучшения визуальных эффектов
 */
public class AnimationUtil {
    
    /**
     * Плавная анимация с интерполяцией
     * @param current текущее значение
     * @param target целевое значение
     * @param speed скорость анимации (0.0 - 1.0)
     * @return новое значение
     */
    public static double animate(double current, double target, double speed) {
        double delta = target - current;
        return Math.abs(delta) < 0.001 ? target : current + delta * speed;
    }
    
    /**
     * Анимация с максимальным шагом
     * @param current текущее значение
     * @param target целевое значение
     * @param maxStep максимальный шаг за кадр
     * @return новое значение
     */
    public static double animateWithMaxStep(double current, double target, double maxStep) {
        double delta = target - current;
        return Math.abs(delta) < maxStep ? target : current + Math.copySign(maxStep, delta);
    }
    
    /**
     * Линейная интерполяция
     * @param start начальное значение
     * @param end конечное значение
     * @param progress прогресс (0.0 - 1.0)
     * @return интерполированное значение
     */
    public static double lerp(double start, double end, double progress) {
        return start + (end - start) * clamp(progress, 0.0, 1.0);
    }
    
    /**
     * Ease Out - замедление в конце
     * @param start начальное значение
     * @param end конечное значение
     * @param progress прогресс (0.0 - 1.0)
     * @return значение с ease out эффектом
     */
    public static double easeOut(double start, double end, double progress) {
        progress = clamp(progress, 0.0, 1.0);
        progress = 1.0 - Math.pow(1.0 - progress, 3.0);
        return start + (end - start) * progress;
    }
    
    /**
     * Ease In - ускорение в начале
     * @param start начальное значение
     * @param end конечное значение
     * @param progress прогресс (0.0 - 1.0)
     * @return значение с ease in эффектом
     */
    public static double easeIn(double start, double end, double progress) {
        progress = clamp(progress, 0.0, 1.0);
        progress = Math.pow(progress, 3.0);
        return start + (end - start) * progress;
    }
    
    /**
     * Ease In-Out - плавное ускорение и замедление
     * @param progress прогресс (0.0 - 1.0)
     * @return преобразованный прогресс
     */
    public static double easeInOut(double progress) {
        progress = clamp(progress, 0.0, 1.0);
        return progress < 0.5 
            ? 4.0 * progress * progress * progress 
            : 1.0 - Math.pow(-2.0 * progress + 2.0, 3.0) / 2.0;
    }
    
    /**
     * Ease Out Bounce - эффект отскока
     * @param start начальное значение
     * @param end конечное значение
     * @param progress прогресс (0.0 - 1.0)
     * @return значение с bounce эффектом
     */
    public static double easeOutBounce(double start, double end, double progress) {
        progress = clamp(progress, 0.0, 1.0);
        double n1 = 7.5625;
        double d1 = 2.75;
        double result;
        
        if (progress < 1.0 / d1) {
            result = n1 * progress * progress;
        } else if (progress < 2.0 / d1) {
            progress -= 1.5 / d1;
            result = n1 * progress * progress + 0.75;
        } else if (progress < 2.5 / d1) {
            progress -= 2.25 / d1;
            result = n1 * progress * progress + 0.9375;
        } else {
            progress -= 2.625 / d1;
            result = n1 * progress * progress + 0.984375;
        }
        
        return start + (end - start) * result;
    }
    
    /**
     * Ограничивает значение в диапазоне
     * @param value значение
     * @param min минимум
     * @param max максимум
     * @return ограниченное значение
     */
    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
    
    // Float версии для удобства
    
    public static float animate(float current, float target, float speed) {
        return (float) animate((double) current, (double) target, (double) speed);
    }
    
    public static float lerp(float start, float end, float progress) {
        return (float) lerp((double) start, (double) end, (double) progress);
    }
    
    public static float easeOut(float start, float end, float progress) {
        return (float) easeOut((double) start, (double) end, (double) progress);
    }
    
    public static float easeIn(float start, float end, float progress) {
        return (float) easeIn((double) start, (double) end, (double) progress);
    }
    
    public static float easeOutBounce(float start, float end, float progress) {
        return (float) easeOutBounce((double) start, (double) end, (double) progress);
    }
    
    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
