package com.whiterise.adminpanel.util;
import net.minecraft.client.gui.DrawContext;

/**
 * Универсальная библиотека для скругленных GUI элементов
 * Использует оригинальную систему закруглений
 */
public class RenderUtils {
    
    /**
     * Рисует скругленный прямоугольник
     */
    public static void fillRounded(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (radius <= 0) {
            context.fill(x, y, x + width, y + height, color);
            return;
        }
        
        radius = Math.min(radius, Math.min(width, height) / 2);
        
        // Основной прямоугольник (центр)
        context.fill(x + radius, y, x + width - radius, y + height, color);
        
        // Левая и правая полосы
        context.fill(x, y + radius, x + radius, y + height - radius, color);
        context.fill(x + width - radius, y + radius, x + width, y + height - radius, color);
        
        // Рисуем скругленные углы
        for (int i = 0; i < radius; i++) {
            int offset = (int) Math.sqrt(radius * radius - i * i);
            
            // Верхний левый угол
            context.fill(x + radius - offset, y + radius - i, x + radius, y + radius - i + 1, color);
            
            // Верхний правый угол
            context.fill(x + width - radius, y + radius - i, x + width - radius + offset, y + radius - i + 1, color);
            
            // Нижний левый угол
            context.fill(x + radius - offset, y + height - radius + i, x + radius, y + height - radius + i + 1, color);
            
            // Нижний правый угол
            context.fill(x + width - radius, y + height - radius + i, x + width - radius + offset, y + height - radius + i + 1, color);
        }
    }

    public static void drawRoundedBorder(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (radius <= 0) {
            context.fill(x, y, x + width, y + 1, color);
            context.fill(x, y + height - 1, x + width, y + height, color);
            context.fill(x, y, x + 1, y + height, color);
            context.fill(x + width - 1, y, x + width, y + height, color);
            return;
        }
        
        radius = Math.min(radius, Math.min(width, height) / 2);
        
        // Горизонтальные линии
        context.fill(x + radius, y, x + width - radius, y + 1, color); // Верх
        context.fill(x + radius, y + height - 1, x + width - radius, y + height, color); // Низ
        context.fill(x, y + radius, x + 1, y + height - radius, color); // Лево
        context.fill(x + width - 1, y + radius, x + width, y + height - radius, color); // Право
        
        // Рисуем 4 скругленных угла границы - только внешний контур
        for (int i = 0; i < radius; i++) {
            int dx = (int) Math.sqrt(radius * radius - i * i);
            
            // Верхний левый угол - крайний левый пиксель
            context.fill(x + radius - dx, y + radius - i, x + radius - dx + 1, y + radius - i + 1, color);
            
            // Верхний правый угол - крайний правый пиксель
            context.fill(x + width - radius + dx - 1, y + radius - i, x + width - radius + dx, y + radius - i + 1, color);
            
            // Нижний левый угол - крайний левый пиксель
            context.fill(x + radius - dx, y + height - radius + i, x + radius - dx + 1, y + height - radius + i + 1, color);
            
            // Нижний правый угол - крайний правый пиксель
            context.fill(x + width - radius + dx - 1, y + height - radius + i, x + width - radius + dx, y + height - radius + i + 1, color);
        }
    }

    public static int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    public static int applyOpacity(int color, float opacity) {
        int alpha = (int) ((color >> 24 & 0xFF) * opacity);
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    public static void fillRoundedRight(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (radius <= 0) {
            context.fill(x, y, x + width, y + height, color);
            return;
        }
        radius = Math.min(radius, Math.min(width, height) / 2);
        context.fill(x, y, x + width - radius, y + height, color);
        context.fill(x + width - radius, y + radius, x + width, y + height - radius, color);
        for (int i = 0; i < radius; i++) {
            int offset = (int) Math.sqrt(radius * radius - i * i);
            context.fill(x + width - radius + i, y + radius - offset, x + width - radius + i + 1, y + radius, color);
            context.fill(x + width - radius + i, y + height - radius, x + width - radius + i + 1, y + height - radius + offset, color);
        }
    }

    public static void drawRoundedBorderRight(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (radius <= 0) {
            context.fill(x, y, x + width, y + 1, color);
            context.fill(x, y + height - 1, x + width, y + height, color);
            context.fill(x, y, x + 1, y + height, color);
            context.fill(x + width - 1, y, x + width, y + height, color);
            return;
        }
        radius = Math.min(radius, Math.min(width, height) / 2);
        context.fill(x, y, x + width - radius, y + 1, color);
        context.fill(x, y + height - 1, x + width - radius, y + height, color);
        context.fill(x, y, x + 1, y + height, color);
        context.fill(x + width - 1, y + radius, x + width, y + height - radius, color);
        for (int i = 0; i < radius; i++) {
            int offset = (int) Math.sqrt(radius * radius - i * i);
            if (offset > 0) {
                context.fill(x + width - radius + i, y + radius - offset, x + width - radius + i + 1, y + radius - offset + 1, color);
                context.fill(x + width - radius + i, y + height - radius + offset - 1, x + width - radius + i + 1, y + height - radius + offset, color);
            }
        }
    }

    /**
     * Рисует скругленный прямоугольник с градиентом
     * Упрощенная версия - использует fillRounded для избежания дырок в углах
     */
    public static void fillRoundedGradient(DrawContext context, int x, int y, int width, int height, int radius, int colorStart, int colorEnd) {
        if (radius <= 0) {
            context.fillGradient(x, y, x + width, y + height, colorStart, colorEnd);
            return;
        }
        
        // Используем простой fillRounded с усредненным цветом
        // Это устраняет дырки в углах, а градиент практически незаметен на маленьких элементах
        int avgAlpha = ((colorStart >> 24 & 0xFF) + (colorEnd >> 24 & 0xFF)) / 2;
        int avgRed = ((colorStart >> 16 & 0xFF) + (colorEnd >> 16 & 0xFF)) / 2;
        int avgGreen = ((colorStart >> 8 & 0xFF) + (colorEnd >> 8 & 0xFF)) / 2;
        int avgBlue = ((colorStart & 0xFF) + (colorEnd & 0xFF)) / 2;
        int avgColor = (avgAlpha << 24) | (avgRed << 16) | (avgGreen << 8) | avgBlue;
        
        fillRounded(context, x, y, width, height, radius, avgColor);
    }

    /**
     * Рисует многослойную тень для эффекта "парения"
     */
    public static void drawLayeredShadow(DrawContext context, int x, int y, int width, int height, int radius, int layers, boolean isHovered) {
        int shadowOffset = isHovered ? 4 : 2;
        int shadowOpacity = isHovered ? 0x55 : 0x33;
        for (int i = layers; i > 0; i--) {
            int offset = shadowOffset + (layers - i);
            int opacity = shadowOpacity / (i + 1);
            int shadowColor = (opacity << 24) | 0x000000;
            fillRounded(context, x + offset, y + offset, width, height, radius, shadowColor);
        }
    }

    /**
     * Рисует свечение вокруг элемента
     */
    public static void drawGlow(DrawContext context, int x, int y, int width, int height, int radius, int glowColor, int intensity) {
        int alpha = (glowColor >> 24) & 0xFF;
        int red = (glowColor >> 16) & 0xFF;
        int green = (glowColor >> 8) & 0xFF;
        int blue = glowColor & 0xFF;
        for (int i = 0; i < intensity; i++) {
            int offset = i;
            int glowAlpha = (int) (alpha * (1.0f - (float) i / intensity) * 0.3f);
            int glowColorWithAlpha = (glowAlpha << 24) | (red << 16) | (green << 8) | blue;
            fillRounded(context, x - offset, y - offset, width + offset * 2, height + offset * 2, radius + offset, glowColorWithAlpha);
        }
    }

    /**
     * Интерполирует цвет между двумя значениями
     */
    public static int interpolateColor(int colorFrom, int colorTo, float progress) {
        progress = Math.max(0.0f, Math.min(1.0f, progress));
        int a1 = (colorFrom >> 24) & 0xFF;
        int r1 = (colorFrom >> 16) & 0xFF;
        int g1 = (colorFrom >> 8) & 0xFF;
        int b1 = colorFrom & 0xFF;
        int a2 = (colorTo >> 24) & 0xFF;
        int r2 = (colorTo >> 16) & 0xFF;
        int g2 = (colorTo >> 8) & 0xFF;
        int b2 = colorTo & 0xFF;
        int a = (int) (a1 + (a2 - a1) * progress);
        int r = (int) (r1 + (r2 - r1) * progress);
        int g = (int) (g1 + (g2 - g1) * progress);
        int b = (int) (b1 + (b2 - b1) * progress);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Включает scissor для скругленного контейнера с учетом отступов
     * Используется для правильного обрезания содержимого по скругленным краям
     */
    public static void enableRoundedScissor(DrawContext context, int x, int y, int width, int height, int radius) {
        // Учитываем радиус скругления при установке scissor
        // Внутренняя область контейнера (без углов)
        int padding = Math.max(1, radius / 2);
        context.enableScissor(x + padding, y + padding, x + width - padding, y + height - padding);
    }
}