package com.whiterise.adminpanel.mixin;

import com.whiterise.adminpanel.sound.SoundManager;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Миксин для добавления звука набора текста в TextFieldWidget
 */
@Mixin(TextFieldWidget.class)
public abstract class TextFieldWidgetMixin {
    
    @Shadow
    private String text;
    
    private String lastText = "";
    
    /**
     * Воспроизводит звук при изменении текста
     */
    @Inject(method = "write", at = @At("TAIL"))
    private void onTextChanged(String text, CallbackInfo ci) {
        // Проверяем, изменился ли текст
        String currentText = this.text;
        if (currentText != null && !currentText.equals(lastText)) {
            // Воспроизводим звук только если текст действительно изменился
            if (currentText.length() != lastText.length()) {
                SoundManager.playTypeSound();
            }
            lastText = currentText;
        }
    }
}
