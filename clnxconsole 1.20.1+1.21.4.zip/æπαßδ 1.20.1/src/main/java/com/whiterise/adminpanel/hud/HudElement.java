package com.whiterise.adminpanel.hud;

/**
 * Базовый класс для HUD-элемента
 */
public abstract class HudElement {
    private String id;
    private String name;
    private boolean enabled;
    private HudPosition position;
    private float scale;
    private float opacity;
    private int offsetX;
    private int offsetY;
    
    public HudElement(String id, String name) {
        this.id = id;
        this.name = name;
        this.enabled = true;
        this.position = HudPosition.TOP_LEFT;
        this.scale = 1.0f;
        this.opacity = 0.8f;
        this.offsetX = 10;
        this.offsetY = 10;
    }
    
    /**
     * Рендерит элемент на экране
     */
    public abstract void render(net.minecraft.client.gui.DrawContext context, int screenWidth, int screenHeight, float delta);
    
    /**
     * Получает ширину элемента
     */
    public abstract int getWidth();
    
    /**
     * Получает высоту элемента
     */
    public abstract int getHeight();
    
    /**
     * Вычисляет X координату на основе позиции
     */
    public int getX(int screenWidth) {
        int width = (int)(getWidth() * scale);
        switch (position) {
            case TOP_LEFT:
            case BOTTOM_LEFT:
                return offsetX;
            case TOP_RIGHT:
            case BOTTOM_RIGHT:
                return screenWidth - width - offsetX;
            case FREE:
                return offsetX;
            default:
                return offsetX;
        }
    }
    
    /**
     * Вычисляет Y координату на основе позиции
     */
    public int getY(int screenHeight) {
        int height = (int)(getHeight() * scale);
        switch (position) {
            case TOP_LEFT:
            case TOP_RIGHT:
                return offsetY;
            case BOTTOM_LEFT:
            case BOTTOM_RIGHT:
                return screenHeight - height - offsetY;
            case FREE:
                return offsetY;
            default:
                return offsetY;
        }
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public String getName() { return name; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public HudPosition getPosition() { return position; }
    public void setPosition(HudPosition position) { this.position = position; }
    public float getScale() { return scale; }
    public void setScale(float scale) { this.scale = Math.max(0.5f, Math.min(2.0f, scale)); }
    public float getOpacity() { return opacity; }
    public void setOpacity(float opacity) { this.opacity = Math.max(0.0f, Math.min(1.0f, opacity)); }
    public int getOffsetX() { return offsetX; }
    public void setOffsetX(int offsetX) { this.offsetX = offsetX; }
    public int getOffsetY() { return offsetY; }
    public void setOffsetY(int offsetY) { this.offsetY = offsetY; }
    
    /**
     * Позиции HUD-элементов
     */
    public enum HudPosition {
        TOP_LEFT("Левый верх"),
        TOP_RIGHT("Правый верх"),
        BOTTOM_LEFT("Левый низ"),
        BOTTOM_RIGHT("Правый низ"),
        FREE("Свободная");
        
        private final String displayName;
        
        HudPosition(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
}
