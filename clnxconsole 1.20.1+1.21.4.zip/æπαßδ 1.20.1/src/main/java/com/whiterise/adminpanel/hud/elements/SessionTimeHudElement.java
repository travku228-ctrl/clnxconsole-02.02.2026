package com.whiterise.adminpanel.hud.elements;

import com.whiterise.adminpanel.hud.HudElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * HUD-элемент: Время текущей сессии на сервере
 */
public class SessionTimeHudElement extends HudElement {
    private static final int COLOR_BG = 0xE61A2332;
    private static final int COLOR_BG_GRADIENT = 0xE6161C26;
    private static final int COLOR_ACCENT = 0xFF00D9FF;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_SHADOW = 0x88000000;
    private static final int COLOR_BORDER = 0x40FFFFFF;
    
    private long sessionStartTime = 0;
    
    public SessionTimeHudElement() {
        super("session_time", "Время сессии");
        setPosition(HudPosition.TOP_RIGHT);
        setOffsetY(80);
    }
    
    @Override
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Инициализируем время начала сессии
        if (sessionStartTime == 0 && client.world != null) {
            sessionStartTime = System.currentTimeMillis();
        }
        
        // Сбрасываем при выходе с сервера
        if (client.world == null) {
            sessionStartTime = 0;
            return;
        }
        
        // Вычисляем время сессии
        long elapsed = System.currentTimeMillis() - sessionStartTime;
        String timeStr = formatTime(elapsed);
        
        int width = getWidth();
        int height = getHeight();
        
        // Тень
        int shadowColor = applyOpacity(COLOR_SHADOW);
        fillRounded(context, 2, 2, width, height, 8, shadowColor);
        
        // Фон с градиентом
        int bgColor = applyOpacity(COLOR_BG);
        int bgGradient = applyOpacity(COLOR_BG_GRADIENT);
        fillRounded(context, 0, 0, width, height, 8, bgColor);
        context.fillGradient(8, 0, width - 8, height, bgColor, bgGradient);
        
        // Тонкая светлая рамка
        int borderColor = applyOpacity(COLOR_BORDER);
        drawRoundedBorder(context, 0, 0, width, height, 8, borderColor);
        
        // Иконка с фоном
        int iconBgColor = applyOpacity(0x3000D9FF);
        fillRounded(context, 4, 4, 20, 20, 4, iconBgColor);
        context.drawText(client.textRenderer, "⏱", 8, 9, COLOR_ACCENT, false);
        
        // Текст
        context.drawText(client.textRenderer, timeStr, 30, 9, COLOR_TEXT, false);
    }
    
    /**
     * Форматирует время в читаемый вид (ЧЧ:ММ:СС)
     */
    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, secs);
        } else {
            return String.format("%02d:%02d", minutes, secs);
        }
    }
    
    @Override
    public int getWidth() {
        return 100;
    }
    
    @Override
    public int getHeight() {
        return 28;
    }
    
    private int applyOpacity(int color) {
        int alpha = (int)((color >> 24 & 0xFF) * getOpacity());
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
    
    private void fillRounded(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        context.fill(x + radius, y, x + width - radius, y + height, color);
        context.fill(x, y + radius, x + radius, y + height - radius, color);
        context.fill(x + width - radius, y + radius, x + width, y + height - radius, color);
        
        drawCorner(context, x, y, radius, color, 0);
        drawCorner(context, x + width - radius, y, radius, color, 1);
        drawCorner(context, x, y + height - radius, radius, color, 2);
        drawCorner(context, x + width - radius, y + height - radius, radius, color, 3);
    }
    
    private void drawCorner(DrawContext context, int x, int y, int radius, int color, int corner) {
        switch (corner) {
            case 0: context.fill(x + 2, y, x + radius, y + 1, color); context.fill(x + 1, y + 1, x + radius, y + 2, color); context.fill(x, y + 2, x + radius, y + radius, color); break;
            case 1: context.fill(x, y, x + radius - 2, y + 1, color); context.fill(x, y + 1, x + radius - 1, y + 2, color); context.fill(x, y + 2, x + radius, y + radius, color); break;
            case 2: context.fill(x, y, x + radius, y + radius - 2, color); context.fill(x + 1, y + radius - 2, x + radius, y + radius - 1, color); context.fill(x + 2, y + radius - 1, x + radius, y + radius, color); break;
            case 3: context.fill(x, y, x + radius, y + radius - 2, color); context.fill(x, y + radius - 2, x + radius - 1, y + radius - 1, color); context.fill(x, y + radius - 1, x + radius - 2, y + radius, color); break;
        }
    }
    
    private void drawRoundedBorder(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        context.fill(x + radius, y, x + width - radius, y + 1, color);
        context.fill(x + radius, y + height - 1, x + width - radius, y + height, color);
        context.fill(x, y + radius, x + 1, y + height - radius, color);
        context.fill(x + width - 1, y + radius, x + width, y + height - radius, color);
        
        context.fill(x + 2, y, x + radius, y + 1, color);
        context.fill(x + 1, y + 1, x + 2, y + 2, color);
        context.fill(x, y + 2, x + 1, y + radius, color);
        context.fill(x + width - radius, y, x + width - 2, y + 1, color);
        context.fill(x + width - 2, y + 1, x + width - 1, y + 2, color);
        context.fill(x + width - 1, y + 2, x + width, y + radius, color);
        context.fill(x, y + height - radius, x + 1, y + height - 2, color);
        context.fill(x + 1, y + height - 2, x + 2, y + height - 1, color);
        context.fill(x + 2, y + height - 1, x + radius, y + height, color);
        context.fill(x + width - 1, y + height - radius, x + width, y + height - 2, color);
        context.fill(x + width - 2, y + height - 2, x + width - 1, y + height - 1, color);
        context.fill(x + width - radius, y + height - 1, x + width - 2, y + height, color);
    }
}
