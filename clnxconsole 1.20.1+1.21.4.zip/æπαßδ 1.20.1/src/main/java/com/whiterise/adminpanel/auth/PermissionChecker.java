package com.whiterise.adminpanel.auth;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Проверка прав доступа к моду
 * Проверяет наличие доступа к команде /history
 */
public class PermissionChecker {
    
    private static boolean hasPermission = false;
    private static boolean isChecking = false;
    private static boolean wasCheckedThisSession = false;
    private static String lastErrorMessage = null;
    
    /**
     * Проверяет есть ли у игрока права на использование мода
     * Отправляет команду /history и ждет ответ
     */
    public static void checkPermission(Runnable onSuccess, Runnable onFailure) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        if (client.player == null || client.getNetworkHandler() == null) {
            onFailure.run();
            return;
        }
        
        // Если уже проверяли в этой сессии - используем сохраненный результат
        if (wasCheckedThisSession) {
            if (hasPermission) {
                onSuccess.run();
            } else {
                onFailure.run();
            }
            return;
        }
        
        // Если уже проверяем - не делаем повторную проверку
        if (isChecking) {
            return;
        }
        
        isChecking = true;
        lastErrorMessage = null;
        
        // Подписываемся на сообщения чата для перехвата ошибок
        setupMessageListener(client, onSuccess, onFailure);
        
        // Отправляем команду /history
        client.player.networkHandler.sendChatCommand("history");
    }
    
    /**
     * Настраивает слушатель сообщений для перехвата ответа сервера
     */
    private static void setupMessageListener(MinecraftClient client, Runnable onSuccess, Runnable onFailure) {
        new Thread(() -> {
            try {
                // Ждем ответ от сервера (500ms)
                Thread.sleep(500);
                
                // Выполняем на главном потоке
                client.execute(() -> {
                    isChecking = false;
                    wasCheckedThisSession = true;
                    
                    // Проверяем последнее сообщение об ошибке
                    if (lastErrorMessage != null) {
                        String error = lastErrorMessage.toLowerCase();
                        
                        // Проверяем на ошибки доступа
                        if (error.contains("permission") || 
                            error.contains("don't have") ||
                            error.contains("not allowed") ||
                            error.contains("unknown command") ||
                            error.contains("не хватает прав") ||
                            error.contains("нет прав") ||
                            error.contains("недостаточно прав")) {
                            
                            hasPermission = false;
                            onFailure.run();
                            return;
                        }
                    }
                    
                    // Если ошибок нет - считаем что права есть
                    hasPermission = true;
                    onSuccess.run();
                });
            } catch (InterruptedException e) {
                client.execute(() -> {
                    isChecking = false;
                    wasCheckedThisSession = true;
                    hasPermission = false;
                    onFailure.run();
                });
            }
        }).start();
    }
    
    /**
     * Вызывается из ChatHudMixin при получении сообщения
     * Сохраняет последнее сообщение для проверки
     */
    public static void onChatMessage(Text message) {
        if (isChecking) {
            lastErrorMessage = message.getString();
        }
    }
    
    /**
     * Быстрая проверка без отправки команды
     */
    public static boolean hasPermissionCached() {
        return hasPermission;
    }
    
    /**
     * Сбрасывает кеш проверки прав
     */
    public static void resetCache() {
        hasPermission = false;
        wasCheckedThisSession = false;
        isChecking = false;
        lastErrorMessage = null;
    }
}
