package com.whiterise.adminpanel.background;

import java.util.Random;

/**
 * Фоновая частица для GUI
 * 
 * Представляет одну анимированную частицу с плавным движением и отскоком от краёв экрана
 * Используется в эффекте "particle network" для создания динамического фона
 */
public class BackgroundParticle {
    // Текущая позиция частицы
    private float x;
    private float y;
    
    // Скорость движения (пикселей в секунду)
    private float velocityX;
    private float velocityY;
    
    // Радиус частицы
    private float radius;
    
    // Границы экрана для отскока
    private int screenWidth;
    private int screenHeight;
    
    // Для хаотичного движения
    private final Random random = new Random();
    private float directionChangeTimer = 0;
    private static final float DIRECTION_CHANGE_INTERVAL = 2.0f; // Меняем направление каждые 2 секунды
    private static final float DIRECTION_CHANGE_AMOUNT = 20.0f; // Величина изменения скорости
    
    /**
     * Конструктор частицы
     */
    public BackgroundParticle(float x, float y, float velocityX, float velocityY, float radius, int screenWidth, int screenHeight) {
        this.x = x;
        this.y = y;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.radius = radius;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    
    /**
     * Обновление позиции частицы
     * Плавное движение с хаотичными изменениями направления
     * БЕЗ отскока от краёв - частицы могут вылетать за границы
     */
    public void update(float delta) {
        // Хаотичное изменение направления
        directionChangeTimer += delta;
        if (directionChangeTimer >= DIRECTION_CHANGE_INTERVAL) {
            directionChangeTimer = 0;
            
            // Случайное изменение скорости для хаотичности
            velocityX += (random.nextFloat() - 0.5f) * DIRECTION_CHANGE_AMOUNT;
            velocityY += (random.nextFloat() - 0.5f) * DIRECTION_CHANGE_AMOUNT;
            
            // Ограничиваем скорость
            float speed = (float) Math.sqrt(velocityX * velocityX + velocityY * velocityY);
            if (speed > 60.0f) {
                velocityX = (velocityX / speed) * 60.0f;
                velocityY = (velocityY / speed) * 60.0f;
            }
            if (speed < 15.0f) {
                velocityX = (velocityX / speed) * 15.0f;
                velocityY = (velocityY / speed) * 15.0f;
            }
        }
        
        // Плавное движение
        x += velocityX * delta;
        y += velocityY * delta;
        
        // НЕ отскакиваем от краёв - частицы могут вылетать
        // Они будут удалены и заспавнены заново в ParticleRenderer
    }
    
    /**
     * Обновление размеров экрана (при изменении разрешения)
     */
    public void updateScreenSize(int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    
    // Геттеры
    public float getX() {
        return x;
    }
    
    public float getY() {
        return y;
    }
    
    public float getRadius() {
        return radius;
    }
}
