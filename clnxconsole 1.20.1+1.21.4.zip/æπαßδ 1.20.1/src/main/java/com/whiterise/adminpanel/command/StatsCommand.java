package com.whiterise.adminpanel.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.whiterise.adminpanel.data.ViolationLearner;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;

/**
 * Команда для просмотра статистики обучения
 */
public class StatsCommand {
    
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(
            ClientCommandManager.literal("clnxstats")
                .executes(StatsCommand::execute)
        );
    }
    
    private static int execute(CommandContext<FabricClientCommandSource> context) {
        String stats = ViolationLearner.getStatistics();
        
        // Разбиваем на строки и отправляем каждую
        String[] lines = stats.split("\n");
        for (String line : lines) {
            context.getSource().sendFeedback(Text.literal("§b" + line));
        }
        
        return 1;
    }
}
