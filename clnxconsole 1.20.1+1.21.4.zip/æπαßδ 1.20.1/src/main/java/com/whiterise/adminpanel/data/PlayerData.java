package com.whiterise.adminpanel.data;

public class PlayerData {
    private final String username;
    private long lastChatActivity;
    
    public PlayerData(String username) {
        this.username = username;
        this.lastChatActivity = System.currentTimeMillis();
    }
    
    public String getUsername() {
        return username;
    }
    
    public long getLastChatActivity() {
        return lastChatActivity;
    }
    
    public void updateChatActivity() {
        this.lastChatActivity = System.currentTimeMillis();
    }
}
