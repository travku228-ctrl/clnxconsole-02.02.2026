package com.whiterise.adminpanel.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

/**
 * Renderer for smooth rounded panels using pre-generated textures with antialiasing
 */
public class NinePatchRenderer {
    
    /**
     * Renders a panel with rounding only on the right side using texture
     * @param context DrawContext
     * @param x X position
     * @param y Y position
     * @param width Panel width
     * @param height Panel height
     * @param textureId Texture identifier
     * @param color Tint color (0xAARRGGBB)
     */
    public static void renderRoundedRightPanel(DrawContext context, int x, int y, int width, int height, 
                                                Identifier textureId, int color) {
        float alpha = (color >> 24 & 0xFF) / 255.0f;
        float red = (color >> 16 & 0xFF) / 255.0f;
        float green = (color >> 8 & 0xFF) / 255.0f;
        float blue = (color & 0xFF) / 255.0f;
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, textureId);
        
        // Enable linear filtering for smooth edges
        RenderSystem.setShaderColor(red, green, blue, alpha);
        
        Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        
        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        
        // Render texture stretched to fit the panel
        buffer.vertex(matrix, x, y + height, 0).texture(0, 1).color(red, green, blue, alpha).next();
        buffer.vertex(matrix, x + width, y + height, 0).texture(1, 1).color(red, green, blue, alpha).next();
        buffer.vertex(matrix, x + width, y, 0).texture(1, 0).color(red, green, blue, alpha).next();
        buffer.vertex(matrix, x, y, 0).texture(0, 0).color(red, green, blue, alpha).next();
        
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.disableBlend();
    }
    
    /**
     * Renders a 9-patch panel (scalable with preserved corners)
     * @param context DrawContext
     * @param x X position
     * @param y Y position
     * @param width Panel width
     * @param height Panel height
     * @param textureId Texture identifier
     * @param cornerSize Size of corner regions in texture
     * @param edgeSize Size of edge region in texture
     * @param color Tint color
     */
    public static void renderNinePatch(DrawContext context, int x, int y, int width, int height,
                                        Identifier textureId, int cornerSize, int edgeSize, int color) {
        float alpha = (color >> 24 & 0xFF) / 255.0f;
        float red = (color >> 16 & 0xFF) / 255.0f;
        float green = (color >> 8 & 0xFF) / 255.0f;
        float blue = (color & 0xFF) / 255.0f;
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, textureId);
        RenderSystem.setShaderColor(red, green, blue, alpha);
        
        Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().getBuffer();
        
        int textureSize = cornerSize * 2 + edgeSize;
        float cornerU = (float) cornerSize / textureSize;
        float edgeU = (float) (cornerSize + edgeSize) / textureSize;
        
        buffer.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        
        // Top-left corner
        renderQuad(buffer, matrix, x, y, cornerSize, cornerSize, 
                   0, 0, cornerU, cornerU, red, green, blue, alpha);
        
        // Top edge (stretched)
        renderQuad(buffer, matrix, x + cornerSize, y, width - cornerSize * 2, cornerSize,
                   cornerU, 0, edgeU, cornerU, red, green, blue, alpha);
        
        // Top-right corner
        renderQuad(buffer, matrix, x + width - cornerSize, y, cornerSize, cornerSize,
                   edgeU, 0, 1, cornerU, red, green, blue, alpha);
        
        // Left edge (stretched)
        renderQuad(buffer, matrix, x, y + cornerSize, cornerSize, height - cornerSize * 2,
                   0, cornerU, cornerU, edgeU, red, green, blue, alpha);
        
        // Center (stretched)
        renderQuad(buffer, matrix, x + cornerSize, y + cornerSize, 
                   width - cornerSize * 2, height - cornerSize * 2,
                   cornerU, cornerU, edgeU, edgeU, red, green, blue, alpha);
        
        // Right edge (stretched)
        renderQuad(buffer, matrix, x + width - cornerSize, y + cornerSize, 
                   cornerSize, height - cornerSize * 2,
                   edgeU, cornerU, 1, edgeU, red, green, blue, alpha);
        
        // Bottom-left corner
        renderQuad(buffer, matrix, x, y + height - cornerSize, cornerSize, cornerSize,
                   0, edgeU, cornerU, 1, red, green, blue, alpha);
        
        // Bottom edge (stretched)
        renderQuad(buffer, matrix, x + cornerSize, y + height - cornerSize, 
                   width - cornerSize * 2, cornerSize,
                   cornerU, edgeU, edgeU, 1, red, green, blue, alpha);
        
        // Bottom-right corner
        renderQuad(buffer, matrix, x + width - cornerSize, y + height - cornerSize, 
                   cornerSize, cornerSize,
                   edgeU, edgeU, 1, 1, red, green, blue, alpha);
        
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.disableBlend();
    }
    
    /**
     * Helper method to render a single quad with texture coordinates
     */
    private static void renderQuad(BufferBuilder buffer, Matrix4f matrix,
                                    float x, float y, float width, float height,
                                    float u1, float v1, float u2, float v2,
                                    float r, float g, float b, float a) {
        buffer.vertex(matrix, x, y + height, 0).texture(u1, v2).color(r, g, b, a).next();
        buffer.vertex(matrix, x + width, y + height, 0).texture(u2, v2).color(r, g, b, a).next();
        buffer.vertex(matrix, x + width, y, 0).texture(u2, v1).color(r, g, b, a).next();
        buffer.vertex(matrix, x, y, 0).texture(u1, v1).color(r, g, b, a).next();
    }
}
