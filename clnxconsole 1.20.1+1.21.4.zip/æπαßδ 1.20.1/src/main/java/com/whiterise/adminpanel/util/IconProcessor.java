package com.whiterise.adminpanel.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Processes icons by adding background and colorizing WITHOUT changing quality or size
 */
public class IconProcessor {
    
    private static final Color BG_COLOR = new Color(0x31, 0x25, 0x41, 255); // #312541
    private static final Color ICON_COLOR = new Color(0x8F, 0x57, 0xAF, 255); // #8F57AF
    
    /**
     * Processes icon: adds background and colorizes while preserving original size and quality
     */
    public static void processIcon(String inputPath, String outputPath) {
        try {
            // Load original icon
            File inputFile = new File(inputPath);
            BufferedImage originalIcon = ImageIO.read(inputFile);
            
            if (originalIcon == null) {
                System.err.println("✗ Failed to load: " + inputPath);
                return;
            }
            
            int width = originalIcon.getWidth();
            int height = originalIcon.getHeight();
            
            System.out.println("Processing: " + new File(inputPath).getName() + " (" + width + "x" + height + ")");
            
            // Create new image with RGB (no alpha) - SAME SIZE as original
            BufferedImage newImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = newImage.createGraphics();
            
            // Enable maximum quality
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
            
            // Fill background with panel color
            g2d.setColor(BG_COLOR);
            g2d.fillRect(0, 0, width, height);
            
            // Colorize the original icon
            BufferedImage colorizedIcon = colorizeIcon(originalIcon, ICON_COLOR);
            
            // Draw colorized icon at original size (NO SCALING)
            g2d.drawImage(colorizedIcon, 0, 0, null);
            
            g2d.dispose();
            
            // Save result
            File outputFile = new File(outputPath);
            outputFile.getParentFile().mkdirs();
            ImageIO.write(newImage, "PNG", outputFile);
            
            System.out.println("✓ Saved: " + new File(outputPath).getName() + " (" + width + "x" + height + ")\n");
            
        } catch (IOException e) {
            System.err.println("✗ Error processing " + inputPath + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Colorizes an icon to the specified color (SOLID color, ignores original brightness)
     */
    private static BufferedImage colorizeIcon(BufferedImage original, Color targetColor) {
        BufferedImage colorized = new BufferedImage(
            original.getWidth(), 
            original.getHeight(), 
            BufferedImage.TYPE_INT_ARGB
        );
        
        for (int y = 0; y < original.getHeight(); y++) {
            for (int x = 0; x < original.getWidth(); x++) {
                int pixel = original.getRGB(x, y);
                
                // Extract alpha
                int alpha = (pixel >> 24) & 0xFF;
                
                // If pixel is not fully transparent, use target color
                if (alpha > 0) {
                    // Use SOLID target color (no brightness adjustment)
                    int newPixel = (alpha << 24) | (targetColor.getRed() << 16) | (targetColor.getGreen() << 8) | targetColor.getBlue();
                    colorized.setRGB(x, y, newPixel);
                } else {
                    // Keep transparent pixels transparent
                    colorized.setRGB(x, y, 0);
                }
            }
        }
        
        return colorized;
    }
    
    public static void main(String[] args) {
        String sourcePath = "C:/Users/doooo/Desktop/custom-mods/clnxconsole/temp_icons";
        String destPath = "C:/Users/doooo/Desktop/custom-mods/clnxconsole/src/main/resources/assets/whiterise_adminpanel/textures/icons";
        
        System.out.println("=== Processing icons WITHOUT changing size or quality ===");
        System.out.println("Background: #312541");
        System.out.println("Icon color: #8F57AF (Figma purple)\n");
        
        // Process all icons
        processIcon(sourcePath + "/fps.png", destPath + "/fps.png");
        processIcon(sourcePath + "/logo.png", destPath + "/logo.png");
        processIcon(sourcePath + "/nickname.png", destPath + "/player.png");
        processIcon(sourcePath + "/ping.png", destPath + "/ping.png");
        processIcon(sourcePath + "/punishments.png", destPath + "/punishment.png");
        processIcon(sourcePath + "/time.png", destPath + "/time.png");
        
        System.out.println("=== All icons processed successfully! ===");
        System.out.println("✓ Original size and quality preserved");
        System.out.println("✓ Background added: #312541");
        System.out.println("✓ Colorized to: #8F57AF");
    }
}
