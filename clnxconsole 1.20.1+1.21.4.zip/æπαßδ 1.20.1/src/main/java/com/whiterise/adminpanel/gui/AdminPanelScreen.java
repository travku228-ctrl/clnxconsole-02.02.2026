package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.AdminPanelClient;
import com.whiterise.adminpanel.data.PlayerData;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class AdminPanelScreen extends Screen {
    private static final int SIDEBAR_WIDTH = 200;
    private static final int HEADER_HEIGHT = 70;
    private static final int CARD_PADDING = 20; // Было 15
    
    // СОВРЕМЕННАЯ ЦВЕТОВАЯ ПАЛИТРА - ЗАМЕНЕНЫ НА ColorManager
    // Эти методы возвращают цвета из текущей темы
    private int COLOR_BG_DARKEST() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_DARK() { return ColorManager.getC2().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BG_HOVER() { return ColorManager.getC4().getRGB(); }
    private int COLOR_ACCENT() { return ColorManager.getC5().getRGB(); }
    private int COLOR_ACCENT_BLUE() { return ColorManager.getC5().getRGB(); }  // Используем C5
    private int COLOR_SUCCESS() { return ColorManager.getC6().getRGB(); }
    private int COLOR_WARNING() { return ColorManager.getC7().getRGB(); }
    private int COLOR_DANGER() { return ColorManager.getC8().getRGB(); }
    // ФИКСИРОВАННЫЕ цвета текста (всегда читаемые)
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;    // Белый всегда
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;  // Светло-серый всегда
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;      // Серый всегда
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    private static final int COLOR_SHADOW = 0x44000000;          // Тень всегда одинаковая
    private int COLOR_SIDEBAR_ACTIVE() { return ColorManager.getC4().getRGB(); }
    
    // Идентификаторы иконок
    private static final Identifier ICON_HOME = new Identifier("whiterise_adminpanel", "textures/icons/home.png");
    private static final Identifier ICON_PLAYERS = new Identifier("whiterise_adminpanel", "textures/icons/players.png");
    private static final Identifier ICON_PUNISHMENTS = new Identifier("whiterise_adminpanel", "textures/icons/punishments.png");
    private static final Identifier ICON_CHAT = new Identifier("whiterise_adminpanel", "textures/icons/chat.png");
    private static final Identifier ICON_ISSUED = new Identifier("whiterise_adminpanel", "textures/icons/issued.png");
    private static final Identifier ICON_SHIELD = new Identifier("whiterise_adminpanel", "textures/icons/shield.png");
    private static final Identifier ICON_CONSOLE = new Identifier("whiterise_adminpanel", "textures/icons/console.png");
    private static final Identifier ICON_INFO = new Identifier("whiterise_adminpanel", "textures/icons/info.png");
    private static final Identifier ICON_EYE = new Identifier("whiterise_adminpanel", "textures/icons/eye.png");
    private static final Identifier ICON_HAMMER_RED = new Identifier("whiterise_adminpanel", "textures/icons/hammer_red.png");
    private static final Identifier ICON_CHECK_GREEN = new Identifier("whiterise_adminpanel", "textures/icons/check_green.png");
    private static final Identifier ICON_CROSS_RED = new Identifier("whiterise_adminpanel", "textures/icons/cross_red.png");
    private static final Identifier ICON_ONLINE = new Identifier("whiterise_adminpanel", "textures/icons/online.png");
    private static final Identifier ICON_GUI_SETTINGS = new Identifier("whiterise_adminpanel", "textures/icons/gui_settings.png");
    private static final Identifier ICON_RULES = new Identifier("whiterise_adminpanel", "textures/icons/rules.png");
    private static final Identifier ICON_THEME = new Identifier("whiterise_adminpanel", "textures/icons/theme.png");
    
    private int scrollOffset = 0;
    private TextFieldWidget searchField;
    private String currentTab = "console"; // ИЗМЕНЕНО: консоль теперь главная страница
    private int hoveredButtonIndex = -1; // Для отслеживания наведения на кнопки
    private long lastClickTime = 0; // Для отслеживания двойного клика
    private String lastClickedPlayer = ""; // Последний кликнутый игрок
    
    // КОНТЕКСТНОЕ МЕНЮ ДЛЯ БЫСТРЫХ МУТОВ
    private QuickMuteMenu quickMuteMenu = null;
    
    // Отслеживание hover для кнопок верхней панели
    private boolean wasConsoleButtonHovered = false;
    private boolean wasPlayersButtonHovered = false;
    private boolean wasLogsButtonHovered = false;
    private boolean wasIssuedButtonHovered = false;
    private boolean wasAntiCheatButtonHovered = false;
    private boolean wasRulesButtonHovered = false;
    private boolean wasThemeButtonHovered = false; // НОВАЯ
    private boolean wasInterfaceButtonHovered = false;
    
    public AdminPanelScreen() {
        super(Text.literal("WhiteRise Admin Panel"));
    }
    
    @Override
    protected void init() {
        // Боковое меню - кнопки с группировкой
        int buttonY = HEADER_HEIGHT + 10;
        int buttonHeight = 40;
        int buttonSpacing = 5;
        int groupSpacing = 20;
        
        // Группа: ОСНОВНОЕ
        // ИЗМЕНЕНО: Консоль теперь первая (главная)
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Консоль"), button -> {
            currentTab = "console";
            scrollOffset = 0;
            this.clearAndInit();
        }));
        
        buttonY += buttonHeight + buttonSpacing;
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Игроки"), button -> {
            currentTab = "players";
            scrollOffset = 0;
            this.clearAndInit();
        }));
        
        // УДАЛЕНО: Кнопка "Наказания"
        
        // Разделитель группы
        buttonY += buttonHeight + groupSpacing;
        
        // Группа: МОНИТОРИНГ
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Логи чата"), button -> {
            currentTab = "logs";
            scrollOffset = 0;
            this.clearAndInit();
        }));
        
        buttonY += buttonHeight + buttonSpacing;
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Выданные"), button -> {
            currentTab = "issued";
            scrollOffset = 0;
            this.clearAndInit();
        }));
        
        buttonY += buttonHeight + buttonSpacing;
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Правила"), button -> {
            SoundManager.playClickSound();
            this.client.setScreen(new RulesScreen(this));
        }));
        
        buttonY += buttonHeight + buttonSpacing;
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Проверка"), button -> {
            currentTab = "anticheat";
            scrollOffset = 0;
            this.clearAndInit();
        }));
        
        // УДАЛЕНО: Консоль теперь первая кнопка
        
        // Разделитель группы
        buttonY += buttonHeight + groupSpacing;
        
        // Группа: СИСТЕМА
        this.addDrawableChild(new SilentButtonWidget(10, buttonY, SIDEBAR_WIDTH - 20, buttonHeight, Text.literal("Инфо"), button -> {
            currentTab = "info";
            scrollOffset = 0;
            this.clearAndInit();
        }));
        
        // Поле поиска только для игроков, логов и проверки (НЕ для выданных!)
        if (currentTab.equals("players") || currentTab.equals("logs") || currentTab.equals("anticheat")) {
            int searchWidth = 600; // Увеличено с 300 до 600
            int searchX = 30; // Было SIDEBAR_WIDTH + 30, теперь просто 30
            int searchY = HEADER_HEIGHT - 15; // Было HEADER_HEIGHT + 10, подняли на 25px выше
            
            // ИСПРАВЛЕНО: выравниваем текст по иконке + опускаем на 6px для центрирования
            int iconWidth = this.textRenderer.getWidth("🔍");
            searchField = new TextFieldWidget(this.textRenderer, searchX + 5 + iconWidth + 5, searchY + 10, searchWidth - (5 + iconWidth + 10), 20, Text.literal("Search"));
            searchField.setDrawsBackground(false); // Отключаем стандартный фон
            
            if (currentTab.equals("players")) {
                searchField.setPlaceholder(Text.literal(""));
            } else if (currentTab.equals("logs")) {
                searchField.setPlaceholder(Text.literal(""));
            } else if (currentTab.equals("anticheat")) {
                searchField.setPlaceholder(Text.literal(""));
            }
            
            this.addSelectableChild(searchField);
        } else if (currentTab.equals("issued")) {
            // Поле поиска для вкладки "Выданные"
            int searchX = 30;
            int searchY = HEADER_HEIGHT - 15;
            int searchWidth = 300;
            
            int iconWidth = this.textRenderer.getWidth("🔍");
            searchField = new TextFieldWidget(this.textRenderer, searchX + 5 + iconWidth + 5, searchY + 10, searchWidth - (5 + iconWidth + 10), 20, Text.literal("Search"));
            searchField.setDrawsBackground(false);
            searchField.setPlaceholder(Text.literal("Поиск по никнейму..."));
            searchField.setMaxLength(16);
            searchField.setChangedListener(text -> {
                scrollOffset = 0;
            });
            
            this.addSelectableChild(searchField);
        } else {
            searchField = null; // Убираем поисковик для других вкладок
        }
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Мягкий радиальный градиент фона (центр светлее, края темнее)
        // Создаем эффект "парящего" интерфейса
        renderRadialGradientBackground(context);
        
        // ФОНОВЫЕ ЧАСТИЦЫ (рендерим ПОСЛЕ фона, но ДО UI элементов)
        context.getMatrices().push();
        com.whiterise.adminpanel.background.ParticleSystem.getInstance().render(context, delta, mouseX, mouseY);
        context.getMatrices().pop();
        
        // ВЕРХНЯЯ ПАНЕЛЬ НАВИГАЦИИ (рендерим первой, чтобы была поверх фона)
        renderTopNavigationBar(context, mouseX, mouseY);
        
        // СЧЕТЧИК ОНЛАЙН ИГРОКОВ убран по запросу
        
        // БОКОВАЯ ПАНЕЛЬ УДАЛЕНА
        
        // Компактный текст внизу (1 строка)
        String username = this.client.getSession().getUsername();
        String infoText = "CLNXconsole | Logged: " + username + " | Role: Staff";
        context.drawText(this.textRenderer, infoText, 15, this.height - 25, COLOR_TEXT_MUTED, false);
        
        // Рендер поля поиска с новым стилем
        if (searchField != null) {
            renderStyledSearchField(context, mouseX, mouseY, delta);
        }
        
        // Рендер контента (РАСТЯНУТ НА ВСЮ ШИРИНУ)
        int contentX = 20; // Было SIDEBAR_WIDTH + 20
        int contentY = HEADER_HEIGHT + 20; // Было HEADER_HEIGHT + 80
        int contentWidth = this.width - 40; // Было this.width - SIDEBAR_WIDTH - 40
        
        switch (currentTab) {
            case "console":
                // ИЗМЕНЕНО: Сразу открываем ConsoleScreen без заглушки
                this.client.setScreen(new ConsoleScreen(this));
                break;
            case "home":
                renderHomeTab(context, contentX, contentY, contentWidth, mouseX, mouseY);
                break;
            case "players":
                renderPlayersTab(context, contentX, contentY, contentWidth, mouseX, mouseY);
                break;
            // УДАЛЕНО: case "punishments"
            case "logs":
                renderLogsTab(context, contentX, contentY, contentWidth, mouseX, mouseY);
                break;
            case "issued":
                renderIssuedTab(context, contentX, contentY, contentWidth);
                break;
            case "anticheat":
                renderAntiCheatTab(context, contentX, contentY, contentWidth, mouseX, mouseY);
                break;
            case "info":
                renderInfoTab(context, contentX, contentY, contentWidth);
                break;
        }
        
        super.render(context, mouseX, mouseY, delta);
        
        // РЕНДЕР КОНТЕКСТНОГО МЕНЮ (поверх всего)
        if (quickMuteMenu != null && quickMuteMenu.isOpen()) {
            quickMuteMenu.render(context, mouseX, mouseY);
        }
    }
    
    private void renderSidebarWithActiveState(DrawContext context) {
        int buttonY = HEADER_HEIGHT + 10;
        int buttonHeight = 40;
        int buttonSpacing = 5;
        int groupSpacing = 20;
        
        // ИЗМЕНЕНО: Консоль теперь первая, Наказания УДАЛЕНЫ
        String[] tabs = {"console", "players", "logs", "issued", "anticheat", "info"};
        Identifier[] icons = {ICON_CONSOLE, ICON_PLAYERS, ICON_CHAT, ICON_ISSUED, ICON_SHIELD, ICON_INFO};
        String[] labels = {"Консоль", "Игроки", "Логи чата", "Выданные", "Проверка", "Инфо"};
        
        // УЛУЧШЕННЫЙ SIDEBAR: без текстовых заголовков, с линиями разделения
        
        // Кнопка 0: Консоль (главная)
        if (currentTab.equals(tabs[0])) {
            context.fill(5, buttonY, 8, buttonY + buttonHeight, COLOR_ACCENT()); // Яркая полоска
            context.fill(10, buttonY, SIDEBAR_WIDTH - 10, buttonY + buttonHeight, COLOR_SIDEBAR_ACTIVE());
        }
        context.drawTexture(icons[0], 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, labels[0], 35, buttonY + (buttonHeight - 8) / 2, 
                        currentTab.equals(tabs[0]) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY, 
                        currentTab.equals(tabs[0])); // Bold если активна
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 1: Игроки
        if (currentTab.equals(tabs[1])) {
            context.fill(5, buttonY, 8, buttonY + buttonHeight, COLOR_ACCENT());
            context.fill(10, buttonY, SIDEBAR_WIDTH - 10, buttonY + buttonHeight, COLOR_SIDEBAR_ACTIVE());
        }
        context.drawTexture(icons[1], 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, labels[1], 35, buttonY + (buttonHeight - 8) / 2, 
                        currentTab.equals(tabs[1]) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY,
                        currentTab.equals(tabs[1]));
        buttonY += buttonHeight + groupSpacing;
        
        // УДАЛЕНО: Кнопка 2: Наказания
        
        // РАЗДЕЛИТЕЛЬ ГРУППЫ убран для чистого вида
        
        // Кнопка 2: Логи чата (было 3)
        if (currentTab.equals(tabs[2])) {
            context.fill(5, buttonY, 8, buttonY + buttonHeight, COLOR_ACCENT());
            context.fill(10, buttonY, SIDEBAR_WIDTH - 10, buttonY + buttonHeight, COLOR_SIDEBAR_ACTIVE());
        }
        context.drawTexture(icons[2], 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, labels[2], 35, buttonY + (buttonHeight - 8) / 2, 
                        currentTab.equals(tabs[2]) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY,
                        currentTab.equals(tabs[2]));
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 3: Выданные (было 4)
        if (currentTab.equals(tabs[3])) {
            context.fill(5, buttonY, 8, buttonY + buttonHeight, COLOR_ACCENT());
            context.fill(10, buttonY, SIDEBAR_WIDTH - 10, buttonY + buttonHeight, COLOR_SIDEBAR_ACTIVE());
        }
        context.drawTexture(icons[3], 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, labels[3], 35, buttonY + (buttonHeight - 8) / 2, 
                        currentTab.equals(tabs[3]) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY,
                        currentTab.equals(tabs[3]));
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка: Правила (отдельный экран)
        context.drawTexture(ICON_RULES, 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, "Правила", 35, buttonY + (buttonHeight - 8) / 2, COLOR_TEXT_SECONDARY, false);
        buttonY += buttonHeight + buttonSpacing;
        
        // Кнопка 4: Проверка (было 5)
        if (currentTab.equals(tabs[4])) {
            context.fill(5, buttonY, 8, buttonY + buttonHeight, COLOR_ACCENT());
            context.fill(10, buttonY, SIDEBAR_WIDTH - 10, buttonY + buttonHeight, COLOR_SIDEBAR_ACTIVE());
        }
        context.drawTexture(icons[4], 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, labels[4], 35, buttonY + (buttonHeight - 8) / 2, 
                        currentTab.equals(tabs[4]) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY,
                        currentTab.equals(tabs[4]));
        buttonY += buttonHeight + groupSpacing;
        
        // УДАЛЕНО: Кнопка Консоль (теперь первая)
        
        // РАЗДЕЛИТЕЛЬ ГРУППЫ убран для чистого вида
        
        // Кнопка 5: Инфо (было 6)
        if (currentTab.equals(tabs[5])) {
            context.fill(5, buttonY, 8, buttonY + buttonHeight, COLOR_ACCENT());
            context.fill(10, buttonY, SIDEBAR_WIDTH - 10, buttonY + buttonHeight, COLOR_SIDEBAR_ACTIVE());
        }
        context.drawTexture(icons[5], 15, buttonY + (buttonHeight - 16) / 2, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, labels[5], 35, buttonY + (buttonHeight - 8) / 2, 
                        currentTab.equals(tabs[5]) ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY,
                        currentTab.equals(tabs[5]));
    }
    
    private void renderHomeTab(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        // Заголовок секции (без CAPS)
        context.drawText(this.textRenderer, "Главная", x, y - 30, COLOR_TEXT_SECONDARY, false);
        
        // Карточки в сетке 2x2
        int cardWidth = (width - CARD_PADDING) / 2;
        int cardHeight = 120;
        
        // Проверка hover для каждой карточки
        boolean hover1 = mouseX >= x && mouseX <= x + cardWidth && mouseY >= y && mouseY <= y + cardHeight;
        boolean hover2 = mouseX >= x + cardWidth + CARD_PADDING && mouseX <= x + cardWidth * 2 + CARD_PADDING && 
                        mouseY >= y && mouseY <= y + cardHeight;
        boolean hover3 = mouseX >= x && mouseX <= x + cardWidth && 
                        mouseY >= y + cardHeight + CARD_PADDING && mouseY <= y + cardHeight * 2 + CARD_PADDING;
        boolean hover4 = mouseX >= x + cardWidth + CARD_PADDING && mouseX <= x + cardWidth * 2 + CARD_PADDING && 
                        mouseY >= y + cardHeight + CARD_PADDING && mouseY <= y + cardHeight * 2 + CARD_PADDING;
        
        // Карточка 1: Активные игроки (синий)
        renderCard(context, x, y, cardWidth, cardHeight, hover1 ? COLOR_BG_HOVER() : COLOR_BG_CARD(), ICON_PLAYERS, "Активные игроки", 
                   "Список игроков онлайн на сервере", hover1 ? 0xFF6BA3FF : COLOR_ACCENT_BLUE(), "Открыть", hover1, ICON_EYE);
        
        // Карточка 2: Наказания (желтый)
        renderCard(context, x + cardWidth + CARD_PADDING, y, cardWidth, cardHeight, hover2 ? COLOR_BG_HOVER() : COLOR_BG_CARD(), ICON_HAMMER_RED, "Выдать наказание",
                   "Мут, бан или разбан игроков", hover2 ? 0xFFFFB84D : COLOR_WARNING(), "Перейти", hover2, ICON_HAMMER_RED);
        
        // Карточка 3: Логи чата (зеленый)
        renderCard(context, x, y + cardHeight + CARD_PADDING, cardWidth, cardHeight, hover3 ? COLOR_BG_HOVER() : COLOR_BG_CARD(), ICON_CHAT, "Последние сообщения",
                   "Мониторинг чата за последние 6 часов", hover3 ? 0xFF3DD68C : COLOR_SUCCESS(), "Открыть", hover3, ICON_EYE);
        
        // Карточка 4: История наказаний (красный)
        renderCard(context, x + cardWidth + CARD_PADDING, y + cardHeight + CARD_PADDING, cardWidth, cardHeight, 
                   hover4 ? COLOR_BG_HOVER() : COLOR_BG_CARD(), ICON_ISSUED, "Все выданные наказания", "Просмотр истории наказаний", hover4 ? 0xFFFF6B6B : COLOR_DANGER(), "Открыть", hover4, ICON_EYE);
    }
    
    private void renderCard(DrawContext context, int x, int y, int width, int height, int bgColor, 
                           Identifier icon, String title, String description, int buttonColor, String buttonText, boolean isHovered, Identifier buttonIcon) {
        // УЛУЧШЕННАЯ МНОГОСЛОЙНАЯ ТЕНЬ с использованием нового метода
        com.whiterise.adminpanel.util.RenderUtils.drawLayeredShadow(context, x, y, width, height, 10, 3, isHovered);
        
        // Фон карточки с легким градиентом для глубины
        int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, x, y, width, height, 10, bgColor, bgColorDarker);
        
        // Скругленная граница с улучшенным эффектом
        int borderColor = isHovered ? 0xFF3a4451 : COLOR_BORDER();
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, x, y, width, height, 10, borderColor);
        
        // Свечение при hover
        if (isHovered) {
            int glowColor = (buttonColor & 0x00FFFFFF) | 0x22000000;
            com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, x, y, width, height, 10, glowColor, 2);
        }
        
        // БОЛЬШАЯ иконка карточки (64x64) - в левой части, по центру по вертикали
        int iconSize = 64;
        int iconX = x + 20;
        int iconY = y + (height - iconSize) / 2;
        
        // Фон под иконкой с легким свечением
        int bgPadding = 8;
        context.fill(iconX - bgPadding, iconY - bgPadding, 
                    iconX + iconSize + bgPadding, iconY + iconSize + bgPadding, 0x22000000);
        
        // Рисуем иконку
        context.drawTexture(icon, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Заголовок (справа от иконки, вверху)
        int textStartX = iconX + iconSize + 20;
        context.drawText(this.textRenderer, title, textStartX, y + 20, COLOR_TEXT_PRIMARY, true);
        
        // Описание (справа от иконки, под заголовком)
        String[] words = description.split(" ");
        StringBuilder line = new StringBuilder();
        int lineY = y + 40;
        int maxTextWidth = width - (textStartX - x) - 20;
        
        for (String word : words) {
            if (this.textRenderer.getWidth(line + word) > maxTextWidth) {
                context.drawText(this.textRenderer, line.toString().trim(), textStartX, lineY, COLOR_TEXT_MUTED, false);
                line = new StringBuilder();
                lineY += 12;
            }
            line.append(word).append(" ");
        }
        if (line.length() > 0) {
            context.drawText(this.textRenderer, line.toString().trim(), textStartX, lineY, COLOR_TEXT_MUTED, false);
        }
        
        // Кнопка с улучшенной анимацией и градиентом
        int buttonTextWidth = this.textRenderer.getWidth(buttonText);
        int buttonWidth = Math.max(110, buttonTextWidth + 35);
        int buttonHeight = 25;
        int buttonX = x + width - buttonWidth - 15;
        int buttonY = y + height - buttonHeight - 15;
        
        // Hover эффект: поднимаем кнопку и добавляем свечение
        if (isHovered) {
            buttonY -= 2;
            // Улучшенная тень под кнопкой
            com.whiterise.adminpanel.util.RenderUtils.drawLayeredShadow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, 2, true);
            // Свечение вокруг кнопки
            com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonColor, 3);
        }
        
        // Фон кнопки с градиентом (ярче при hover)
        int finalButtonColor = isHovered ? adjustBrightness(buttonColor, 1.15f) : buttonColor;
        int buttonColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(finalButtonColor, 0.85f);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, finalButtonColor, buttonColorDarker);
        
        // Граница кнопки
        int buttonBorderColor = isHovered ? com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(finalButtonColor, 1.3f) : COLOR_BORDER();
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonBorderColor);
        
        // Иконка кнопки
        int buttonIconY = buttonY + (buttonHeight - 16) / 2;
        context.drawTexture(buttonIcon, buttonX + 10, buttonIconY, 0, 0, 16, 16, 16, 16);
        
        // Текст кнопки
        int textY = buttonY + (buttonHeight - 8) / 2;
        context.drawText(this.textRenderer, buttonText, buttonX + 30, textY, COLOR_TEXT_PRIMARY, false);
    }
    
    /**
     * Изменяет яркость цвета (Phase 3)
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    
    /**
     * Рендерит консоль (главная страница)
     */
    private void renderConsoleTab(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        // Заголовок
        context.drawText(this.textRenderer, "Консоль наказаний", x, y - 30, COLOR_TEXT_PRIMARY, true);
        context.drawText(this.textRenderer, "Удаленное управление наказаниями", x, y - 10, COLOR_TEXT_SECONDARY, false);
        
        // Простое сообщение: используйте отдельный экран консоли
        int centerX = x + width / 2;
        int centerY = y + 100;
        
        String msg1 = "Консоль наказаний доступна через отдельный экран";
        String msg2 = "Нажмите кнопку 'Консоль' в боковом меню";
        String msg3 = "или используйте горячую клавишу";
        
        int msg1Width = this.textRenderer.getWidth(msg1);
        int msg2Width = this.textRenderer.getWidth(msg2);
        int msg3Width = this.textRenderer.getWidth(msg3);
        
        context.drawText(this.textRenderer, msg1, centerX - msg1Width / 2, centerY, COLOR_TEXT_PRIMARY, false);
        context.drawText(this.textRenderer, msg2, centerX - msg2Width / 2, centerY + 20, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, msg3, centerX - msg3Width / 2, centerY + 40, COLOR_TEXT_MUTED, false);
        
        // Кнопка "Открыть консоль"
        int buttonWidth = 200;
        int buttonHeight = 40;
        int buttonX = centerX - buttonWidth / 2;
        int buttonY = centerY + 80;
        
        boolean isHovered = mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                           mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        
        int buttonColor = isHovered ? adjustBrightness(COLOR_ACCENT(), 1.15f) : COLOR_ACCENT();
        context.fill(buttonX, buttonY, buttonX + buttonWidth, buttonY + buttonHeight, buttonColor);
        
        String buttonText = "Открыть консоль";
        int textWidth = this.textRenderer.getWidth(buttonText);
        context.drawText(this.textRenderer, buttonText, buttonX + (buttonWidth - textWidth) / 2, 
                        buttonY + (buttonHeight - 8) / 2, COLOR_TEXT_PRIMARY, true);
    }
    
    private void renderPlayersTab(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        // Заголовок удален по запросу пользователя
        
        List<PlayerData> players;
        String search = searchField != null ? searchField.getText() : "";
        
        if (search.isEmpty()) {
            players = AdminPanelClient.getPlayerManager().getPlayersSortedByActivity();
        } else {
            players = AdminPanelClient.getPlayerManager().searchPlayers(search);
        }
        
        // Компактные блоки - 3 в строке
        int cardWidth = (width - CARD_PADDING * 2) / 3;
        int cardHeight = 80;
        int index = 0;
        int row = 0;
        int col = 0;
        
        for (PlayerData player : players) {
            int cardX = x + col * (cardWidth + CARD_PADDING);
            int cardY = y + row * (cardHeight + CARD_PADDING) - scrollOffset;
            
            if (cardY >= y - cardHeight && cardY < this.height - 20) {
                // Проверка hover
                boolean isHovered = mouseX >= cardX && mouseX <= cardX + cardWidth && 
                                   mouseY >= cardY && mouseY <= cardY + cardHeight;
                
                // УЛУЧШЕННАЯ ТЕНЬ (Phase 3)
                if (isHovered) {
                    context.fill(cardX + 3, cardY + 3, cardX + cardWidth + 3, cardY + cardHeight + 3, 0x33000000);
                    context.fill(cardX + 2, cardY + 2, cardX + cardWidth + 2, cardY + cardHeight + 2, 0x55000000);
                } else {
                    context.fill(cardX + 2, cardY + 2, cardX + cardWidth + 2, cardY + cardHeight + 2, 0x44000000);
                }
                
                // Фон карточки с hover эффектом (чуть светлее) - СКРУГЛЕННЫЙ
                int bgColor = isHovered ? 
                    com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BG_CARD(), 1.15f) : 
                    COLOR_BG_CARD();
                RenderUtils.fillRounded(context, cardX, cardY, cardWidth, cardHeight, 10, bgColor);
                
                // Границы (чуть светлее при hover) - СКРУГЛЕННЫЕ
                int borderColor = isHovered ? 
                    com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BORDER(), 1.3f) : 
                    COLOR_BORDER();
                RenderUtils.drawRoundedBorder(context, cardX, cardY, cardWidth, cardHeight, 10, borderColor);
                
                // Имя игрока по центру
                int nameWidth = this.textRenderer.getWidth(player.getUsername());
                context.drawText(this.textRenderer, player.getUsername(), 
                    cardX + (cardWidth - nameWidth) / 2, cardY + 20, COLOR_TEXT_PRIMARY, false);
                
                // Кнопка Выбрать с улучшенной анимацией и градиентом
                int buttonWidth = 100;
                int buttonHeight = 25;
                int buttonX = cardX + (cardWidth - buttonWidth) / 2;
                int buttonY = cardY + cardHeight - buttonHeight - 10;
                
                // Hover эффект: поднимаем кнопку и добавляем тень
                if (isHovered) {
                    buttonY -= 2;
                    // Улучшенная тень под кнопкой
                    com.whiterise.adminpanel.util.RenderUtils.drawLayeredShadow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, 2, true);
                    // Свечение
                    com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, COLOR_ACCENT_BLUE(), 2);
                }
                
                int buttonColor = isHovered ? adjustBrightness(COLOR_ACCENT_BLUE(), 1.15f) : COLOR_ACCENT_BLUE();
                int buttonColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonColor, 0.85f);
                com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonColor, buttonColorDarker);
                
                // Граница кнопки
                int buttonBorderColor = isHovered ? com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonColor, 1.3f) : COLOR_BORDER();
                com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonBorderColor);
                
                String btnText = "Выбрать";
                int btnTextWidth = this.textRenderer.getWidth(btnText);
                context.drawText(this.textRenderer, btnText, 
                    buttonX + (buttonWidth - btnTextWidth) / 2, buttonY + 8, COLOR_TEXT_PRIMARY, false);
            }
            
            col++;
            if (col >= 3) {
                col = 0;
                row++;
            }
            index++;
        }
        
        // Рендер скроллбара
        int totalRows = (int) Math.ceil(players.size() / 3.0);
        int totalHeight = totalRows * (cardHeight + CARD_PADDING);
        int visibleHeight = this.height - y - 20;
        int maxScroll = Math.max(0, totalHeight - visibleHeight);
        renderScrollbar(context, x, y, width, visibleHeight, maxScroll);
    }
    
    private void renderPunishmentsCard(DrawContext context, int x, int y, int width) {
        context.drawText(this.textRenderer, "Наказания", x, y - 30, COLOR_TEXT_SECONDARY, false);
        context.drawText(this.textRenderer, "Выберите игрока из вкладки Игроки для выдачи наказания", x, y - 15, COLOR_TEXT_MUTED, false);
    }
    
    private void renderLogsTab(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        // Заголовок УДАЛЕН (было: "Логи чата")
        
        // Получаем логи из менеджера
        String search = searchField != null ? searchField.getText() : "";
        var logs = search.isEmpty() ? 
            AdminPanelClient.getChatLogManager().getAllLogs() : 
            AdminPanelClient.getChatLogManager().searchLogs(search);
        
        if (logs.isEmpty()) {
            String emptyText = search.isEmpty() ? "Чат пуст" : "Ничего не найдено";
            context.drawText(this.textRenderer, emptyText, x + 5, y + 10, COLOR_TEXT_MUTED, false);
            return;
        }
        
        // Рендерим логи (новые сверху)
        int lineY = y - scrollOffset;
        int lineHeight = 12;
        int maxWidth = width - 20;
        
        for (var entry : logs) {
            // Вычисляем высоту с учетом переноса
            int entryHeight = calculateEntryHeight(entry, maxWidth);
            
            // Проверяем видимость
            if (lineY + entryHeight >= y && lineY < this.height - 20) {
                // Hover подсветка
                boolean isHovered = mouseX >= x && mouseX <= x + width && 
                                   mouseY >= lineY && mouseY <= lineY + entryHeight;
                
                if (isHovered) {
                    context.fill(x, lineY, x + width, lineY + entryHeight, 0x22FFFFFF);
                }
                
                // Рендерим entry
                renderChatEntry(context, x + 10, lineY, maxWidth, entry);
            }
            
            lineY += entryHeight + 2; // 2px отступ между сообщениями
        }
        
        // Скроллбар
        int totalHeight = 0;
        for (var entry : logs) {
            totalHeight += calculateEntryHeight(entry, maxWidth) + 2;
        }
        int visibleHeight = this.height - y - 20;
        int maxScroll = Math.max(0, totalHeight - visibleHeight);
        renderScrollbar(context, x, y, width, visibleHeight, maxScroll);
    }
    
    /**
     * Вычисляет высоту entry с учетом переноса
     */
    private int calculateEntryHeight(com.whiterise.adminpanel.data.ChatLogEntry entry, int maxWidth) {
        String fullText = entry.getTimeString() + " " + entry.getRawText();
        
        if (this.textRenderer.getWidth(fullText) <= maxWidth) {
            return 10; // Одна строка
        }
        
        // Считаем количество строк при переносе
        String[] words = fullText.split(" ");
        int lines = 1;
        int currentWidth = 0;
        
        for (String word : words) {
            int wordWidth = this.textRenderer.getWidth(word + " ");
            if (currentWidth + wordWidth > maxWidth) {
                lines++;
                currentWidth = wordWidth;
            } else {
                currentWidth += wordWidth;
            }
        }
        
        return lines * 10;
    }
    
    /**
     * Рендерит одну запись лога
     * Формат: [HH:mm:ss] rawText [CAPS]
     */
    private void renderChatEntry(DrawContext context, int x, int y, int maxWidth, 
                                 com.whiterise.adminpanel.data.ChatLogEntry entry) {
        int currentX = x;
        int currentY = y;
        
        // Проверяем, является ли это сообщением от WhiteCheat
        String rawText = entry.getRawText();
        boolean isWhiteCheatMessage = rawText.contains("[ᴡʜɪᴛᴇᴄʜᴇᴀᴛ]");
        
        // Время (серый или красный)
        String timeStr = entry.getTimeString();
        int timeColor = isWhiteCheatMessage ? COLOR_DANGER() : 0xFF666666;
        context.drawText(this.textRenderer, timeStr, currentX, currentY, timeColor, false);
        currentX += this.textRenderer.getWidth(timeStr) + 5;
        
        // Текст сообщения (белый или красный)
        int textColor = isWhiteCheatMessage ? COLOR_DANGER() : 0xFFFFFFFF;
        int availableWidth = maxWidth - (currentX - x);
        
        // CAPS метка (если есть)
        if (entry.isCaps()) {
            // Рендерим текст с переносом
            renderWrappedTextWithCaps(context, rawText, currentX, currentY, availableWidth, textColor);
        } else {
            // Обычный рендер с переносом
            renderWrappedText(context, rawText, currentX, currentY, availableWidth, textColor);
        }
    }
    
    /**
     * Рендерит текст с CAPS меткой
     */
    private void renderWrappedTextWithCaps(DrawContext context, String text, int x, int y, int maxWidth, int textColor) {
        // Сначала рендерим текст
        renderWrappedText(context, text, x, y, maxWidth - 50, textColor);
        
        // Потом добавляем метку [CAPS] справа (всегда желтая)
        String capsLabel = "[CAPS]";
        int capsX = x + maxWidth - this.textRenderer.getWidth(capsLabel) - 5;
        context.drawText(this.textRenderer, capsLabel, capsX, y, COLOR_WARNING(), true);
    }
    
    
    /**
     * Рендерит текст с автоматическим переносом
     */
    private void renderWrappedText(DrawContext context, String text, int x, int y, int maxWidth, int color) {
        if (this.textRenderer.getWidth(text) <= maxWidth) {
            context.drawText(this.textRenderer, text, x, y, color, false);
            return;
        }
        
        String[] words = text.split(" ");
        int currentX = x;
        int currentY = y;
        StringBuilder currentLine = new StringBuilder();
        
        for (String word : words) {
            String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
            int testWidth = this.textRenderer.getWidth(testLine);
            
            if (testWidth > maxWidth && currentLine.length() > 0) {
                // Рендерим текущую строку
                context.drawText(this.textRenderer, currentLine.toString(), currentX, currentY, color, false);
                currentY += 10;
                currentX = x;
                currentLine = new StringBuilder(word);
            } else {
                if (currentLine.length() > 0) currentLine.append(" ");
                currentLine.append(word);
            }
        }
        
        // Рендерим последнюю строку
        if (currentLine.length() > 0) {
            context.drawText(this.textRenderer, currentLine.toString(), currentX, currentY, color, false);
        }
    }
    
    
    private void renderIssuedTab(DrawContext context, int x, int y, int width) {
        // Заголовок удален по запросу
        
        // Фильтруем историю - убираем размуты и разбаны
        var allHistory = AdminPanelClient.getPunishmentManager().getPunishmentHistory();
        var history = allHistory.stream()
            .filter(record -> record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE 
                           && record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN)
            .collect(java.util.stream.Collectors.toList());
        
        // Фильтрация по поиску
        String search = searchField != null ? searchField.getText().toLowerCase() : "";
        if (!search.isEmpty()) {
            history = history.stream()
                .filter(record -> record.getUsername().toLowerCase().contains(search))
                .collect(java.util.stream.Collectors.toList());
        }
        
        int itemY = y - scrollOffset;
        int index = 0;
        
        if (history.isEmpty()) {
            // Пустое состояние с инструкцией
            String emptyText = search.isEmpty() ? "История наказаний пуста" : "Игрок не найден";
            int textWidth = this.textRenderer.getWidth(emptyText);
            context.drawText(this.textRenderer, emptyText, x + (width - textWidth) / 2, y + 50, COLOR_TEXT_MUTED, false);
            
            if (search.isEmpty()) {
                String hintText = "Наказания будут отображаться здесь после их выдачи";
                int hintWidth = this.textRenderer.getWidth(hintText);
                context.drawText(this.textRenderer, hintText, x + (width - hintWidth) / 2, y + 70, 0xFF666666, false);
            }
            return;
        }
        
        for (var record : history) {
            if (itemY >= y && itemY < this.height - 20) {
                int itemHeight = 28; // Уменьшено с 30 до 28
                int bgColor = 0xFF1e2936;
                context.fill(x, itemY, x + width, itemY + itemHeight, bgColor);
                context.fill(x, itemY, x + width, itemY + 1, 0xFF2a3441);
                
                // Имя игрока (ГОЛУБОЙ цвет, увеличенный шрифт)
                int nameX = x + 10; // Уменьшено с 15 до 10
                int nameY = itemY + (itemHeight - 8) / 2;
                context.drawText(this.textRenderer, record.getUsername(), nameX, nameY, COLOR_ACCENT(), true); // Голубой + жирный
                
                // Тип наказания (без CAPS, увеличенный шрифт) - динамическая позиция
                String type = record.getType().getDisplayName();
                int typeX = nameX + this.textRenderer.getWidth(record.getUsername()) + 15; // Динамически после никнейма
                context.drawText(this.textRenderer, type, typeX, nameY, COLOR_WARNING(), true);
                
                // Время (КРАСНЫЙ цвет, увеличенный шрифт) - динамическая позиция
                int timeX = typeX + this.textRenderer.getWidth(type) + 15; // Динамически после типа
                context.drawText(this.textRenderer, record.getDuration(), timeX, nameY, COLOR_DANGER(), true); // Красный + жирный
                
                // Причина (увеличенный шрифт) - динамическая позиция
                int reasonX = timeX + this.textRenderer.getWidth(record.getDuration()) + 15; // Динамически после времени
                String reason = record.getReason();
                // Обрезаем если слишком длинная
                int maxReasonWidth = width - reasonX - 10; // Уменьшено с 15 до 10
                if (this.textRenderer.getWidth(reason) > maxReasonWidth) {
                    reason = this.textRenderer.trimToWidth(reason, maxReasonWidth);
                }
                context.drawText(this.textRenderer, reason, reasonX, nameY, 0xFF8899aa, false);
            }
            itemY += 30; // Уменьшено с 35 до 30
            index++;
        }
    }
    
    private void renderAntiCheatTab(DrawContext context, int x, int y, int width, int mouseX, int mouseY) {
        // Заголовок удален по запросу пользователя
        
        // ПРОВЕРКА АКТИВНОЙ СЕССИИ - если есть, автоматически открываем экран проверки
        if (com.whiterise.adminpanel.manager.AntiCheatSessionManager.hasActiveSession()) {
            var session = com.whiterise.adminpanel.manager.AntiCheatSessionManager.getActiveSession();
            this.client.setScreen(new AntiCheatScreen(session.getPlayerName()));
            return;
        }
        
        var allPlayers = AdminPanelClient.getPlayerManager().getPlayersSortedAlphabetically();
        
        // Фильтрация по поиску
        String search = searchField != null ? searchField.getText().toLowerCase() : "";
        var players = allPlayers;
        
        if (!search.isEmpty()) {
            players = allPlayers.stream()
                .filter(p -> p.getUsername().toLowerCase().contains(search))
                .collect(java.util.stream.Collectors.toList());
        }
        
        if (players.isEmpty()) {
            String emptyText = search.isEmpty() ? "Нет игроков онлайн" : "Игрок не найден";
            int textWidth = this.textRenderer.getWidth(emptyText);
            context.drawText(this.textRenderer, emptyText, x + (width - textWidth) / 2, y + 50, 0xFF666666, false);
            return;
        }
        
        // Компактные карточки - 2-3 в строке
        int cardWidth = (width - CARD_PADDING * 2) / 3;
        int cardHeight = 90;
        int row = 0;
        int col = 0;
        
        for (var player : players) {
            int cardX = x + col * (cardWidth + CARD_PADDING);
            int cardY = y + row * (cardHeight + CARD_PADDING) - scrollOffset;
            
            if (cardY >= y - cardHeight && cardY < this.height - 20) {
                // Проверка hover
                boolean isHovered = mouseX >= cardX && mouseX <= cardX + cardWidth && 
                                   mouseY >= cardY && mouseY <= cardY + cardHeight;
                
                // УЛУЧШЕННАЯ МНОГОСЛОЙНАЯ ТЕНЬ
                com.whiterise.adminpanel.util.RenderUtils.drawLayeredShadow(context, cardX, cardY, cardWidth, cardHeight, 10, 2, isHovered);
                
                // Фон карточки с градиентом и hover эффектом (чуть светлее)
                int bgColor = isHovered ? 
                    com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BG_CARD(), 1.15f) : 
                    COLOR_BG_CARD();
                int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
                com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, cardX, cardY, cardWidth, cardHeight, 10, bgColor, bgColorDarker);
                
                // Границы с улучшенным эффектом (чуть светлее при hover)
                int borderColor = isHovered ? 
                    com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BORDER(), 1.3f) : 
                    COLOR_BORDER();
                com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, cardX, cardY, cardWidth, cardHeight, 10, borderColor);
                
                // Убрано свечение при hover (было слишком ярко)
                
                // Иконка игрока (выровнена с никнеймом)
                int iconSize = 20; // Увеличено с 16 до 20
                context.drawTexture(ICON_PLAYERS, cardX + 15, cardY + 13, 0, 0, iconSize, iconSize, iconSize, iconSize);
                
                // Имя игрока
                String username = player.getUsername();
                if (this.textRenderer.getWidth(username) > cardWidth - 50) {
                    username = this.textRenderer.trimToWidth(username, cardWidth - 50);
                }
                context.drawText(this.textRenderer, username, cardX + 40 + (iconSize - 16), cardY + 15, 0xFFFFFFFF, true);
                
                // Статус
                context.drawText(this.textRenderer, "ВЫЗВАТЬ НА ПРОВЕРКУ", cardX + 15, cardY + 35, 0xFF8899aa, false);
                
                // Кнопка с улучшенной анимацией - СКРУГЛЕННАЯ
                int buttonWidth = cardWidth - 30;
                int buttonHeight = 30; // Увеличена высота для лучшего вида
                int buttonX = cardX + 15;
                int buttonY = cardY + cardHeight - buttonHeight - 10;
                
                // Hover эффект с улучшенными визуальными эффектами
                if (isHovered) {
                    buttonY -= 2;
                    // Улучшенная тень под кнопкой
                    com.whiterise.adminpanel.util.RenderUtils.drawLayeredShadow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, 2, true);
                    // Свечение
                    com.whiterise.adminpanel.util.RenderUtils.drawGlow(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, COLOR_SUCCESS(), 2);
                }
                
                int buttonColor = isHovered ? adjustBrightness(COLOR_SUCCESS(), 1.15f) : COLOR_SUCCESS();
                int buttonColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonColor, 0.85f);
                com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonColor, buttonColorDarker);
                
                // Граница кнопки
                int buttonBorderColor = isHovered ? com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(buttonColor, 1.3f) : COLOR_BORDER();
                com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, buttonX, buttonY, buttonWidth, buttonHeight, 8, buttonBorderColor);
                
                // Иконка и текст кнопки
                String btnText = "▶ Начать";
                int btnTextWidth = this.textRenderer.getWidth(btnText);
                context.drawText(this.textRenderer, btnText, 
                    buttonX + (buttonWidth - btnTextWidth) / 2, buttonY + (buttonHeight - 8) / 2, 0xFFFFFFFF, true);
            }
            
            col++;
            if (col >= 3) {
                col = 0;
                row++;
            }
        }
        
        // Рендер скроллбара
        int totalRows = (int) Math.ceil(players.size() / 3.0);
        int totalHeight = totalRows * (cardHeight + CARD_PADDING);
        int visibleHeight = this.height - y - 20;
        int maxScroll = Math.max(0, totalHeight - visibleHeight);
        renderScrollbar(context, x, y, width, visibleHeight, maxScroll);
    }
    
    private void renderInfoTab(DrawContext context, int x, int y, int width) {
        context.drawText(this.textRenderer, "Информация", x, y - 30, COLOR_TEXT_SECONDARY, false);
        
        int cardHeight = 300;
        context.fill(x, y, x + width, y + cardHeight, 0xFF1e2936);
        context.fill(x, y, x + width, y + 1, 0xFF2a3441);
        
        int textY = y + 30;
        int lineHeight = 18;
        
        // Заголовок по центру
        String title = "WhiteRise Admin Panel";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, x + (width - titleWidth) / 2, textY, 0xFFFFFF, true);
        textY += lineHeight * 2;
        
        // Описание
        String desc1 = "WhiteRise Admin Panel — клиентский мод для Minecraft 1.20.1,";
        String desc2 = "предназначенный для удобной и быстрой работы администрации сервера.";
        String desc3 = "Мод предоставляет современную админ-панель, позволяя выполнять";
        String desc4 = "большинство модераторских действий в 1–2 клика, без ручного ввода команд в чат.";
        
        context.drawText(this.textRenderer, desc1, x + 20, textY, 0xFF8899aa, false);
        textY += lineHeight;
        context.drawText(this.textRenderer, desc2, x + 20, textY, 0xFF8899aa, false);
        textY += lineHeight;
        context.drawText(this.textRenderer, desc3, x + 20, textY, 0xFF8899aa, false);
        textY += lineHeight;
        context.drawText(this.textRenderer, desc4, x + 20, textY, 0xFF8899aa, false);
        textY += lineHeight * 2;
        
        // Автор
        context.drawTexture(ICON_ISSUED, x + 20, textY - 1, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, "Автор", x + 40, textY, 0xFFaaaaaa, true);
        textY += lineHeight;
        context.drawText(this.textRenderer, "Создано: clownuxk", x + 30, textY, 0xFF8899aa, false);
        textY += lineHeight;
        context.drawText(this.textRenderer, "Discord: ustonki", x + 30, textY, 0xFF8899aa, false);
        textY += lineHeight;
        context.drawText(this.textRenderer, "Для сообщений о багах или предложений пишите в ЛС Discord.", x + 30, textY, 0xFF8899aa, false);
        textY += lineHeight * 2;
        
        // Лицензия
        context.drawTexture(ICON_SHIELD, x + 20, textY - 1, 0, 0, 16, 16, 16, 16);
        context.drawText(this.textRenderer, "Лицензия", x + 40, textY, 0xFFaaaaaa, true);
        textY += lineHeight;
        context.drawText(this.textRenderer, "Проект предназначен для использования в рамках проекта WhiteRise.", x + 30, textY, 0xFF8899aa, false);
        textY += lineHeight;
        context.drawText(this.textRenderer, "Распространение и модификация — по согласованию с автором.", x + 30, textY, 0xFF8899aa, false);
    }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        // Вычисляем максимальный скролл в зависимости от текущей вкладки
        int maxScroll = getMaxScrollForCurrentTab();
        
        scrollOffset -= (int) (amount * 20);
        
        // Ограничиваем скролл
        if (scrollOffset < 0) scrollOffset = 0;
        if (scrollOffset > maxScroll) scrollOffset = maxScroll;
        
        return true;
    }
    
    /**
     * Вычисляет максимальный скролл для текущей вкладки
     */
    private int getMaxScrollForCurrentTab() {
        int contentY = HEADER_HEIGHT + 80;
        int visibleHeight = this.height - contentY - 20;
        
        switch (currentTab) {
            case "players": {
                // ИСПРАВЛЕНО: Используем ОТФИЛЬТРОВАННЫЙ список
                var allPlayers = AdminPanelClient.getPlayerManager().getPlayersSortedByActivity();
                String search = searchField != null ? searchField.getText() : "";
                var players = allPlayers;
                
                if (!search.isEmpty()) {
                    players = allPlayers.stream()
                        .filter(p -> p.getUsername().toLowerCase().contains(search.toLowerCase()))
                        .collect(java.util.stream.Collectors.toList());
                }
                
                int cardHeight = 80;
                int totalRows = (int) Math.ceil(players.size() / 3.0);
                int totalHeight = totalRows * (cardHeight + CARD_PADDING);
                return Math.max(0, totalHeight - visibleHeight);
            }
            case "logs": {
                // Используем новый ChatLogManager
                String search = searchField != null ? searchField.getText() : "";
                var logs = search.isEmpty() ? 
                    AdminPanelClient.getChatLogManager().getAllLogs() : 
                    AdminPanelClient.getChatLogManager().searchLogs(search);
                
                // Вычисляем высоту с учетом переноса
                int maxWidth = this.width - SIDEBAR_WIDTH - 50;
                int totalHeight = 0;
                
                for (var entry : logs) {
                    totalHeight += calculateEntryHeight(entry, maxWidth) + 2;
                }
                
                return Math.max(0, totalHeight - visibleHeight);
            }
            case "anticheat": {
                // ИСПРАВЛЕНО: Используем ОТФИЛЬТРОВАННЫЙ список
                var allPlayers = AdminPanelClient.getPlayerManager().getPlayersSortedAlphabetically();
                String search = searchField != null ? searchField.getText().toLowerCase() : "";
                var players = allPlayers;
                
                if (!search.isEmpty()) {
                    players = allPlayers.stream()
                        .filter(p -> p.getUsername().toLowerCase().contains(search))
                        .collect(java.util.stream.Collectors.toList());
                }
                
                int cardHeight = 90;
                int totalRows = (int) Math.ceil(players.size() / 3.0);
                int totalHeight = totalRows * (cardHeight + CARD_PADDING);
                return Math.max(0, totalHeight - visibleHeight);
            }
            case "issued": {
                // Фильтруем историю - убираем размуты и разбаны
                var allHistory = AdminPanelClient.getPunishmentManager().getPunishmentHistory();
                var history = allHistory.stream()
                    .filter(record -> record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE 
                                   && record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN)
                    .collect(java.util.stream.Collectors.toList());
                
                // Фильтрация по поиску
                String search = searchField != null ? searchField.getText().toLowerCase() : "";
                if (!search.isEmpty()) {
                    history = history.stream()
                        .filter(record -> record.getUsername().toLowerCase().contains(search))
                        .collect(java.util.stream.Collectors.toList());
                }
                
                int itemHeight = 30;
                int totalHeight = history.size() * itemHeight;
                return Math.max(0, totalHeight - visibleHeight);
            }
            default:
                return 0; // Для вкладок без скролла
        }
    }
    
    private void renderScrollbar(DrawContext context, int contentX, int contentY, int contentWidth, int contentHeight, int maxScroll) {
        if (maxScroll <= 0) return; // Нет необходимости в скроллбаре
        
        int scrollbarX = contentX + contentWidth + 5;
        int scrollbarY = contentY;
        int scrollbarWidth = 6;
        int scrollbarHeight = contentHeight;
        
        // Фон скроллбара
        context.fill(scrollbarX, scrollbarY, scrollbarX + scrollbarWidth, scrollbarY + scrollbarHeight, 0xFF1a1f2e);
        
        // Ползунок
        float scrollPercentage = (float) scrollOffset / maxScroll;
        int thumbHeight = Math.max(20, (int) (scrollbarHeight * ((float) scrollbarHeight / (scrollbarHeight + maxScroll))));
        int thumbY = scrollbarY + (int) ((scrollbarHeight - thumbHeight) * scrollPercentage);
        
        // Ползунок с градиентом
        context.fillGradient(scrollbarX + 1, thumbY, scrollbarX + scrollbarWidth - 1, thumbY + thumbHeight, 0xFF5588ff, 0xFF4477ee);
        
        // Границы ползунка
        context.fill(scrollbarX + 1, thumbY, scrollbarX + scrollbarWidth - 1, thumbY + 1, 0xFF6699ff);
        context.fill(scrollbarX + 1, thumbY + thumbHeight - 1, scrollbarX + scrollbarWidth - 1, thumbY + thumbHeight, 0xFF3366dd);
    }
    
    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        // Проверяем наведение на карточки и кнопки для воспроизведения звука
        checkHoverSound(mouseX, mouseY);
        super.mouseMoved(mouseX, mouseY);
    }
    
    private void checkHoverSound(double mouseX, double mouseY) {
        int contentX = SIDEBAR_WIDTH + 20;
        int contentY = HEADER_HEIGHT + 80;
        int contentWidth = this.width - SIDEBAR_WIDTH - 40;
        
        // Проверка наведения на карточки главной страницы
        if (currentTab.equals("home")) {
            int cardWidth = (contentWidth - CARD_PADDING) / 2;
            int cardHeight = 120;
            
            int[][] cardPositions = {
                {contentX, contentY},
                {contentX + cardWidth + CARD_PADDING, contentY},
                {contentX, contentY + cardHeight + CARD_PADDING},
                {contentX + cardWidth + CARD_PADDING, contentY + cardHeight + CARD_PADDING}
            };
            
            for (int i = 0; i < cardPositions.length; i++) {
                int x = cardPositions[i][0];
                int y = cardPositions[i][1];
                
                if (mouseX >= x && mouseX <= x + cardWidth && 
                    mouseY >= y && mouseY <= y + cardHeight) {
                    if (hoveredButtonIndex != i) {
                        hoveredButtonIndex = i;
                        SoundManager.playHoverSound();
                    }
                    return;
                }
            }
        }
        
        // Проверка наведения на карточки игроков
        if (currentTab.equals("players") || currentTab.equals("anticheat")) {
            int cardWidth = (contentWidth - CARD_PADDING * 2) / 3;
            int cardHeight = currentTab.equals("players") ? 80 : 90;
            
            // ИСПРАВЛЕНО: Используем ОТФИЛЬТРОВАННЫЙ список
            var allPlayers = currentTab.equals("players") 
                ? AdminPanelClient.getPlayerManager().getPlayersSortedByActivity()
                : AdminPanelClient.getPlayerManager().getPlayersSortedAlphabetically();
            
            String search = searchField != null ? searchField.getText().toLowerCase() : "";
            var players = allPlayers;
            
            if (!search.isEmpty()) {
                players = allPlayers.stream()
                    .filter(p -> p.getUsername().toLowerCase().contains(search))
                    .collect(java.util.stream.Collectors.toList());
            }
            
            int row = 0;
            int col = 0;
            int index = 0;
            
            // ИСПРАВЛЕНО: Итерируем по ОТФИЛЬТРОВАННОМУ списку
            for (var player : players) {
                int cardX = contentX + col * (cardWidth + CARD_PADDING);
                int cardY = contentY + row * (cardHeight + CARD_PADDING) - scrollOffset;
                
                if (cardY >= contentY - cardHeight && cardY < this.height - 20) {
                    if (mouseX >= cardX && mouseX <= cardX + cardWidth && 
                        mouseY >= cardY && mouseY <= cardY + cardHeight) {
                        if (hoveredButtonIndex != index) {
                            hoveredButtonIndex = index;
                            SoundManager.playHoverSound();
                        }
                        return;
                    }
                }
                
                col++;
                if (col >= 3) {
                    col = 0;
                    row++;
                }
                index++;
            }
        }
        
        hoveredButtonIndex = -1;
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // ПКМ по полю поиска - очистить
        if (button == 1 && searchField != null) { // ПКМ
            int searchX = 30; // Было SIDEBAR_WIDTH + 30, теперь просто 30
            int searchY = HEADER_HEIGHT - 15;
            int searchWidth = 600;
            int searchHeight = 25;
            
            if (mouseX >= searchX && mouseX <= searchX + searchWidth && 
                mouseY >= searchY && mouseY <= searchY + searchHeight) {
                searchField.setText("");
                SoundManager.playClickSound();
                return true;
            }
        }
        
        // ПРИОРИТЕТ: Обработка кликов по верхней панели навигации
        if (handleTopBarClick(mouseX, mouseY)) {
            return true;
        }
        
        // ОБРАБОТКА КОНТЕКСТНОГО МЕНЮ (приоритет)
        if (quickMuteMenu != null && quickMuteMenu.isOpen()) {
            if (quickMuteMenu.handleClick((int) mouseX, (int) mouseY)) {
                return true; // Клик обработан меню
            }
        }
        
        // ПКМ в логах чата - ОТКЛЮЧЕНО (упрощенные логи)
        // if (button == 1 && currentTab.equals("logs")) {
        //     if (handleChatLogRightClick(mouseX, mouseY)) {
        //         return true;
        //     }
        // }
        
        // Воспроизводим звук клика
        SoundManager.playClickSound();
        
        if (searchField != null) {
            searchField.mouseClicked(mouseX, mouseY, button);
        }
        
        // Обработка клика по кнопке "Открыть консоль" на главной странице
        if (currentTab.equals("console")) {
            handleConsoleButtonClick(mouseX, mouseY);
        }
        
        // Обработка кликов по карточкам на главной странице
        if (currentTab.equals("home")) {
            handleHomeCardClick(mouseX, mouseY);
        }
        
        // Обработка кликов по кнопкам в списках
        if (currentTab.equals("players") || currentTab.equals("anticheat")) {
            handlePlayerClick(mouseX, mouseY);
        }
        
        // Обработка кликов по кнопке VIEW в выданных наказаниях
        if (currentTab.equals("issued")) {
            handleIssuedClick(mouseX, mouseY);
        }
        
        // Обработка двойного клика по никнейму в логах чата - ОТКЛЮЧЕНО (упрощенные логи)
        // if (currentTab.equals("logs")) {
        //     handleChatLogClick(mouseX, mouseY);
        // }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    /**
     * Обработка клика по верхней панели навигации
     */
    private boolean handleTopBarClick(double mouseX, double mouseY) {
        int barHeight = 50;
        
        // Проверяем что клик в области верхней панели
        if (mouseY < 0 || mouseY > barHeight) {
            return false;
        }
        
        int buttonWidth = 115; // Обновлено для 7 кнопок
        int buttonHeight = 35;
        int buttonSpacing = 8; // Обновлено
        int totalWidth = buttonWidth * 7 + buttonSpacing * 6; // Обновлено для 7 кнопок
        int startX = (this.width - totalWidth) / 2;
        int buttonY = (barHeight - buttonHeight) / 2;
        
        // Кнопка 1: Консоль
        int button1X = startX;
        if (mouseX >= button1X && mouseX <= button1X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new ConsoleScreen(this));
            return true;
        }
        
        // Кнопка 2: Игроки
        int button2X = button1X + buttonWidth + buttonSpacing;
        if (mouseX >= button2X && mouseX <= button2X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            setCurrentTab("players");
            this.clearAndInit();
            return true;
        }
        
        // Кнопка 3: Проверка
        int button3X = button2X + buttonWidth + buttonSpacing;
        if (mouseX >= button3X && mouseX <= button3X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            setCurrentTab("anticheat");
            this.clearAndInit();
            return true;
        }
        
        // Кнопка 4: Выданные
        int button4X = button3X + buttonWidth + buttonSpacing;
        if (mouseX >= button4X && mouseX <= button4X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            setCurrentTab("issued");
            this.clearAndInit();
            return true;
        }
        
        // Кнопка 5: Правила
        int button5X = button4X + buttonWidth + buttonSpacing;
        if (mouseX >= button5X && mouseX <= button5X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new RulesScreen(this));
            return true;
        }
        
        // Кнопка 6: Темы (НОВАЯ)
        int button6X = button5X + buttonWidth + buttonSpacing;
        if (mouseX >= button6X && mouseX <= button6X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new ThemeSettingsScreen(this));
            return true;
        }
        
        // Кнопка 7: Интерфейс
        int button7X = button6X + buttonWidth + buttonSpacing;
        if (mouseX >= button7X && mouseX <= button7X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new InterfaceScreen(this));
            return true;
        }
        
        return false;
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // ESC закрывает контекстное меню
        if (keyCode == 256 && quickMuteMenu != null && quickMuteMenu.isOpen()) { // 256 = ESC
            quickMuteMenu.close();
            return true;
        }
        
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    /**
     * Обработка клика по кнопке "Открыть консоль"
     */
    private void handleConsoleButtonClick(double mouseX, double mouseY) {
        int contentX = SIDEBAR_WIDTH + 20;
        int contentY = HEADER_HEIGHT + 80;
        int contentWidth = this.width - SIDEBAR_WIDTH - 40;
        
        int centerX = contentX + contentWidth / 2;
        int centerY = contentY + 100;
        
        int buttonWidth = 200;
        int buttonHeight = 40;
        int buttonX = centerX - buttonWidth / 2;
        int buttonY = centerY + 80;
        
        // Проверка клика по кнопке
        if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            // Открываем отдельный экран консоли
            this.client.setScreen(new ConsoleScreen(this));
        }
    }
    
    private void handleHomeCardClick(double mouseX, double mouseY) {
        int contentX = SIDEBAR_WIDTH + 20;
        int contentY = HEADER_HEIGHT + 80;
        int contentWidth = this.width - SIDEBAR_WIDTH - 40;
        int cardWidth = (contentWidth - CARD_PADDING) / 2;
        int cardHeight = 120;
        
        // Проверка клика по кнопкам карточек
        int[][] cardPositions = {
            {contentX, contentY},
            {contentX + cardWidth + CARD_PADDING, contentY},
            {contentX, contentY + cardHeight + CARD_PADDING},
            {contentX + cardWidth + CARD_PADDING, contentY + cardHeight + CARD_PADDING}
        };
        
        String[] tabs = {"players", "punishments", "logs", "issued"};
        String[] buttonTexts = {"Просмотреть", "Выдать наказание", "Просмотреть", "Просмотреть"};
        
        for (int i = 0; i < cardPositions.length; i++) {
            int x = cardPositions[i][0];
            int y = cardPositions[i][1];
            
            int buttonTextWidth = this.textRenderer.getWidth(buttonTexts[i]);
            int buttonWidth = Math.max(90, buttonTextWidth + 20);
            int buttonX = x + cardWidth - buttonWidth - 15;
            int buttonY = y + cardHeight - 40;
            
            if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                mouseY >= buttonY && mouseY <= buttonY + 25) {
                currentTab = tabs[i];
                scrollOffset = 0;
                this.clearAndInit();
                return;
            }
        }
    }
    
    private void handlePlayerClick(double mouseX, double mouseY) {
        if (currentTab.equals("players")) {
            // ИСПРАВЛЕНО: Используем ОТФИЛЬТРОВАННЫЙ список (как в рендере)
            var allPlayers = AdminPanelClient.getPlayerManager().getPlayersSortedByActivity();
            String search = searchField != null ? searchField.getText() : "";
            var players = allPlayers;
            
            if (!search.isEmpty()) {
                players = allPlayers.stream()
                    .filter(p -> p.getUsername().toLowerCase().contains(search.toLowerCase()))
                    .collect(java.util.stream.Collectors.toList());
            }
            
            int contentX = 20; // ИСПРАВЛЕНО: было SIDEBAR_WIDTH + 20
            int contentY = HEADER_HEIGHT + 20; // ИСПРАВЛЕНО: было HEADER_HEIGHT + 80
            int contentWidth = this.width - 40; // ИСПРАВЛЕНО: было this.width - SIDEBAR_WIDTH - 40
            
            int cardWidth = (contentWidth - CARD_PADDING * 2) / 3;
            int cardHeight = 80;
            int row = 0;
            int col = 0;
            
            // ИСПРАВЛЕНО: Итерируем по ОТФИЛЬТРОВАННОМУ списку
            for (PlayerData player : players) {
                int cardX = contentX + col * (cardWidth + CARD_PADDING);
                int cardY = contentY + row * (cardHeight + CARD_PADDING) - scrollOffset;
                
                if (cardY >= contentY - cardHeight && cardY < this.height - 20) {
                    int buttonWidth = 100;
                    int buttonHeight = 25;
                    int buttonX = cardX + (cardWidth - buttonWidth) / 2;
                    int buttonY = cardY + cardHeight - buttonHeight - 10;
                    
                    if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                        // ИСПРАВЛЕНО: Используем объект player напрямую, а не индекс
                        this.client.setScreen(new PunishmentScreen(player.getUsername()));
                        return;
                    }
                }
                
                col++;
                if (col >= 3) {
                    col = 0;
                    row++;
                }
            }
        } else if (currentTab.equals("anticheat")) {
            // ИСПРАВЛЕНО: Используем ОТФИЛЬТРОВАННЫЙ список (как в рендере)
            var allPlayers = AdminPanelClient.getPlayerManager().getPlayersSortedAlphabetically();
            String search = searchField != null ? searchField.getText().toLowerCase() : "";
            var players = allPlayers;
            
            if (!search.isEmpty()) {
                players = allPlayers.stream()
                    .filter(p -> p.getUsername().toLowerCase().contains(search))
                    .collect(java.util.stream.Collectors.toList());
            }
            
            int contentX = 20; // ИСПРАВЛЕНО: было SIDEBAR_WIDTH + 20
            int contentY = HEADER_HEIGHT + 20; // ИСПРАВЛЕНО: было HEADER_HEIGHT + 80
            int contentWidth = this.width - 40; // ИСПРАВЛЕНО: было this.width - SIDEBAR_WIDTH - 40
            
            int cardWidth = (contentWidth - CARD_PADDING * 2) / 3;
            int cardHeight = 90;
            int row = 0;
            int col = 0;
            
            // ИСПРАВЛЕНО: Итерируем по ОТФИЛЬТРОВАННОМУ списку
            for (PlayerData player : players) {
                int cardX = contentX + col * (cardWidth + CARD_PADDING);
                int cardY = contentY + row * (cardHeight + CARD_PADDING) - scrollOffset;
                
                if (cardY >= contentY - cardHeight && cardY < this.height - 20) {
                    int buttonWidth = cardWidth - 30;
                    int buttonHeight = 30; // ИСПРАВЛЕНО: было 25, теперь 30 (синхронизировано с рендером)
                    int buttonX = cardX + 15;
                    int buttonY = cardY + cardHeight - buttonHeight - 10;
                    
                    if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                        // ИСПРАВЛЕНО: Используем объект player напрямую, а не индекс
                        this.client.setScreen(new AntiCheatScreen(player.getUsername()));
                        return;
                    }
                }
                
                col++;
                if (col >= 3) {
                    col = 0;
                    row++;
                }
            }
        }
    }
    
    /**
     * Обработка кликов по кнопке VIEW в выданных наказаниях
     */
    private void handleIssuedClick(double mouseX, double mouseY) {
        int contentX = SIDEBAR_WIDTH + 20;
        int contentY = HEADER_HEIGHT + 80;
        int contentWidth = this.width - SIDEBAR_WIDTH - 40;
        
        var history = AdminPanelClient.getPunishmentManager().getPunishmentHistory();
        if (history.isEmpty()) return;
        
        int itemY = contentY - scrollOffset;
        
        for (var record : history) {
            if (itemY >= contentY && itemY < this.height - 20) {
                // ИСПРАВЛЕНО: Координаты кнопки "Просмотреть" (обновлены под новую ширину)
                int buttonX = contentX + contentWidth - 120;
                int buttonY = itemY + 8;
                int buttonWidth = 105;
                int buttonHeight = 20;
                
                if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && 
                    mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                    // ИСПРАВЛЕНО: Передаем весь объект record с сообщениями
                    this.client.setScreen(new PunishmentDetailsScreen(record));
                    return;
                }
            }
            itemY += 45;
        }
    }
    
    /**
     * Рендерит мягкий радиальный градиент фона
     * Центр экрана светлее (#141A2A), края темнее (#0E111B)
     * Создает эффект глубины и снижает усталость глаз
     * v4.0 - Современный градиент в стиле visual/cheat GUI
     */
    private void renderRadialGradientBackground(DrawContext context) {
        // Мягкий вертикальный градиент (темно-синий/графитовый)
        // Верх темнее, низ светлее для эффекта глубины
        context.fillGradient(0, 0, this.width, this.height / 2, COLOR_BG_DARKEST(), COLOR_BG_DARK());
        context.fillGradient(0, this.height / 2, this.width, this.height, COLOR_BG_DARK(), COLOR_BG_DARKEST());
    }
    
    /**
     * Рендерит счетчик онлайн игроков (слева сверху)
     */
    private void renderOnlineCounter(DrawContext context) {
        int x = 10;
        int y = 18;
        
        // Получаем количество онлайн игроков
        int onlineCount = AdminPanelClient.getPlayerManager().getPlayersSortedByActivity().size();
        
        // Текст без иконки
        String text = onlineCount + " онлайн";
        context.drawText(this.textRenderer, text, x, y, COLOR_TEXT_SECONDARY, false);
    }
    
    /**
     * Рендерит стилизованное поле поиска с надписью и скругленными углами
     */
    private void renderStyledSearchField(DrawContext context, int mouseX, int mouseY, float delta) {
        int searchWidth = 600; // Увеличено с 300 до 600
        int searchX = 30; // Было SIDEBAR_WIDTH + 30
        int searchY = HEADER_HEIGHT - 15; // Было HEADER_HEIGHT + 10, подняли на 25px выше
        int searchHeight = 25;
        
        // Надпись над полем удалена по запросу пользователя
        String label = "";
        if (currentTab.equals("players")) {
            label = "";
        } else if (currentTab.equals("logs")) {
            label = "Поиск в логах";
        } else if (currentTab.equals("anticheat")) {
            label = "";
        }
        if (!label.isEmpty()) {
            context.drawText(this.textRenderer, label, searchX, searchY - 15, COLOR_TEXT_SECONDARY, false);
        }
        
        // Проверка hover
        boolean isHovered = mouseX >= searchX && mouseX <= searchX + searchWidth && 
                           mouseY >= searchY && mouseY <= searchY + searchHeight;
        
        // Фон поля с градиентом (чуть светлее при фокусе) - СКРУГЛЕННЫЙ
        int bgColor = searchField.isFocused() ? 
            com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BG_CARD(), 1.1f) : 
            COLOR_BG_CARD();
        int bgColorDarker = com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(bgColor, 0.95f);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedGradient(context, searchX, searchY, searchWidth, searchHeight, 8, bgColor, bgColorDarker);
        
        // Границы с улучшенным эффектом (чуть светлее при hover/focus) - СКРУГЛЕННЫЕ
        int borderColor = (searchField.isFocused() || isHovered) ? 
            com.whiterise.adminpanel.util.RenderUtils.adjustBrightness(COLOR_BORDER(), 1.3f) : 
            COLOR_BORDER();
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, searchX, searchY, searchWidth, searchHeight, 8, borderColor);
        
        // Убрано свечение при фокусе (было слишком ярко)
        
        // Иконка поиска слева
        int iconY = searchY + (searchHeight - 8) / 2;
        context.drawText(this.textRenderer, "🔍", searchX + 5, iconY, COLOR_TEXT_SECONDARY, false);
        
        // Рендерим само поле
        searchField.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Устанавливает активную вкладку (для возврата из других экранов)
     */
    public void setCurrentTab(String tab) {
        this.currentTab = tab;
        this.scrollOffset = 0;
    }
    
    /**
     * Рендерит верхнюю панель навигации с кнопками
     */
    private void renderTopNavigationBar(DrawContext context, int mouseX, int mouseY) {
        int barHeight = 50;
        
        // Фон панели
        context.fillGradient(0, 0, this.width, barHeight, COLOR_BG_CARD(), COLOR_BG_DARK());
        
        // Нижняя граница
        context.fill(0, barHeight, this.width, barHeight + 2, COLOR_BORDER());
        
        // Кнопки в один ряд (7 кнопок: Консоль, Игроки, Проверка, Выданные, Правила, Темы, Интерфейс)
        int buttonWidth = 115; // Уменьшена ширина для 7 кнопок
        int buttonHeight = 35;
        int buttonSpacing = 8; // Уменьшен отступ
        int totalWidth = buttonWidth * 7 + buttonSpacing * 6;
        int startX = (this.width - totalWidth) / 2; // Центрируем
        int buttonY = (barHeight - buttonHeight) / 2;
        
        // Кнопка 1: Консоль
        boolean hover1 = mouseX >= startX && mouseX <= startX + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover1 && !wasConsoleButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasConsoleButtonHovered = hover1;
        renderTopBarButton(context, startX, buttonY, buttonWidth, buttonHeight, ICON_CONSOLE, "Консоль", hover1, currentTab.equals("console"));
        
        // Кнопка 2: Игроки
        int button2X = startX + buttonWidth + buttonSpacing;
        boolean hover2 = mouseX >= button2X && mouseX <= button2X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover2 && !wasPlayersButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasPlayersButtonHovered = hover2;
        renderTopBarButton(context, button2X, buttonY, buttonWidth, buttonHeight, ICON_PLAYERS, "Игроки", hover2, currentTab.equals("players"));
        
        // Кнопка 3: Проверка
        int button3X = button2X + buttonWidth + buttonSpacing;
        boolean hover3 = mouseX >= button3X && mouseX <= button3X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover3 && !wasAntiCheatButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasAntiCheatButtonHovered = hover3;
        renderTopBarButton(context, button3X, buttonY, buttonWidth, buttonHeight, ICON_SHIELD, "Проверка", hover3, currentTab.equals("anticheat"));
        
        // Кнопка 4: Выданные
        int button4X = button3X + buttonWidth + buttonSpacing;
        boolean hover4 = mouseX >= button4X && mouseX <= button4X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover4 && !wasIssuedButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasIssuedButtonHovered = hover4;
        renderTopBarButton(context, button4X, buttonY, buttonWidth, buttonHeight, ICON_ISSUED, "Выданные", hover4, currentTab.equals("issued"));
        
        // Кнопка 5: Правила
        int button5X = button4X + buttonWidth + buttonSpacing;
        boolean hover5 = mouseX >= button5X && mouseX <= button5X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover5 && !wasRulesButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasRulesButtonHovered = hover5;
        renderTopBarButton(context, button5X, buttonY, buttonWidth, buttonHeight, ICON_RULES, "Правила", hover5, false);
        
        // Кнопка 6: Темы (НОВАЯ)
        int button6X = button5X + buttonWidth + buttonSpacing;
        boolean hover6 = mouseX >= button6X && mouseX <= button6X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover6 && !wasThemeButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasThemeButtonHovered = hover6;
        renderTopBarButton(context, button6X, buttonY, buttonWidth, buttonHeight, ICON_THEME, "Темы", hover6, false);
        
        // Кнопка 7: Интерфейс
        int button7X = button6X + buttonWidth + buttonSpacing;
        boolean hover7 = mouseX >= button7X && mouseX <= button7X + buttonWidth && 
                        mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
        if (hover7 && !wasInterfaceButtonHovered) {
            SoundManager.playHoverSound();
        }
        wasInterfaceButtonHovered = hover7;
        renderTopBarButton(context, button7X, buttonY, buttonWidth, buttonHeight, ICON_GUI_SETTINGS, "Интерфейс", hover7, currentTab.equals("interface"));
    }
    
    /**
     * Рендерит одну кнопку верхней панели с иконкой (текстовая иконка - эмодзи)
     */
    private void renderTopBarButton(DrawContext context, int x, int y, int width, int height, String icon, String text, boolean isHovered, boolean isActive) {
        // Фон кнопки (активная кнопка всегда подсвечена)
        int bgColor;
        if (isActive) {
            bgColor = COLOR_BG_HOVER(); // Активная кнопка
        } else {
            bgColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_DARKEST();
        }
        RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
        
        // Границы (активная кнопка с акцентной границей)
        int borderColor;
        if (isActive) {
            borderColor = COLOR_ACCENT(); // Активная кнопка
        } else {
            borderColor = isHovered ? COLOR_ACCENT() : COLOR_BORDER();
        }
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, borderColor);
        
        // Иконка слева
        int iconSize = 16;
        int iconX = x + 15;
        int iconY = y + (height - iconSize) / 2;
        context.drawText(this.textRenderer, icon, iconX, iconY, COLOR_ACCENT(), false);
        
        // Текст справа от иконки
        int textX = iconX + iconSize + 8;
        int textY = y + (height - 8) / 2;
        int textColor;
        if (isActive) {
            textColor = COLOR_TEXT_PRIMARY; // Активная кнопка
        } else {
            textColor = isHovered ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
        }
        context.drawText(this.textRenderer, text, textX, textY, textColor, isActive || isHovered);
    }
    
    /**
     * Рендерит одну кнопку верхней панели с иконкой (PNG иконка из assets)
     */
    private void renderTopBarButton(DrawContext context, int x, int y, int width, int height, Identifier iconTexture, String text, boolean isHovered, boolean isActive) {
        // Фон кнопки (активная кнопка всегда подсвечена)
        int bgColor;
        if (isActive) {
            bgColor = COLOR_BG_HOVER(); // Активная кнопка
        } else {
            bgColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_DARKEST();
        }
        RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
        
        // Границы (активная кнопка с акцентной границей)
        int borderColor;
        if (isActive) {
            borderColor = COLOR_ACCENT(); // Активная кнопка
        } else {
            borderColor = isHovered ? COLOR_ACCENT() : COLOR_BORDER();
        }
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, borderColor);
        
        // Текст - центрируем
        int iconSize = 20; // Уменьшено с 24 до 20 для лучшего вмещения в блоки
        int textWidth = this.textRenderer.getWidth(text);
        
        // Центрируем текст по горизонтали
        int textX = x + (width - textWidth) / 2;
        int textY = y + (height - 8) / 2;
        
        // Иконка слева от текста
        int iconX = textX - iconSize - 8; // Слева от текста с отступом 8px
        int iconY = y + (height - iconSize) / 2;
        context.drawTexture(iconTexture, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Рендерим текст
        int textColor;
        if (isActive) {
            textColor = COLOR_TEXT_PRIMARY; // Активная кнопка
        } else {
            textColor = isHovered ? COLOR_TEXT_PRIMARY : COLOR_TEXT_SECONDARY;
        }
        context.drawText(this.textRenderer, text, textX, textY, textColor, isActive || isHovered);
    }
    
}

