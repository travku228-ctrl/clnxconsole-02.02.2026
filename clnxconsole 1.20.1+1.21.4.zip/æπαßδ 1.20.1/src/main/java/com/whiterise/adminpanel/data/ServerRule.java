package com.whiterise.adminpanel.data;

public class ServerRule {
    private final RuleType type;
    private final String content;
    
    public ServerRule(RuleType type, String content) {
        this.type = type;
        this.content = content;
    }
    
    public RuleType getType() {
        return type;
    }
    
    public String getContent() {
        return content;
    }
    
    public enum RuleType {
        SECTION,      // Раздел (оранжевый, большой шрифт)
        RULE,         // Пункт правила (синий, средний шрифт)
        DESCRIPTION,  // Описание (белый, чуть меньше среднего)
        DURATION,     // Длительность наказания (красный)
        EXCEPTION,    // Исключения/запрещенные моды (темно-оранжевый)
        SEPARATOR     // Разделитель
    }
}
