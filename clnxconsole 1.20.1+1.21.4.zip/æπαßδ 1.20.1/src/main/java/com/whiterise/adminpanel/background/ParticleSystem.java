package com.whiterise.adminpanel.background;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Система фоновых частиц для GUI
 * 
 * КЛЮЧЕВЫЕ ОСОБЕННОСТИ:
 * - Частицы создаются ОДИН РАЗ при инициализации
 * - ПЕРМАНЕНТНЫЕ (без времени жизни)
 * - WRAP-AROUND (телепорт на противоположную сторону)
 * - Плавное движение с высокой частотой обновления
 * - Правильный Z-ORDER (частицы ПОД UI элементами)
 */
public class ParticleSystem {
    private static ParticleSystem INSTANCE;
    
    // Список частиц (создаются ОДИН РАЗ)
    private final List<Particle> particles = new ArrayList<>();
    
    // Флаг инициализации
    private boolean initialized = false;
    
    // === КОНСТАНТЫ ===
    private static final int PARTICLE_COUNT = 40;
    private static final float PARTICLE_RADIUS_MIN = 1.5f;
    private static final float PARTICLE_RADIUS_MAX = 2.5f;
    
    // ЕЩЁ БОЛЕЕ МЕДЛЕННАЯ СКОРОСТЬ (в 8 раз медленнее оригинала)
    private static final float MIN_VELOCITY = 1.5f;   // было 2.5f
    private static final float MAX_VELOCITY = 4.0f;   // было 7.0f
    
    // УМЕНЬШЕННОЕ РАССТОЯНИЕ СОЕДИНЕНИЯ (короче линии)
    private static final float MAX_CONNECTION_DISTANCE = 90.0f;  // было 120.0f
    
    // Цвет и прозрачность
    private static final float PARTICLE_ALPHA = 0.8f; // Увеличена прозрачность
    private static final float LINE_ALPHA_MAX = 0.6f; // Увеличена прозрачность линий
    private static final int PARTICLE_COLOR = 0x00D9FF; // Голубой цвет (акцентный из мода)
    private static final int LINE_COLOR = 0xFFFFFF; // Белый для линий
    
    // Параметры реакции на курсор
    private static final float CURSOR_REPEL_DISTANCE = 100.0f; // Радиус отталкивания от курсора
    private static final float CURSOR_REPEL_FORCE = 150.0f;    // Сила отталкивания
    
    // Параметры отталкивания между частицами
    private static final float PARTICLE_REPEL_DISTANCE = 90.0f; // Расстояние отталкивания (равно дистанции соединения)
    private static final float PARTICLE_REPEL_FORCE = 80.0f;     // Сила отталкивания между частицами
    
    private final Random random = new Random();
    
    private ParticleSystem() {
    }
    
    public static ParticleSystem getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ParticleSystem();
        }
        return INSTANCE;
    }
    
    /**
     * Инициализация системы частиц
     * Создает частицы ОДИН РАЗ
     */
    public void init(int screenWidth, int screenHeight) {
        if (initialized) {
            return;
        }
        
        particles.clear();
        
        // Получаем количество частиц из настроек
        int particleCount = com.whiterise.adminpanel.hud.HudConfig.getParticleCount();
        
        for (int i = 0; i < particleCount; i++) {
            // Случайная позиция
            float x = random.nextFloat() * screenWidth;
            float y = random.nextFloat() * screenHeight;
            
            // Случайная скорость с учётом множителя из настроек
            float speedMultiplier = com.whiterise.adminpanel.hud.HudConfig.getParticleSpeed();
            float velocityX = (MIN_VELOCITY + random.nextFloat() * (MAX_VELOCITY - MIN_VELOCITY)) * speedMultiplier;
            float velocityY = (MIN_VELOCITY + random.nextFloat() * (MAX_VELOCITY - MIN_VELOCITY)) * speedMultiplier;
            
            // Случайное направление
            if (random.nextBoolean()) velocityX = -velocityX;
            if (random.nextBoolean()) velocityY = -velocityY;
            
            // Случайный размер
            float radius = PARTICLE_RADIUS_MIN + random.nextFloat() * (PARTICLE_RADIUS_MAX - PARTICLE_RADIUS_MIN);
            
            particles.add(new Particle(x, y, velocityX, velocityY, radius, screenWidth, screenHeight));
        }
        
        initialized = true;
    }
    
    /**
    /**
     * Обновление всех частиц
     * Вызывается каждый кадр для плавности
     * Применяет отталкивание от курсора и между частицами
     */
    public void update(float delta, int mouseX, int mouseY) {
        if (!initialized) {
            return;
        }
        
        MinecraftClient client = MinecraftClient.getInstance();
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();
        
        // Ограничиваем delta для предотвращения рывков при лагах
        // Максимум 0.1 секунды (100ms) за кадр
        float smoothDelta = Math.min(delta, 0.1f);
        
        // Кэшируем квадраты расстояний для оптимизации (избегаем sqrt)
        float cursorRepelDistanceSq = CURSOR_REPEL_DISTANCE * CURSOR_REPEL_DISTANCE;
        float particleRepelDistanceSq = PARTICLE_REPEL_DISTANCE * PARTICLE_REPEL_DISTANCE;
        
        // Обновляем размеры экрана и применяем силы
        for (Particle particle : particles) {
            particle.updateScreenSize(screenWidth, screenHeight);
            
            // === ОТТАЛКИВАНИЕ ОТ КУРСОРА ===
            float dx = particle.getX() - mouseX;
            float dy = particle.getY() - mouseY;
            float distanceSq = dx * dx + dy * dy;
            
            // Если частица близко к курсору - отталкиваем её
            if (distanceSq < cursorRepelDistanceSq && distanceSq > 0.1f) {
                // Теперь вычисляем реальное расстояние
                float distance = (float) Math.sqrt(distanceSq);
                
                // Нормализуем вектор направления
                float dirX = dx / distance;
                float dirY = dy / distance;
                
                // Сила отталкивания зависит от расстояния (чем ближе, тем сильнее)
                float repelStrength = (1.0f - (distance / CURSOR_REPEL_DISTANCE)) * CURSOR_REPEL_FORCE;
                
                // Применяем силу отталкивания с учётом smoothDelta
                particle.applyForce(dirX * repelStrength * smoothDelta, dirY * repelStrength * smoothDelta);
            }
            
            // === ОТТАЛКИВАНИЕ ОТ ДРУГИХ ЧАСТИЦ ===
            for (Particle other : particles) {
                if (particle == other) continue; // Пропускаем саму себя
                
                float dx2 = particle.getX() - other.getX();
                float dy2 = particle.getY() - other.getY();
                float distanceSq2 = dx2 * dx2 + dy2 * dy2;
                
                // Если частицы близко друг к другу - отталкиваем
                if (distanceSq2 < particleRepelDistanceSq && distanceSq2 > 0.1f) {
                    // Вычисляем реальное расстояние
                    float distance2 = (float) Math.sqrt(distanceSq2);
                    
                    // Нормализуем вектор направления
                    float dirX2 = dx2 / distance2;
                    float dirY2 = dy2 / distance2;
                    
                    // Сила отталкивания зависит от расстояния (чем ближе, тем сильнее)
                    float repelStrength2 = (1.0f - (distance2 / PARTICLE_REPEL_DISTANCE)) * PARTICLE_REPEL_FORCE;
                    
                    // Применяем силу отталкивания с учётом smoothDelta
                    particle.applyForce(dirX2 * repelStrength2 * smoothDelta, dirY2 * repelStrength2 * smoothDelta);
                }
            }
            
            // Обновляем частицу с учётом smoothDelta
            particle.update(smoothDelta);
        }
    }
    
    /**
     * Рендер всех частиц и соединений
     * 
     * ВАЖНО: Рендерится с правильным Z-ORDER (ПОД UI элементами)
     */
    public void render(DrawContext context, float delta, int mouseX, int mouseY) {
        // ПРОВЕРКА НАСТРОЙКИ: если частицы выключены - не рендерим
        if (!com.whiterise.adminpanel.hud.HudConfig.isBackgroundParticlesEnabled()) {
            return;
        }
        
        if (!initialized) {
            MinecraftClient client = MinecraftClient.getInstance();
            init(client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight());
            System.out.println("[ParticleSystem] Initialized with " + particles.size() + " particles");
        }
        
        // Обновляем частицы с учётом позиции курсора
        update(delta, mouseX, mouseY);
        
        // Включаем blend для сглаживания
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        
        // Рендерим соединения (линии) - СНАЧАЛА
        renderConnections(context);
        
        // Рендерим частицы - ПОТОМ (поверх линий)
        renderParticles(context);
        
        RenderSystem.disableBlend();
    }
    
    /**
     * Рендер соединений между близкими частицами
     */
    private void renderConnections(DrawContext context) {
        // Проходим по всем парам частиц
        for (int i = 0; i < particles.size(); i++) {
            Particle p1 = particles.get(i);
            
            for (int j = i + 1; j < particles.size(); j++) {
                Particle p2 = particles.get(j);
                
                // Вычисляем расстояние
                float dx = p2.getX() - p1.getX();
                float dy = p2.getY() - p1.getY();
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                
                // Рисуем линию если расстояние меньше максимального
                if (distance < MAX_CONNECTION_DISTANCE) {
                    // Вычисляем прозрачность (чем дальше, тем прозрачнее)
                    float alpha = (1.0f - (distance / MAX_CONNECTION_DISTANCE)) * LINE_ALPHA_MAX;
                    int alphaInt = (int) (alpha * 255);
                    
                    // Цвет линии с прозрачностью (белый)
                    int color = (alphaInt << 24) | 0xFFFFFF;
                    
                    // Рисуем линию используя DrawContext
                    drawLine(context, (int) p1.getX(), (int) p1.getY(), (int) p2.getX(), (int) p2.getY(), color);
                }
            }
        }
    }
    
    /**
     * Рендер частиц
     */
    private void renderParticles(DrawContext context) {
        for (Particle particle : particles) {
            float x = particle.getX();
            float y = particle.getY();
            float radius = particle.getRadius();
            
            // Цвет частицы с прозрачностью (белый)
            int alphaInt = (int) (PARTICLE_ALPHA * 255);
            int color = (alphaInt << 24) | 0xFFFFFF;
            
            // Рисуем квад (прямоугольник)
            int x1 = (int) (x - radius);
            int y1 = (int) (y - radius);
            int x2 = (int) (x + radius);
            int y2 = (int) (y + radius);
            
            context.fill(x1, y1, x2, y2, color);
        }
    }
    
    /**
     * Рисует линию между двумя точками (алгоритм Брезенхема)
     */
    private void drawLine(DrawContext context, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        
        while (true) {
            // Рисуем пиксель
            context.fill(x1, y1, x1 + 1, y1 + 1, color);
            
            if (x1 == x2 && y1 == y2) break;
            
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }
    }
    
    /**
     * Сброс системы (при закрытии экрана или изменении настроек)
     */
    public void reset() {
        initialized = false;
        particles.clear();
    }
    
    /**
     * Пересоздаёт частицы с новыми настройками
     */
    public void reinitialize(int screenWidth, int screenHeight) {
        reset();
        init(screenWidth, screenHeight);
    }
}
