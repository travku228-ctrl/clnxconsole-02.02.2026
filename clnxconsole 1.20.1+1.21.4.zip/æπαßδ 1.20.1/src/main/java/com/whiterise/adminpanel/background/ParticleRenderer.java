package com.whiterise.adminpanel.background;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Рендерер фоновых частиц для GUI
 * 
 * Создает эффект "particle network" - анимированные частицы с соединениями
 * Частицы плавно двигаются по экрану и обходят UI элементы
 * Близкие частицы соединяются линиями с прозрачностью, зависящей от расстояния
 * 
 * Технические детали:
 * - Рендеринг через mixin в Screen.renderBackground()
 * - Гарантирует правильный Z-ORDER: фон -> частицы -> UI
 * - Запретные зоны защищают важные UI элементы от перекрытия
 * - Плавная анимация с хаотичным движением
 */
public class ParticleRenderer {
    private static ParticleRenderer INSTANCE;
    
    // === СПИСКИ ===
    private final List<BackgroundParticle> particles = new ArrayList<>();
    private final List<Rectangle> safeZones = new ArrayList<>();
    
    // Флаг инициализации запретных зон
    private boolean safeZonesInitialized = false;
    
    // === КОНСТАНТЫ ЧАСТИЦ ===
    /** Количество частиц на экране */
    private static final int PARTICLE_COUNT = 100;
    
    /** Радиус частицы в пикселях */
    private static final float PARTICLE_RADIUS = 2.0f;
    
    /** Минимальная скорость частицы (пикселей в секунду) */
    private static final float MIN_VELOCITY = 15.0f;
    
    /** Максимальная скорость частицы (пикселей в секунду) */
    private static final float MAX_VELOCITY = 40.0f;
    
    /** Цвет частиц (белый) */
    private static final int PARTICLE_COLOR = 0xFFFFFFFF;
    
    // === КОНСТАНТЫ СОЕДИНЕНИЙ ===
    /** Максимальное расстояние для соединения частиц линией */
    private static final float MAX_CONNECTION_DISTANCE = 150.0f;
    
    // === КОНСТАНТЫ ЗАПРЕТНЫХ ЗОН ===
    /** Ширина центральной панели */
    private static final int CENTER_PANEL_WIDTH = 400;
    
    /** Высота центральной панели */
    private static final int CENTER_PANEL_HEIGHT = 300;
    
    /** Высота верхней панели (заголовки) */
    private static final int TOP_PANEL_HEIGHT = 60;
    
    /** Высота нижней панели (кнопки) */
    private static final int BOTTOM_PANEL_HEIGHT = 80;
    
    /** Ширина левой боковой панели (навигация) */
    private static final int LEFT_PANEL_WIDTH = 150;
    
    private final Random random = new Random();
    
    private ParticleRenderer() {
    }
    
    public static ParticleRenderer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ParticleRenderer();
        }
        return INSTANCE;
    }
    
    /**
     * Инициализация рендерера
     * Больше не требуется регистрация - рендер вызывается через mixin
     */
    public void init() {
        // Инициализация завершена - рендер будет вызываться через ScreenMixin
    }
    
    /**
     * Настройка запретных зон (основные UI элементы)
     * Запретные зоны защищают важные UI элементы от перекрытия частицами
     */
    private void setupSafeZones() {
        MinecraftClient client = MinecraftClient.getInstance();
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();
        
        safeZones.clear();
        
        // Центральная панель (основное меню)
        int centerX = (screenWidth - CENTER_PANEL_WIDTH) / 2;
        int centerY = (screenHeight - CENTER_PANEL_HEIGHT) / 2;
        safeZones.add(new Rectangle(centerX, centerY, CENTER_PANEL_WIDTH, CENTER_PANEL_HEIGHT));
        
        // Верхняя панель (заголовки)
        safeZones.add(new Rectangle(0, 0, screenWidth, TOP_PANEL_HEIGHT));
        
        // Нижняя панель (кнопки)
        safeZones.add(new Rectangle(0, screenHeight - BOTTOM_PANEL_HEIGHT, screenWidth, BOTTOM_PANEL_HEIGHT));
        
        // Левая боковая панель (навигация)
        safeZones.add(new Rectangle(0, TOP_PANEL_HEIGHT, LEFT_PANEL_WIDTH, screenHeight - TOP_PANEL_HEIGHT - BOTTOM_PANEL_HEIGHT));
    }
    
    /**
     * Спавн частиц со случайными позициями и скоростями
     * Максимально хаотичный спавн по всему экрану
     */
    private void spawnParticles(int screenWidth, int screenHeight) {
        particles.clear();
        
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            spawnSingleParticle(screenWidth, screenHeight);
        }
    }
    
    /**
     * Спавн одной частицы в случайном месте экрана
     */
    private void spawnSingleParticle(int screenWidth, int screenHeight) {
        // Абсолютно случайная позиция по всему экрану
        float x = random.nextFloat() * screenWidth;
        float y = random.nextFloat() * screenHeight;
        
        // Случайная скорость в заданном диапазоне
        float velocityX = MIN_VELOCITY + random.nextFloat() * (MAX_VELOCITY - MIN_VELOCITY);
        float velocityY = MIN_VELOCITY + random.nextFloat() * (MAX_VELOCITY - MIN_VELOCITY);
        
        // Случайное направление движения (50% шанс на каждое направление)
        if (random.nextBoolean()) velocityX = -velocityX;
        if (random.nextBoolean()) velocityY = -velocityY;
        
        particles.add(new BackgroundParticle(x, y, velocityX, velocityY, PARTICLE_RADIUS, screenWidth, screenHeight));
    }
    
    /**
     * Публичный метод для рендера частиц
     * Вызывается из ScreenMixin после рендера фона
     */
    public void renderParticles(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Получаем размеры экрана
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();
        
        // Инициализируем запретные зоны при первом рендере
        if (!safeZonesInitialized) {
            setupSafeZones();
            safeZonesInitialized = true;
        }
        
        // Спавним частицы при первом запуске
        if (particles.isEmpty()) {
            spawnParticles(screenWidth, screenHeight);
        }
        
        // Поддерживаем постоянное количество частиц - респавним пропавшие
        while (particles.size() < PARTICLE_COUNT) {
            spawnSingleParticle(screenWidth, screenHeight);
        }
        
        // Рендерим соединения между частицами
        renderConnections(context, tickDelta);
        
        // Обновляем и рендерим каждую частицу
        List<BackgroundParticle> particlesToRemove = new ArrayList<>();
        
        for (BackgroundParticle particle : particles) {
            // Обновляем позицию (используем фиксированный deltaTime для плавности)
            particle.update(0.016f); // ~60 FPS
            
            // Проверяем, не вышла ли частица за границы экрана
            if (particle.getX() < -50 || particle.getX() > screenWidth + 50 ||
                particle.getY() < -50 || particle.getY() > screenHeight + 50) {
                // Помечаем для удаления
                particlesToRemove.add(particle);
                continue;
            }
            
            // Проверяем, не вошла ли частица в запретную зону
            checkSafeZoneCollision(particle);
            
            // Рендерим частицу только если она не в запретной зоне
            if (!isInSafeZone(particle.getX(), particle.getY())) {
                int x = (int) particle.getX();
                int y = (int) particle.getY();
                int radius = (int) particle.getRadius();
                
                drawCircle(context, x, y, radius, PARTICLE_COLOR);
            }
        }
        
        // Удаляем частицы, вышедшие за границы
        particles.removeAll(particlesToRemove);
    }
    
    /**
     * Проверяет столкновение частицы с запретной зоной и меняет направление
     */
    private void checkSafeZoneCollision(BackgroundParticle particle) {
        for (Rectangle zone : safeZones) {
            if (zone.contains(particle.getX(), particle.getY())) {
                // Частица вошла в запретную зону - меняем направление
                // Определяем, с какой стороны вошла частица
                float centerX = zone.getX() + zone.getWidth() / 2.0f;
                float centerY = zone.getY() + zone.getHeight() / 2.0f;
                
                float dx = particle.getX() - centerX;
                float dy = particle.getY() - centerY;
                
                // Отталкиваем от ближайшей стороны
                if (Math.abs(dx) > Math.abs(dy)) {
                    // Горизонтальное отталкивание
                    if (dx > 0) {
                        // Справа - двигаем вправо
                        particle.update(1.0f); // Выталкиваем
                    } else {
                        // Слева - двигаем влево
                        particle.update(-1.0f);
                    }
                } else {
                    // Вертикальное отталкивание
                    if (dy > 0) {
                        // Снизу - двигаем вниз
                        particle.update(1.0f);
                    } else {
                        // Сверху - двигаем вверх
                        particle.update(-1.0f);
                    }
                }
                break;
            }
        }
    }
    
    /**
     * Проверяет, находится ли точка в запретной зоне
     */
    private boolean isInSafeZone(float x, float y) {
        for (Rectangle zone : safeZones) {
            if (zone.contains(x, y)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Рендерит соединения между близкими частицами
     */
    private void renderConnections(DrawContext context, float tickDelta) {
        // Проходим по всем парам частиц
        for (int i = 0; i < particles.size(); i++) {
            BackgroundParticle p1 = particles.get(i);
            
            // Пропускаем частицы в запретных зонах
            if (isInSafeZone(p1.getX(), p1.getY())) {
                continue;
            }
            
            for (int j = i + 1; j < particles.size(); j++) {
                BackgroundParticle p2 = particles.get(j);
                
                // Пропускаем частицы в запретных зонах
                if (isInSafeZone(p2.getX(), p2.getY())) {
                    continue;
                }
                
                // Вычисляем расстояние между частицами
                float dx = p2.getX() - p1.getX();
                float dy = p2.getY() - p1.getY();
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                
                // Если расстояние меньше максимального - проверяем пересечение с зонами
                if (distance < MAX_CONNECTION_DISTANCE) {
                    // Проверяем, не пересекает ли линия запретную зону
                    boolean intersects = false;
                    for (Rectangle zone : safeZones) {
                        if (zone.intersectsLine(p1.getX(), p1.getY(), p2.getX(), p2.getY())) {
                            intersects = true;
                            break;
                        }
                    }
                    
                    // Рисуем линию только если она не пересекает запретные зоны
                    if (!intersects) {
                        // Вычисляем прозрачность (чем дальше, тем прозрачнее)
                        float alpha = 1.0f - (distance / MAX_CONNECTION_DISTANCE);
                        int alphaInt = (int) (alpha * 255);
                        
                        // Цвет линии с прозрачностью (белый)
                        int color = (alphaInt << 24) | 0xFFFFFF;
                        
                        // Рисуем линию
                        drawLine(context, (int) p1.getX(), (int) p1.getY(), (int) p2.getX(), (int) p2.getY(), color);
                    }
                }
            }
        }
    }
    
    /**
     * Рисует линию между двумя точками (алгоритм Брезенхема)
     */
    private void drawLine(DrawContext context, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        
        while (true) {
            // Рисуем пиксель
            context.fill(x1, y1, x1 + 1, y1 + 1, color);
            
            if (x1 == x2 && y1 == y2) break;
            
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }
    }
    
    /**
     * Рисует круг (заполненный)
     * Использует только DrawContext.fill() - гарантирует правильный Z-ORDER
     */
    private void drawCircle(DrawContext context, int centerX, int centerY, int radius, int color) {
        // Используем простой алгоритм рисования круга через fill
        // НЕ используем RenderLayer или дополнительные матрицы
        for (int y = -radius; y <= radius; y++) {
            for (int x = -radius; x <= radius; x++) {
                if (x * x + y * y <= radius * radius) {
                    context.fill(centerX + x, centerY + y, centerX + x + 1, centerY + y + 1, color);
                }
            }
        }
    }
}
