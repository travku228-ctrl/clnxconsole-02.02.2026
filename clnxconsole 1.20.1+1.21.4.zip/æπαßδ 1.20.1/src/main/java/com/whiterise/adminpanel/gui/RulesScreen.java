package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.data.ServerRule;
import com.whiterise.adminpanel.data.ServerRules;
import com.whiterise.adminpanel.manager.ColorManager;
import com.whiterise.adminpanel.sound.SoundManager;
import com.whiterise.adminpanel.util.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Экран с правилами сервера
 */
public class RulesScreen extends Screen {
    private final Screen parent;
    
    // Цвета - интегрированы с ColorManager
    private int COLOR_BG_DARKEST() { return ColorManager.getC1().getRGB(); }
    private int COLOR_BG_DARK() { return ColorManager.getC2().getRGB(); }
    private int COLOR_BG_CARD() { return ColorManager.getC3().getRGB(); }
    private int COLOR_BG_HOVER() { return adjustBrightness(ColorManager.getC3().getRGB(), 1.15f); }
    private int COLOR_BORDER() { return ColorManager.getC2().getRGB(); }
    
    // ФИКСИРОВАННЫЕ цвета (не зависят от темы для читаемости)
    private static final int COLOR_SECTION = 0xFFFF8C00;      // Оранжевый (раздел)
    private static final int COLOR_RULE = 0xFF00A8FF;         // Синий (пункт)
    private static final int COLOR_DESCRIPTION = 0xFFE0E0E0;  // Белый (описание)
    private static final int COLOR_DURATION = 0xFFFF4444;     // Красный (наказание)
    private static final int COLOR_EXCEPTION = 0xFFCC6600;    // Темно-оранжевый (исключения)
    private static final int COLOR_ACCENT_FIXED = 0xFF00D9FF; // Фиксированный акцент
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;    // Белый всегда
    private static final int COLOR_TEXT_SECONDARY = 0xFFa0aec0;  // Светло-серый всегда
    
    // Иконки
    private static final Identifier ICON_RULES = new Identifier("whiterise_adminpanel", "textures/icons/rules.png");
    private static final Identifier ICON_CONSOLE = new Identifier("whiterise_adminpanel", "textures/icons/console.png");
    private static final Identifier ICON_PLAYERS = new Identifier("whiterise_adminpanel", "textures/icons/players.png");
    private static final Identifier ICON_SHIELD = new Identifier("whiterise_adminpanel", "textures/icons/shield.png");
    private static final Identifier ICON_ISSUED = new Identifier("whiterise_adminpanel", "textures/icons/issued.png");
    private static final Identifier ICON_GUI_SETTINGS = new Identifier("whiterise_adminpanel", "textures/icons/gui_settings.png");
    
    // Данные
    private List<ServerRule> allRules;
    private List<ServerRule> filteredRules;
    private int scrollOffset = 0;
    private int maxScroll = 0;
    
    // Поиск
    private TextFieldWidget searchField;
    private String lastSearch = "";
    
    public RulesScreen(Screen parent) {
        super(Text.literal("Правила сервера"));
        this.parent = parent;
    }

    
    @Override
    protected void init() {
        // Загружаем правила
        allRules = ServerRules.getAllRules();
        filteredRules = new ArrayList<>(allRules);
        
        // Поле поиска (вернули обратно)
        int searchWidth = 300;
        int searchX = this.width / 2 - searchWidth / 2;
        int searchY = 70;
        
        // ИСПРАВЛЕНО: правильная позиция текста с учетом иконки
        int iconWidth = this.textRenderer.getWidth("🔍");
        searchField = new TextFieldWidget(this.textRenderer, searchX + iconWidth + 10, searchY + 8, searchWidth - iconWidth - 15, 20, Text.literal("Поиск"));
        searchField.setPlaceholder(Text.literal("Поиск по правилам (Ctrl+F)..."));
        searchField.setMaxLength(100);
        searchField.setChangedListener(this::onSearchChanged);
        searchField.setDrawsBackground(false);
        addDrawableChild(searchField);
    }
    
    private void onSearchChanged(String search) {
        lastSearch = search.toLowerCase();
        filterRules();
    }
    
    private void filterRules() {
        if (lastSearch.isEmpty()) {
            filteredRules = new ArrayList<>(allRules);
        } else {
            filteredRules = new ArrayList<>();
            // Ищем правила которые содержат поисковый запрос
            // Если найдено совпадение, добавляем весь блок (RULE + DESCRIPTION + DURATION + EXCEPTION)
            for (int i = 0; i < allRules.size(); i++) {
                ServerRule rule = allRules.get(i);
                
                // Если это SECTION или SEPARATOR, добавляем как есть
                if (rule.getType() == ServerRule.RuleType.SECTION || 
                    rule.getType() == ServerRule.RuleType.SEPARATOR) {
                    filteredRules.add(rule);
                    continue;
                }
                
                // Если это RULE, проверяем совпадение и добавляем весь блок
                if (rule.getType() == ServerRule.RuleType.RULE) {
                    boolean matches = rule.getContent().toLowerCase().contains(lastSearch);
                    
                    // Проверяем также следующие элементы (DESCRIPTION, DURATION, EXCEPTION)
                    if (!matches) {
                        for (int j = i + 1; j < allRules.size(); j++) {
                            ServerRule nextRule = allRules.get(j);
                            if (nextRule.getType() == ServerRule.RuleType.RULE || 
                                nextRule.getType() == ServerRule.RuleType.SECTION ||
                                nextRule.getType() == ServerRule.RuleType.SEPARATOR) {
                                break;
                            }
                            if (nextRule.getContent().toLowerCase().contains(lastSearch)) {
                                matches = true;
                                break;
                            }
                        }
                    }
                    
                    // Если найдено совпадение, добавляем весь блок
                    if (matches) {
                        filteredRules.add(rule);
                        // Добавляем все связанные элементы
                        for (int j = i + 1; j < allRules.size(); j++) {
                            ServerRule nextRule = allRules.get(j);
                            if (nextRule.getType() == ServerRule.RuleType.RULE || 
                                nextRule.getType() == ServerRule.RuleType.SECTION ||
                                nextRule.getType() == ServerRule.RuleType.SEPARATOR) {
                                break;
                            }
                            filteredRules.add(nextRule);
                        }
                    }
                }
            }
        }
        scrollOffset = 0;
        calculateMaxScroll();
    }

    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Градиентный фон как во всех экранах
        context.fillGradient(0, 0, this.width, this.height, COLOR_BG_DARKEST(), COLOR_BG_DARK());
        
        // ВЕРХНЯЯ ПАНЕЛЬ НАВИГАЦИИ
        renderTopNavigationBar(context, mouseX, mouseY);
        
        // Заголовок с иконкой (под верхней панелью)
        int titleY = 60;
        int iconSize = 16;
        int titleX = 20;
        
        // Иконка
        context.drawTexture(ICON_RULES, titleX, titleY - 2, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Текст заголовка
        String title = "Правила сервера";
        context.drawText(this.textRenderer, title, titleX + iconSize + 5, titleY, COLOR_SECTION, false);
        
        // Поле поиска
        renderSearchField(context, mouseX, mouseY, delta);
        
        // Рендерим контент с правилами
        renderRulesContent(context, mouseX, mouseY);
        
        super.render(context, mouseX, mouseY, delta);
    }
    
    /**
     * Рендерит верхнюю панель навигации
     */
    private void renderTopNavigationBar(DrawContext context, int mouseX, int mouseY) {
        int barHeight = 50;
        
        // Фон панели
        context.fillGradient(0, 0, this.width, barHeight, COLOR_BG_CARD(), COLOR_BG_DARK());
        
        // Нижняя граница
        context.fill(0, barHeight, this.width, barHeight + 2, COLOR_BORDER());
        
        // Кнопки (6 кнопок: Консоль, Игроки, Проверка, Выданные, Правила, Интерфейс)
        int buttonWidth = 130;
        int buttonHeight = 35;
        int buttonSpacing = 10;
        int totalWidth = buttonWidth * 6 + buttonSpacing * 5;
        int startX = (this.width - totalWidth) / 2;
        int buttonY = (barHeight - buttonHeight) / 2;
        
        // Кнопка 1: Консоль
        renderTopBarButton(context, startX, buttonY, buttonWidth, buttonHeight, "Консоль", mouseX, mouseY, false, ICON_CONSOLE);
        
        // Кнопка 2: Игроки
        int button2X = startX + buttonWidth + buttonSpacing;
        renderTopBarButton(context, button2X, buttonY, buttonWidth, buttonHeight, "Игроки", mouseX, mouseY, false, ICON_PLAYERS);
        
        // Кнопка 3: Проверка
        int button3X = button2X + buttonWidth + buttonSpacing;
        renderTopBarButton(context, button3X, buttonY, buttonWidth, buttonHeight, "Проверка", mouseX, mouseY, false, ICON_SHIELD);
        
        // Кнопка 4: Выданные
        int button4X = button3X + buttonWidth + buttonSpacing;
        renderTopBarButton(context, button4X, buttonY, buttonWidth, buttonHeight, "Выданные", mouseX, mouseY, false, ICON_ISSUED);
        
        // Кнопка 5: Правила (активная)
        int button5X = button4X + buttonWidth + buttonSpacing;
        renderTopBarButton(context, button5X, buttonY, buttonWidth, buttonHeight, "Правила", mouseX, mouseY, true, ICON_RULES);
        
        // Кнопка 6: Интерфейс
        int button6X = button5X + buttonWidth + buttonSpacing;
        renderTopBarButton(context, button6X, buttonY, buttonWidth, buttonHeight, "Интерфейс", mouseX, mouseY, false, ICON_GUI_SETTINGS);
    }
    
    /**
     * Рендерит кнопку верхней панели с иконкой
     */
    private void renderTopBarButton(DrawContext context, int x, int y, int width, int height, String text, int mouseX, int mouseY, boolean isActive, Identifier icon) {
        boolean isHovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        
        // Фон кнопки (активная кнопка всегда подсвечена)
        int bgColor;
        if (isActive) {
            bgColor = COLOR_BG_HOVER(); // Активная кнопка
        } else {
            bgColor = isHovered ? COLOR_BG_HOVER() : COLOR_BG_DARKEST();
        }
        RenderUtils.fillRounded(context, x, y, width, height, 8, bgColor);
        
        // Границы (активная кнопка с акцентной границей)
        int borderColor;
        if (isActive) {
            borderColor = COLOR_ACCENT_FIXED; // Фиксированный акцент - активная кнопка
        } else {
            borderColor = isHovered ? COLOR_ACCENT_FIXED : COLOR_BORDER();
        }
        RenderUtils.drawRoundedBorder(context, x, y, width, height, 8, borderColor);
        
        // Иконка слева
        int iconSize = 24;
        int iconX = x + 15;
        int iconY = y + (height - iconSize) / 2;
        context.drawTexture(icon, iconX, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Текст справа от иконки
        int textX = iconX + iconSize + 8;
        int textY = y + (height - 8) / 2;
        int textColor;
        if (isActive) {
            textColor = 0xFFFFFFFF; // Активная кнопка
        } else {
            textColor = isHovered ? 0xFFFFFFFF : 0xFFa0aec0;
        }
        context.drawText(this.textRenderer, text, textX, textY, textColor, false);
    }
    
    /**
     * Рендерит поле поиска
     */
    private void renderSearchField(DrawContext context, int mouseX, int mouseY, float delta) {
        int searchWidth = 300;
        int searchX = this.width / 2 - searchWidth / 2;
        int searchY = 70;
        int searchHeight = 25;
        
        boolean isHovered = mouseX >= searchX && mouseX <= searchX + searchWidth && 
                           mouseY >= searchY && mouseY <= searchY + searchHeight;
        
        // Фон поля - чуть ярче при фокусе
        int bgColor = searchField.isFocused() ? adjustBrightness(COLOR_BG_CARD(), 1.1f) : COLOR_BG_CARD();
        RenderUtils.fillRounded(context, searchX, searchY, searchWidth, searchHeight, 8, bgColor);
        
        // Границы - чуть ярче при фокусе/наведении
        int borderColor = (searchField.isFocused() || isHovered) ? adjustBrightness(COLOR_BORDER(), 1.3f) : COLOR_BORDER();
        RenderUtils.drawRoundedBorder(context, searchX, searchY, searchWidth, searchHeight, 8, borderColor);
        
        // Иконка поиска
        int iconX = searchX + 5;
        int iconY = searchY + (searchHeight - 8) / 2;
        context.drawText(this.textRenderer, "🔍", iconX, iconY, 0xFFa0aec0, false);
    }
    
    private void renderRulesContent(DrawContext context, int mouseX, int mouseY) {
        int contentX = 20;
        int contentY = 110; // Под поиском
        int contentWidth = this.width - 40;
        int contentHeight = this.height - 130;
        
        // Включаем scissor для обрезки при скролле
        context.enableScissor(contentX, contentY, contentX + contentWidth, contentY + contentHeight);
        
        int y = contentY - scrollOffset;
        
        for (ServerRule rule : filteredRules) {
            if (y > contentY - 50 && y < contentY + contentHeight) {
                y += renderRule(context, rule, contentX, y, contentWidth);
            } else {
                y += getRuleHeight(rule);
            }
        }
        
        context.disableScissor();
        
        // Вычисляем максимальный скролл
        calculateMaxScroll();
        
        // Визуализация скролла (как в логах чата)
        if (maxScroll > 0) {
            int scrollBarX = this.width - 25;
            int scrollBarY = contentY;
            int scrollBarHeight = contentHeight;
            int scrollBarWidth = 4;
            
            // Фон скроллбара
            context.fill(scrollBarX, scrollBarY, scrollBarX + scrollBarWidth, scrollBarY + scrollBarHeight, 0x40FFFFFF);
            
            // Ползунок скроллбара
            float scrollPercentage = (float) scrollOffset / maxScroll;
            int thumbHeight = Math.max(20, (int) ((float) scrollBarHeight * ((float) scrollBarHeight / (scrollBarHeight + maxScroll))));
            int thumbY = scrollBarY + (int) (scrollPercentage * (scrollBarHeight - thumbHeight));
            
            context.fill(scrollBarX, thumbY, scrollBarX + scrollBarWidth, thumbY + thumbHeight, COLOR_ACCENT_FIXED);
        }
    }
    
    /**
     * Изменяет яркость цвета
     */
    private int adjustBrightness(int color, float factor) {
        int a = (color >> 24) & 0xFF;
        int r = (int) Math.min(255, ((color >> 16) & 0xFF) * factor);
        int g = (int) Math.min(255, ((color >> 8) & 0xFF) * factor);
        int b = (int) Math.min(255, (color & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    
    private int renderRule(DrawContext context, ServerRule rule, int x, int y, int width) {
        switch (rule.getType()) {
            case SECTION:
                // Раздел - оранжевый цвет
                context.drawText(this.textRenderer, rule.getContent(), x, y, COLOR_SECTION, false);
                return 20;
                
            case RULE:
                // Пункт правила - голубой цвет с пробелом после номера
                String ruleText = rule.getContent();
                // Добавляем пробел после номера если его нет
                if (!ruleText.contains(" ")) {
                    ruleText = ruleText + " ";
                }
                context.drawText(this.textRenderer, ruleText, x, y, 0xFF00A8FF, false); // Голубой
                return 15;
                
            case DESCRIPTION:
                // Описание - белый текст, переносится
                List<String> wrapped = wrapText(rule.getContent(), width);
                int totalHeight = 0;
                for (String line : wrapped) {
                    context.drawText(this.textRenderer, line, x, y + totalHeight, COLOR_DESCRIPTION, false);
                    totalHeight += 10;
                }
                return totalHeight + 5;
                
            case DURATION:
                // Наказание - красный цвет, переносится
                List<String> wrappedDur = wrapText(rule.getContent(), width);
                int durHeight = 0;
                for (String line : wrappedDur) {
                    context.drawText(this.textRenderer, line, x, y + durHeight, 0xFFFF4444, false); // Красный
                    durHeight += 10;
                }
                return durHeight + 5;
                
            case EXCEPTION:
                // Исключения/запрещенные моды - темно-оранжевый цвет, переносится
                List<String> wrappedEx = wrapText(rule.getContent(), width);
                int totalHeightEx = 0;
                for (String line : wrappedEx) {
                    context.drawText(this.textRenderer, line, x, y + totalHeightEx, 0xFFCC6600, false); // Темно-оранжевый
                    totalHeightEx += 10;
                }
                return totalHeightEx + 5;
                
            case SEPARATOR:
                // Разделитель - линия между разделами
                context.fill(x, y + 5, x + width, y + 7, 0xFF2a3441);
                return 15;
        }
        return 10;
    }

    
    private int getRuleHeight(ServerRule rule) {
        switch (rule.getType()) {
            case SECTION: return 20;
            case RULE: return 15; // Фиксированная высота для номера
            case DESCRIPTION: return wrapText(rule.getContent(), this.width - 40).size() * 10 + 5;
            case DURATION: return wrapText(rule.getContent(), this.width - 40).size() * 10 + 5;
            case EXCEPTION: return wrapText(rule.getContent(), this.width - 40).size() * 10 + 5;
            case SEPARATOR: return 15;
        }
        return 10;
    }
    
    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        String[] words = text.split(" ");
        StringBuilder currentLine = new StringBuilder();
        
        for (String word : words) {
            String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
            if (this.textRenderer.getWidth(testLine) <= maxWidth) {
                if (currentLine.length() > 0) currentLine.append(" ");
                currentLine.append(word);
            } else {
                if (currentLine.length() > 0) {
                    lines.add(currentLine.toString());
                    currentLine = new StringBuilder(word);
                } else {
                    lines.add(word);
                }
            }
        }
        if (currentLine.length() > 0) {
            lines.add(currentLine.toString());
        }
        return lines;
    }
    
    private void calculateMaxScroll() {
        int totalHeight = 0;
        for (ServerRule rule : filteredRules) {
            totalHeight += getRuleHeight(rule);
        }
        int contentHeight = this.height - 130;
        maxScroll = Math.max(0, totalHeight - contentHeight + 20);
    }

    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        int scrollAmount = (int)(-amount * 20);
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset + scrollAmount));
        return true;
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Ctrl+F для фокуса на поиске
        if (keyCode == 70 && (modifiers & 2) != 0) { // F + Ctrl
            searchField.setFocused(true);
            return true;
        }
        // ESC для выхода
        if (keyCode == 256) { // ESC
            this.client.setScreen(parent);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Обработка кликов по верхней панели
        if (handleTopBarClick(mouseX, mouseY)) {
            return true;
        }
        
        // ПКМ по полю поиска - очистить
        if (button == 1) {
            int searchWidth = 300;
            int searchX = this.width / 2 - searchWidth / 2;
            int searchY = 70;
            int searchHeight = 25;
            
            if (mouseX >= searchX && mouseX <= searchX + searchWidth && 
                mouseY >= searchY && mouseY <= searchY + searchHeight) {
                searchField.setText("");
                SoundManager.playClickSound();
                return true;
            }
        }
        
        return super.mouseClicked(mouseX, mouseY, button);
    }
    
    /**
     * Обработка кликов по верхней панели
     */
    private boolean handleTopBarClick(double mouseX, double mouseY) {
        int barHeight = 50;
        
        if (mouseY < 0 || mouseY > barHeight) {
            return false;
        }
        
        int buttonWidth = 130;
        int buttonHeight = 35;
        int buttonSpacing = 10;
        int totalWidth = buttonWidth * 6 + buttonSpacing * 5;
        int startX = (this.width - totalWidth) / 2;
        int buttonY = (barHeight - buttonHeight) / 2;
        
        // Кнопка 1: Консоль
        if (mouseX >= startX && mouseX <= startX + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new ConsoleScreen(parent));
            return true;
        }
        
        // Кнопка 2: Игроки
        int button2X = startX + buttonWidth + buttonSpacing;
        if (mouseX >= button2X && mouseX <= button2X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            AdminPanelScreen screen = new AdminPanelScreen();
            screen.setCurrentTab("players");
            this.client.setScreen(screen);
            return true;
        }
        
        // Кнопка 3: Проверка
        int button3X = button2X + buttonWidth + buttonSpacing;
        if (mouseX >= button3X && mouseX <= button3X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            AdminPanelScreen screen = new AdminPanelScreen();
            screen.setCurrentTab("anticheat");
            this.client.setScreen(screen);
            return true;
        }
        
        // Кнопка 4: Выданные
        int button4X = button3X + buttonWidth + buttonSpacing;
        if (mouseX >= button4X && mouseX <= button4X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            AdminPanelScreen screen = new AdminPanelScreen();
            screen.setCurrentTab("issued");
            this.client.setScreen(screen);
            return true;
        }
        
        // Кнопка 5: Правила (текущий экран)
        int button5X = button4X + buttonWidth + buttonSpacing;
        if (mouseX >= button5X && mouseX <= button5X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            // Уже на экране правил
            return true;
        }
        
        // Кнопка 6: Интерфейс
        int button6X = button5X + buttonWidth + buttonSpacing;
        if (mouseX >= button6X && mouseX <= button6X + buttonWidth && 
            mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
            SoundManager.playClickSound();
            this.client.setScreen(new InterfaceScreen(parent));
            return true;
        }
        
        return false;
    }
}

