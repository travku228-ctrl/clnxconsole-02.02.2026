package com.whiterise.adminpanel.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;

/**
 * Утилита для работы с кастомными шрифтами
 * 
 * ПРИМЕЧАНИЕ: Из-за ограничений Minecraft 1.20.1 и обфускации,
 * кастомный шрифт можно применить только глобально через default.json
 * или использовать стандартный TextRenderer.
 * 
 * Для применения Inter только в GUI мода, используйте resource pack
 * который игрок может включить/выключить по желанию.
 */
public class CustomFontRenderer {
    /**
     * Получает TextRenderer для GUI мода
     * Возвращает стандартный шрифт Minecraft
     * 
     * Для использования кастомного шрифта Inter:
     * 1. Создайте resource pack с assets/minecraft/font/default.json
     * 2. Скопируйте туда конфигурацию из assets/whiterise_adminpanel/font/inter.json
     * 3. Включите resource pack в настройках игры
     */
    public static TextRenderer getMontserrat() {
        return MinecraftClient.getInstance().textRenderer;
    }
    
    /**
     * Сбрасывает кеш шрифта (для перезагрузки)
     */
    public static void reset() {
        // Placeholder для будущего функционала
    }
}
