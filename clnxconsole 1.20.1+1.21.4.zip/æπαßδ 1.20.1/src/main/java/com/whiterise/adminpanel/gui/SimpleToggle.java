package com.whiterise.adminpanel.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

public class SimpleToggle extends ClickableWidget {
    private boolean enabled;
    
    public SimpleToggle(int x, int y, int width, int height, boolean initialState) {
        super(x, y, width, height, Text.empty());
        this.enabled = initialState;
    }
    
    @Override
    public void renderButton(DrawContext context, int mouseX, int mouseY, float delta) {
        // 1. Фон переключателя
        int bgColor = enabled ? 0xFF4CAF50 : 0xFF757575; // Зеленый / Серый
        context.fill(getX(), getY(), getX() + width, getY() + height, bgColor);
        
        // 2. Белый ползунок
        int sliderSize = height - 6;
        int sliderX = enabled ? getX() + width - sliderSize - 3 : getX() + 3;
        int sliderY = getY() + 3;
        context.fill(sliderX, sliderY, sliderX + sliderSize, sliderY + sliderSize, 0xFFFFFFFF);
        
        // 3. Текст состояния (опционально)
        var mc = MinecraftClient.getInstance();
        String state = enabled ? "ON" : "OFF";
        int textX = enabled ? getX() - 25 : getX() + width + 5;
        context.drawText(mc.textRenderer, state, textX, getY() + height/2 - 4, bgColor, false);
    }
    
    @Override
    public void onClick(double mouseX, double mouseY) {
        this.enabled = !enabled;
    }
    
    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE, 
            Text.literal("Toggle: " + (enabled ? "ON" : "OFF")));
    }
    
    public boolean isEnabled() {
        return enabled;
    }
}
