package com.whiterise.adminpanel.data;

import java.util.ArrayList;
import java.util.List;

public class ServerRules {
    
    public static List<ServerRule> getAllRules() {
        List<ServerRule> rules = new ArrayList<>();
        
        // 📕 Основные правила проекта
        rules.add(new ServerRule(ServerRule.RuleType.SECTION, "📕 Основные правила проекта"));
        rules.add(new ServerRule(ServerRule.RuleType.SEPARATOR, ""));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Каждый игрок проекта автоматически соглашается с правилами, принимая на себя полную ответственность за свои действия, нарушения, включая попытки их совершения, караются в соответствии с таблицей поступка — Администрация не признает шуток, сарказма или «проверок границ», любое нарушение, даже в «шуточной» форме, трактуется как прямое и наказывается — Ответственность за любой некорректный поступок, вплоть до наказания на игровом аккаунте, несет владелец аккаунта."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.1.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Решения главной администрации (b3zey, pupilResize, DarkStar, president, stylerussian) абсолютны и не обсуждаются, они вправе применять наказания вне рамок данных правил, если сочтут действия игрока враждебными для проекта."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Все платежи на проекте считаются безвозвратными пожертвованиями, ошибки при переводе, изменение мнения или блокировка аккаунта не являются основанием для возврата средств."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.3"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Взаимодействие администрации (модератор, админ, куратор, заместитель куратора, младший администратор) имеет право требовать устранения дополнительного по, не действия не регулируются общими правилами."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.4"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Обжалование наказания возможно только в течение 3-ех дней с момента его получения, подача жалобы не гарантирует его отмену."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.5"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Администрация не гарантирует бесперебойную работу сервера и не компенсирует ущерб, вызванный им. — Сбоями в работе сети или оборудования — Ошибками пользователей (удаление предметов, смерть игрока и т.д) — Действиями злоумышленников (DDoS, взломы и т.д)"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.6"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Нулевая терпимость к угрозам и атакам — Угрозы в любой форме (в т.ч внутренние) — Doxxing, Swatting, DDoS-атаки на сервер, игроков или администрацию — Попытки взлома или дестабилизации работы проекта"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Перманентный бан без возможности обжалования — Внесение в черный список проекта — Передача данных в правоохранительные органы (в случае реальных угроз)"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.6.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Угрозы и вымогательство в адрес администрации — Любые угрозы, шантаж или давление на администрацию караются перманентным баном и внесением в черный список."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "1.7"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Администрация оставляет за собой право изменять правила без предварительного уведомления. Незнание правил не освобождает от ответственности."));
        
        // 📗 Внутриигровые правила
        rules.add(new ServerRule(ServerRule.RuleType.SECTION, "📗 Внутриигровые правила"));
        rules.add(new ServerRule(ServerRule.RuleType.SEPARATOR, ""));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Выдача себя за администрацию или же за модератора Запрещено — Утверждать, что вы имеете доступ к админке или модератор (даже на втором аккаунте) — Угрожать банами, мутами или кикам от имени администрации — Провоцировать проверки с ложными заявлениями"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Блокировка на 1 день. (при рецидиве на 7 дней)"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Торговля игровыми ресурсами Запрещено — Продажа, покупка ресурсов, привилегий, аккаунтов за реальные деньги вне официального сайта — Содействие в таких сделках (посредничество, реклама)"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Перманентный бан всех связанных аккаунтов, полный снос регионов, привилегий и игрового прогресса, внесение в черный список"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Примечание — Взлом или передача аккаунта не снимают ответственности с владельца — Сделанный ущерб проекту (найдено, дюп) приводит к безвозвратной блокировке"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.2.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Взлом или попытка взлома чужих аккаунтов"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: ЧС(Обнуление)+Перманентный бан"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.3"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Запрещенное строительство — Не допускается порнографические объекты, нацистская символика, пенисы/ты"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 3 дня. + снос постройки"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.4"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Использование читов или запрещенного по Категорический запрет на — Чит-клиенты, макросы, скрипты (AHK), моды с преимуществом (Список ниже) — Отключение служб (SysMain, PcaSvc, EventLog) для уклонения от проверки или для увеличения фпс — Очистка файлов (ShellBag и.т.п) менее чем за 1 день. до начала проверки"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Нарушение отключение служб Предупреждение: Повторная проверка | Бан 14 дней. — Очистка запрещенных модов (Список ниже) - Бан на 21 день. — Услуги от проверки или лив - Бан на 21 день. — Признание на проверке - Бан на 14 дней — Чит-клиенты и другое запрещенное ПО - Бан на 21 дней"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Список запрещенных модификаций и скриптов:"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "FuturSwap, ArmorHotSwap, SlipperyMod, StepUpMod, InvMove, InventoryTotem, CleanOut, GrasssBypass, AimAssistance, AutoLoot, ZerguldCheatMods, DiamondScan, X-Mod, CheatLobby, InventoryProfilesNext, BankoruFabellone, NoClipFly.Mod, FreeCam, PlayerHighlighter, AutoClicker, AttackAura, TriggerBot, AutoRun, InventoryMove, ElytraHack, EntityOutliner, ShiftTap, AutoLeave, Swapper, ClickPerl и многобойные моды."));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Исключение: Auto-Fish."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.4.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Ложный вызов модерации (дрек) — Более 2 ложных вызовов модерации"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 3 часа"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.4.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Тим с читером Игра в команде с читером (если его вина доказана) (Бан за 2.4.2 выдается только если у забаненного от рока бан по 2-й)"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 14 дней"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.4.3"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Обход бана — Использование более 2 аккаунтов для обхода наказания по пункту 2.4"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 42 дн."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.4.4"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Использование багов или уязвимостей — Дюп, абуз багов, нарушение экономики"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан навсегда/Черный список проекта"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.5"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Вредительство серверу — Лаг-машины, дисбалансы предметы"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 20 дней. — Занятие которые не ружают сервер | Бан на 12 дней. — Травля с армор-стендами/Нагружающих сервер/Ваготелки с прекамп/Футуристами | Снос варпа + Бан на 3 дня. — Закрытая варпа, выход должен быть 3х3, в выходом в мир, ничего не должно мешать выходу | Снос варпа + Бан на 1 день. — Распространение уязвимостей (багов, дюпов) Среди других игроков | Бан навсегда. — Взлом вагонеток до 30 блоков от варпа | Бан на 3 дня. — Использование недоработок правил, абуз правил для получения выгоды | Бан на 14 дней/Наказание"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.6"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Никнеймы титулы и профессы Запрещены — Мат, оскорбления, отсылки к читам, чужим проектам, имитация ников администрации, профессы/титулы которые помогут таб"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Перманентный бан — Если через лист - Бан на 1 день"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Исключение: Бан не выдается, если игрока запрещенный ник через лист"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Примеры нарушений: RichFree24124, ProHvhWestSide, CelestialJose, CellusPensi, XyiBoards, PenisJevsyaMs, VaginaMachine, TrashNegro WellnineRp и т.д"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.7"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Злоупотребление командами (/fly, /god, /vanish, /jump, и др) — Использование для вайп рыча или помех другим и на ивентах/подбирание ресурсов."));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 3 дня Повторное нарушение — Снятие подписки без возврата"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "2.8"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Аморальные кланы — Политические, военные названия (RussianVPN, UkraineVPN)"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: На первый раз предупреждение + удаление клана, следующий раз Бан на 7 дней."));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Исключение: Ukraine, Russian, Mongols, Avitancu."));
        
        // ⚠️ Правила чата
        rules.add(new ServerRule(ServerRule.RuleType.SECTION, "⚠️ Правила чата"));
        rules.add(new ServerRule(ServerRule.RuleType.SEPARATOR, ""));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Реклама сторонних проектов — Упоминать другие сервера, youtube каналы, соцсети (кроме tiktok, youtube с донатом) — Прямые или скрытые призывы перейти на иные платформы"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Реклама перманентный бан — Случайное упоминание без цели рекламы мут на 3 часа"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Использование CapsLock — Сообщение, где 50% текста или 10 символов написаны в верхнем регистре"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 30 минут"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.2.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Попрошайничество — Просьба выделить привилегии, ресурсы."));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 1 час"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Исключение: «всем пис», «всерия росса»"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.2.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Обход мута — Использование команд объявления, клан чата, создание кланов с сообщениями и т.д для чата во время мута"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 1 час. по айпи."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.3"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Спам и флуд — Спам 3+ одинаковых сообщения подряд (в одну минуту) — Флуд бессмысленных сообщениями от 12+ символов"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 1 час"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.4"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Оскорбление игроков Запрещено — Личные оскорбления, унижения, провокации"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 3 часа — Мут на 6 часов (систематическое исключениями)"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Исключение: Анэлинг, Школьник, Бот, Краса, Еза (azka, ezz), Синтак, Нуб, Фрик, Нулина (0), Нытик, Рак, Обезьяна, Пиявка, Фемка, Фэмменистка, Слабак, Животное, Божок, Лох, Дурак, Идиот."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.5"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Оскорбление администрации или проекта — Критика в грубой форме, неуважительные высказывания"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Обычный состав (Хелпера до Мл Админов) мут на 12 часов — Высшая администрация (выше Зам.Куратора) — бан на 3 дня"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.6"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Оскорбление родных — Упоминание семьи, родственников в негативном ключе, завуалированное упоминание"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 12 часов"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.7"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "организация флуда — Координация массового спама, флуда"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 1 час"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.8"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Дискриминация — Расизм, гомофобия, шейминг по внешности, здоровью и т.д"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 3 часа"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.9.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Нацизм, расизм, наркотики, оружие — Запрещена нацизм, расизм, пропаганда наркотиков и оружия, а также дискриминация и призывы к их использованию."));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 8 часов"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.9.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Терроризм — Запрещена пропаганда, оправдание или призыв к терроризму, распространение материалов о насилии, взрывах, диверсиях и участие в обсуждениях, поддерживающих экстремистские организации."));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 12 часов"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.9.3"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Политические призывы — Запрещена политическая агитация, пропаганда партий, движений, лидеров или идеологий, призывы к участию в митингах, референдумах и иных политических акциях, а также разжигание социальной, политической или международной напряженности через высказывания, ненависть или игровые действия."));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 12 часов"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.10"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Ложные угрозы — Угрозы типа «тебя забанят», «админка, накажите его»"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Бан на 3 часа"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.11"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Доксинг/Сваттинг — Угрозы раскрыть личные данные, IP-адрес, место жительства и т.д"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Перманентный бан + внесение в черный список — Возможна передача данных правоохранительным органам"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.12"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Ввод в рожок в заблуждение — Изменять лист админа/просто писать в чат неправдивую информацию"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 6 часов"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.13"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Сообщение сексуального характера/посыла — Писать в чат сообщения которые несут за собой сексуальный посыл"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 3 часа"));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "3.14"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Подстрекать на нарушение правил — Писать игрокам чтоб они нарушали правила/подстрекали на нарушение"));
        rules.add(new ServerRule(ServerRule.RuleType.DURATION, "Наказание: Мут на 6 часов"));
        
        // 📙 Общие положения
        rules.add(new ServerRule(ServerRule.RuleType.SECTION, "📙 Общие положения"));
        rules.add(new ServerRule(ServerRule.RuleType.SEPARATOR, ""));
        
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Администрация проекта оставляет за собой право выдавать любого игрока на проверку в любое время для попытки обнаружения запрещенного ПО. Модерация на проверке имеет право занять и посмотреть модификацию и ПК игрока. Ложные сообщения о Чит-клиентах и мессенджерах. Проверки проводятся исключительно один на один, администратору запрещено требовать созвания ПО вне официального списка."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "4.1"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Общие положения — Проверка осуществляется только СТ, Хелперами, Модераторами и выше. — Запрещено демонстрировать экран проверки третьим лицам. — Проверка проводится строго по регламенту."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "4.2"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Разрешенное ПО для проверки Модератор может запросить установку только следующих программ:"));
        rules.add(new ServerRule(ServerRule.RuleType.EXCEPTION, "Anydesk, Rudesk, RustDesktop, Fluidly Checker, Everything, RegScanner, BamParser, LastActivity, Shellbag, RecentFilesView, BrowserDownloadsView, UsbDevineLоg, ExecutedProgramList, System Informer/Process Hacker, Journal Trace, echo strings scanner, Ocean, Simple Unlocker, Recaf, Holycheck, RCornd, PathParser, Napolit checker, Prefetch Parser, Registry Explorer, AMcache Parser, JumpList Explorer, Recuva, FTK Imager, Bypass checks, path scanner, InjectedDLL, Sybtime Text, Notepad++, BrowsingHistoryView, CachedProgramList, InjGen."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "4.3"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Правила отказа проверки Игрок имеет право на мгновенный отказ (Alt-z или Alt+Shift+F10) только раз. — Проверке вне регламента или с превышением полномочий — Давление, угрозы или принуждение — Нарушение приватности (личные данные, пароли, переписки)"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Если отказ совершен без причины, действия от рока считаются недействительным полномочием > блокировка аккаунта на 21 день по пункту 2.4."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "4.4"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Недопустимое поведение игрока Запрещено: — Оскорблять или провоцировать модератора — Намеренно прерывать проверку — Игнорировать указания или саботировать — Намеренно затягивать время проверки"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "За каждое нарушение игрок получает предупреждение (1/2). При 2/2 — блокировка аккаунта на 21 день по пункту 2.4."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "4.5"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Дополнительные условия — Все проверки записываются (видео, скриншоты, логи). — Жалобы на модератора подаются строго через раздел «Жалобы». — Модераторы и медиа-персонал обязаны соблюдать все правила сервера."));
        
        rules.add(new ServerRule(ServerRule.RuleType.RULE, "4.6"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Регламент при покупке рыбалки"));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "24-часовой иммунитет от проверки (Не распространяется на администрацию проекта.) Игрока нельзя вызывать на проверку в течение 24 часов после покупки рыбалки. Исключение составляют только подозрения в использовании читов-читов."));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Запрет на повторный бан по старой причине После рыбалки, при повторной проверке, игрока не могут забанить по той же причине, что и ранее. Это также означает, что если игрок удалил читы, его нельзя банить за счету их очистку. Банить можно только в том случае, если он запускал читы после покупки рыбалки, новое запрещенное ПО или мейнкрафт с читами на компьютере игрока другого, который не был в самом ПО."));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Обязанность модератора перед проверкой При вызове на проверку модератор должен убедиться (команда внутренними командами, например, проверки логи), что игрок не будет подвергнут бану по той же причине, которая фигурировала в предыдущем бане."));
        rules.add(new ServerRule(ServerRule.RuleType.DESCRIPTION, "Администрация вправе удостоверить наказание за систематические нарушения регламента."));
        
        return rules;
    }
}
