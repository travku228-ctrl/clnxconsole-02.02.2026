package com.whiterise.adminpanel.manager;

import com.whiterise.adminpanel.data.ChatLogEntry;

import java.util.*;

/**
 * МИНИМАЛЬНЫЙ менеджер логов чата
 * Singleton, хранит в памяти, очищается при disconnect/shutdown
 */
public class ChatLogManager {
    private static final int MAX_LOGS = 2000; // Максимум сообщений
    
    private final LinkedList<ChatLogEntry> logs = new LinkedList<>();
    private final Set<String> recentHashKeys = new HashSet<>(); // Для дедупликации
    
    /**
     * Добавляет сообщение с Text объектом (с цветами)
     */
    public void addMessage(net.minecraft.text.Text message) {
        if (message == null) {
            return;
        }
        
        String rawText = message.getString();
        if (rawText == null || rawText.isEmpty()) {
            return;
        }
        
        // Создаем entry с Text объектом
        ChatLogEntry entry = new ChatLogEntry(rawText, message);
        
        // ДЕДУПЛИКАЦИЯ: проверяем hashKey
        String hashKey = entry.getHashKey();
        if (recentHashKeys.contains(hashKey)) {
            return; // Дубликат в течение той же секунды
        }
        
        // Добавляем в логи
        logs.addFirst(entry); // Новые сверху
        recentHashKeys.add(hashKey);
        
        // Ограничиваем размер
        if (logs.size() > MAX_LOGS) {
            ChatLogEntry removed = logs.removeLast();
            recentHashKeys.remove(removed.getHashKey());
        }
        
        // Очищаем старые hashKeys (старше 2 секунд)
        cleanOldHashKeys();
    }
    
    /**
     * Добавляет RAW сообщение в логи
     * БЕЗ парсинга, БЕЗ фильтрации - как есть
     */
    public void addRawMessage(String rawText) {
        if (rawText == null || rawText.isEmpty()) {
            return;
        }
        
        // Создаем entry
        ChatLogEntry entry = new ChatLogEntry(rawText);
        
        // ДЕДУПЛИКАЦИЯ: проверяем hashKey
        String hashKey = entry.getHashKey();
        if (recentHashKeys.contains(hashKey)) {
            return; // Дубликат в течение той же секунды
        }
        
        // Добавляем в логи
        logs.addFirst(entry); // Новые сверху
        recentHashKeys.add(hashKey);
        
        // Ограничиваем размер
        if (logs.size() > MAX_LOGS) {
            ChatLogEntry removed = logs.removeLast();
            recentHashKeys.remove(removed.getHashKey());
        }
        
        // Очищаем старые hashKeys (старше 2 секунд)
        cleanOldHashKeys();
    }
    
    /**
     * Очищает старые hashKeys для дедупликации
     */
    private void cleanOldHashKeys() {
        if (recentHashKeys.size() > 100) {
            // Простая очистка: оставляем только последние 50
            Set<String> newSet = new HashSet<>();
            int count = 0;
            for (ChatLogEntry entry : logs) {
                if (count++ >= 50) break;
                newSet.add(entry.getHashKey());
            }
            recentHashKeys.clear();
            recentHashKeys.addAll(newSet);
        }
    }
    
    /**
     * Возвращает все логи (новые сверху)
     */
    public List<ChatLogEntry> getAllLogs() {
        return new ArrayList<>(logs);
    }
    
    /**
     * Поиск по тексту (без учета регистра)
     */
    public List<ChatLogEntry> searchLogs(String query) {
        if (query == null || query.isEmpty()) {
            return getAllLogs();
        }
        
        String lowerQuery = query.toLowerCase();
        List<ChatLogEntry> results = new ArrayList<>();
        
        for (ChatLogEntry entry : logs) {
            if (entry.getRawText().toLowerCase().contains(lowerQuery)) {
                results.add(entry);
            }
        }
        
        return results;
    }
    
    /**
     * ПОЛНАЯ ОЧИСТКА логов
     * Вызывается при disconnect и shutdown
     */
    public void clear() {
        logs.clear();
        recentHashKeys.clear();
    }
    
    /**
     * Возвращает количество логов
     */
    public int getLogCount() {
        return logs.size();
    }
}
