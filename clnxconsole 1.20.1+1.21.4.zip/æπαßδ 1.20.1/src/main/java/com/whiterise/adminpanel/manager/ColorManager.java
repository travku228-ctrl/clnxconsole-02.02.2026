package com.whiterise.adminpanel.manager;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/**
 * Менеджер цветовых схем для UI
 * Портировано из spacemoderation с адаптацией под WhiteRise Admin Panel
 */
public class ColorManager {
    private static Color c1; // Основной акцентный цвет
    private static Color c2; // Темный фон
    private static Color c3; // Средний фон
    private static Color c4; // Светлый текст
    private static Color c5; // Акцентный фон
    private static Color c6; // Очень темный фон
    private static Color c7; // Яркий акцент
    private static Color c8; // Белый текст
    
    // КЭШ RGB значений для оптимизации
    private static int cachedC1RGB;
    private static int cachedC2RGB;
    private static int cachedC3RGB;
    private static int cachedC4RGB;
    private static int cachedC5RGB;
    private static int cachedC6RGB;
    private static int cachedC7RGB;
    private static int cachedC8RGB;
    
    private static final Map<String, Color[]> SCHEMES = new HashMap<>();
    private static String currentScheme = "purple";
    
    static {
        // Фиолетовая схема (по умолчанию)
        SCHEMES.put("purple", new Color[]{
            new Color(150, 130, 255, 180), // c1 - основной акцент
            new Color(30, 28, 50, 180),    // c2 - темный фон
            new Color(50, 45, 70, 180),    // c3 - средний фон
            new Color(225, 220, 245),      // c4 - светлый текст
            new Color(90, 80, 130, 200),   // c5 - акцентный фон
            new Color(25, 22, 35, 180),    // c6 - очень темный
            new Color(150, 130, 255, 255), // c7 - яркий акцент
            new Color(255, 255, 255)       // c8 - белый
        });
        
        // Синяя схема
        SCHEMES.put("blue", new Color[]{
            new Color(110, 170, 255, 180),
            new Color(25, 35, 55, 180),
            new Color(40, 60, 90, 180),
            new Color(220, 235, 250),
            new Color(70, 100, 150, 200),
            new Color(18, 25, 38, 180),
            new Color(110, 170, 255, 255),
            new Color(255, 255, 255)
        });
        
        // Красная схема
        SCHEMES.put("red", new Color[]{
            new Color(255, 100, 100, 180),
            new Color(45, 25, 25, 180),
            new Color(70, 35, 35, 180),
            new Color(245, 215, 215),
            new Color(130, 60, 60, 200),
            new Color(35, 18, 18, 180),
            new Color(255, 100, 100, 255),
            new Color(255, 255, 255)
        });
        
        // Розовая схема
        SCHEMES.put("pink", new Color[]{
            new Color(255, 160, 210, 180),
            new Color(55, 35, 45, 180),
            new Color(85, 55, 70, 180),
            new Color(245, 225, 235),
            new Color(140, 90, 110, 200),
            new Color(40, 28, 35, 180),
            new Color(255, 160, 210, 255),
            new Color(255, 255, 255)
        });
        
        // Оранжевая схема
        SCHEMES.put("orange", new Color[]{
            new Color(255, 180, 100, 180),
            new Color(55, 40, 25, 180),
            new Color(85, 65, 40, 180),
            new Color(250, 230, 210),
            new Color(160, 110, 70, 200),
            new Color(40, 30, 20, 180),
            new Color(255, 180, 100, 255),
            new Color(255, 255, 255)
        });
        
        // Серая схема
        SCHEMES.put("gray", new Color[]{
            new Color(160, 170, 180, 180),
            new Color(35, 40, 50, 180),
            new Color(60, 70, 85, 180),
            new Color(210, 215, 220),
            new Color(100, 110, 130, 200),
            new Color(25, 28, 35, 180),
            new Color(160, 170, 180, 255),
            new Color(240, 240, 240)
        });
        
        // Бирюзовая схема
        SCHEMES.put("cyan", new Color[]{
            new Color(100, 230, 230, 180),
            new Color(25, 45, 45, 180),
            new Color(45, 75, 75, 180),
            new Color(220, 245, 245),
            new Color(70, 130, 130, 200),
            new Color(22, 32, 36, 180),
            new Color(100, 230, 230, 255),
            new Color(255, 255, 255)
        });
        
        // Коричневая схема
        SCHEMES.put("brown", new Color[]{
            new Color(170, 120, 70, 180),
            new Color(45, 35, 25, 180),
            new Color(70, 55, 40, 180),
            new Color(230, 210, 190),
            new Color(115, 85, 50, 200),
            new Color(32, 25, 18, 180),
            new Color(170, 120, 70, 255),
            new Color(255, 255, 255)
        });
        
        // Лаймовая схема
        SCHEMES.put("lime", new Color[]{
            new Color(170, 255, 140, 180),
            new Color(25, 45, 25, 180),
            new Color(50, 85, 50, 180),
            new Color(220, 245, 220),
            new Color(90, 150, 90, 200),
            new Color(28, 38, 28, 180),
            new Color(170, 255, 140, 255),
            new Color(255, 255, 255)
        });
        
        // Золотая схема
        SCHEMES.put("gold", new Color[]{
            new Color(255, 225, 120, 180),
            new Color(55, 45, 25, 180),
            new Color(85, 70, 40, 180),
            new Color(255, 245, 220),
            new Color(170, 140, 70, 200),
            new Color(40, 32, 20, 180),
            new Color(255, 255, 120, 255),
            new Color(255, 255, 255)
        });
        
        // Белая схема
        SCHEMES.put("white", new Color[]{
            new Color(250, 245, 240, 180),
            new Color(80, 75, 70, 180),
            new Color(110, 105, 100, 180),
            new Color(255, 255, 255),
            new Color(180, 170, 160, 200),
            new Color(55, 50, 45, 180),
            new Color(250, 245, 240, 255),
            new Color(255, 255, 255)
        });
        
        // Устанавливаем схему по умолчанию
        setScheme("purple");
    }
    
    /**
     * Устанавливает цветовую схему
     * @param name название схемы
     */
    public static void setScheme(String name) {
        Color[] scheme = SCHEMES.get(name.toLowerCase());
        if (scheme == null) {
            scheme = SCHEMES.get("purple");
        }
        
        c1 = scheme[0];
        c2 = scheme[1];
        c3 = scheme[2];
        c4 = scheme[3];
        c5 = scheme[4];
        c6 = scheme[5];
        c7 = scheme[6];
        c8 = scheme[7];
        
        currentScheme = name.toLowerCase();
        
        // ОБНОВЛЯЕМ КЭШ RGB значений
        updateRGBCache();
    }
    
    /**
     * Обновляет кэш RGB значений
     * Вызывается при смене темы
     */
    private static void updateRGBCache() {
        cachedC1RGB = c1.getRGB();
        cachedC2RGB = c2.getRGB();
        cachedC3RGB = c3.getRGB();
        cachedC4RGB = c4.getRGB();
        cachedC5RGB = c5.getRGB();
        cachedC6RGB = c6.getRGB();
        cachedC7RGB = c7.getRGB();
        cachedC8RGB = c8.getRGB();
    }
    
    /**
     * Проверяет существование схемы
     * @param name название схемы
     * @return true если схема существует
     */
    public static boolean hasScheme(String name) {
        return SCHEMES.containsKey(name.toLowerCase());
    }
    
    /**
     * Получает список доступных схем
     * @return массив названий схем
     */
    public static String[] getAvailableSchemes() {
        return SCHEMES.keySet().toArray(new String[0]);
    }
    
    /**
     * Получает текущую схему
     * @return название текущей схемы
     */
    public static String getCurrentScheme() {
        return currentScheme;
    }
    
    // Геттеры для цветов
    
    public static Color getC1() { return c1; }
    public static Color getC2() { return c2; }
    public static Color getC3() { return c3; }
    public static Color getC4() { return c4; }
    public static Color getC5() { return c5; }
    public static Color getC6() { return c6; }
    public static Color getC7() { return c7; }
    public static Color getC8() { return c8; }
    
    // ОПТИМИЗИРОВАННЫЕ геттеры для RGB (используют кэш)
    
    public static int getC1RGB() { return cachedC1RGB; }
    public static int getC2RGB() { return cachedC2RGB; }
    public static int getC3RGB() { return cachedC3RGB; }
    public static int getC4RGB() { return cachedC4RGB; }
    public static int getC5RGB() { return cachedC5RGB; }
    public static int getC6RGB() { return cachedC6RGB; }
    public static int getC7RGB() { return cachedC7RGB; }
    public static int getC8RGB() { return cachedC8RGB; }
    
    /**
     * Получает цвет для призрачных элементов (с альфа-каналом)
     * @return цвет в формате ARGB
     */
    public static int getGhostColor() {
        Color c = c1;
        return (c.getAlpha() & 255) << 24 | 
               (c.getRed() & 255) << 16 | 
               (c.getGreen() & 255) << 8 | 
               c.getBlue() & 255;
    }
    
    /**
     * Смешивает два цвета
     * @param c1 первый цвет
     * @param c2 второй цвет
     * @param ratio соотношение (0.0 - 1.0)
     * @return смешанный цвет
     */
    public static Color blendColors(Color c1, Color c2, double ratio) {
        ratio = Math.max(0.0, Math.min(1.0, ratio));
        int r = (int) (c1.getRed() + (c2.getRed() - c1.getRed()) * ratio);
        int g = (int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * ratio);
        int b = (int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * ratio);
        int a = (int) (c1.getAlpha() + (c2.getAlpha() - c1.getAlpha()) * ratio);
        return new Color(r, g, b, a);
    }
}
