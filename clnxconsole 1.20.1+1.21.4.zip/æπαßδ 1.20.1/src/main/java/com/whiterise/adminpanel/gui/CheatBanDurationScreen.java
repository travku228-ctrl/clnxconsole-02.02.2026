package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.AdminPanelClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class CheatBanDurationScreen extends Screen {
    private final String targetPlayer;
    
    public CheatBanDurationScreen(String targetPlayer) {
        super(Text.literal("Выбор срока бана"));
        this.targetPlayer = targetPlayer;
    }
    
    @Override
    protected void init() {
        int buttonWidth = 200;
        int startX = (this.width - buttonWidth) / 2;
        int startY = this.height / 2 - 50;
        
        // Кнопка 14 дней
        this.addDrawableChild(ButtonWidget.builder(Text.literal("14 дней"), button -> {
            AdminPanelClient.getPunishmentManager().issueBan(targetPlayer, "14d", "2.4");
            this.client.setScreen(new AdminPanelScreen());
        }).dimensions(startX, startY, buttonWidth, 30).build());
        
        // Кнопка 21 день
        this.addDrawableChild(ButtonWidget.builder(Text.literal("21 день"), button -> {
            AdminPanelClient.getPunishmentManager().issueBan(targetPlayer, "21d", "2.4");
            this.client.setScreen(new AdminPanelScreen());
        }).dimensions(startX, startY + 40, buttonWidth, 30).build());
        
        // Кнопка отмены
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Отмена"), button -> {
            this.client.setScreen(new PunishmentScreen(targetPlayer));
        }).dimensions(20, 20, 100, 25).build());
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Черный фон
        context.fill(0, 0, this.width, this.height, 0xFF000000);
        
        // Заголовок
        String title = "Выбор срока бана за читы";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, 60, 0xFFFFFF, true);
        
        // Текст
        String playerInfo = "Игрок: " + targetPlayer;
        int playerInfoWidth = this.textRenderer.getWidth(playerInfo);
        context.drawText(this.textRenderer, playerInfo, (this.width - playerInfoWidth) / 2, 100, 0xFFFFFF, false);
        
        super.render(context, mouseX, mouseY, delta);
    }
}
