package com.whiterise.adminpanel.sound;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class SoundManager {
    public static final SoundEvent UI_BUTTON_HOVER = registerSound("ui.button.hover");
    public static final SoundEvent UI_BUTTON_CLICK = registerSound("ui.button.click");
    public static final SoundEvent UI_TEXT_TYPE = registerSound("ui.text.type");
    
    private static SoundEvent registerSound(String name) {
        Identifier id = new Identifier("whiterise_adminpanel", name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }
    
    public static void playHoverSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.getSoundManager() != null) {
            client.getSoundManager().play(PositionedSoundInstance.master(UI_BUTTON_HOVER, 1.0f));
        }
    }
    
    public static void playClickSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.getSoundManager() != null) {
            client.getSoundManager().play(PositionedSoundInstance.master(UI_BUTTON_CLICK, 1.0f));
        }
    }
    
    public static void playTypeSound() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.getSoundManager() != null) {
            client.getSoundManager().play(PositionedSoundInstance.master(UI_TEXT_TYPE, 0.3f)); // Тише чем клик
        }
    }
    
    public static void init() {
        // Регистрация звуков при инициализации мода
    }
}
