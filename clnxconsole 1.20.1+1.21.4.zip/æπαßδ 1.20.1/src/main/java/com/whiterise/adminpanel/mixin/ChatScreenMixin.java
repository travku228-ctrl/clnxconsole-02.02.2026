package com.whiterise.adminpanel.mixin;

import com.whiterise.adminpanel.hud.HudConfig;
import com.whiterise.adminpanel.hud.HudEditorScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin для перехвата открытия чата
 * Если включен режим редактирования HUD, открывает HudEditorScreen вместо чата
 */
@Mixin(ChatScreen.class)
public class ChatScreenMixin {
    
    @Inject(method = "<init>(Ljava/lang/String;)V", at = @At("RETURN"))
    private void onChatScreenInit(String originalChatText, CallbackInfo ci) {
        // Проверяем, включен ли режим редактирования
        if (HudConfig.isEditModeEnabled() && originalChatText.isEmpty()) {
            MinecraftClient client = MinecraftClient.getInstance();
            
            // Проверяем, что игра полностью инициализирована
            if (client != null && client.world != null && client.player != null) {
                // Открываем редактор HUD вместо чата
                client.execute(() -> {
                    client.setScreen(new HudEditorScreen());
                });
            }
        }
    }
}
