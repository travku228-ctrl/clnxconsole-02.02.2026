package com.whiterise.adminpanel.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Представление текста с цветовыми сегментами
 * Парсит Minecraft цветовые коды: &X и &#RRGGBB
 */
public class ColoredText {
    private final List<Segment> segments = new ArrayList<>();
    
    /**
     * Сегмент текста с цветом
     */
    public static class Segment {
        public final String text;
        public final int color;
        
        public Segment(String text, int color) {
            this.text = text;
            this.color = color;
        }
    }
    
    /**
     * Парсит текст с цветовыми кодами
     * Поддерживает:
     * - &0-f, &a-f - стандартные цвета
     * - &r - сброс цвета
     * - &#RRGGBB - HEX цвета
     */
    public static ColoredText parse(String input) {
        ColoredText result = new ColoredText();
        
        if (input == null || input.isEmpty()) {
            return result;
        }
        
        int currentColor = 0xFFFFFFFF; // Белый по умолчанию
        StringBuilder currentText = new StringBuilder();
        
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            
            // Проверяем цветовой код
            if (c == '&' && i + 1 < input.length()) {
                char next = input.charAt(i + 1);
                
                // HEX цвет: &#RRGGBB
                if (next == '#' && i + 7 < input.length()) {
                    String hexCode = input.substring(i + 2, i + 8);
                    
                    // Проверяем что это валидный HEX
                    if (isValidHex(hexCode)) {
                        // Сохраняем текущий сегмент
                        if (currentText.length() > 0) {
                            result.segments.add(new Segment(currentText.toString(), currentColor));
                            currentText.setLength(0);
                        }
                        
                        // Парсим HEX цвет
                        try {
                            int rgb = Integer.parseInt(hexCode, 16);
                            currentColor = 0xFF000000 | rgb; // Добавляем альфа
                        } catch (NumberFormatException e) {
                            // Невалидный HEX - игнорируем
                        }
                        
                        i += 7; // Пропускаем &#RRGGBB
                        continue;
                    }
                }
                
                // Стандартный цветовой код: &X
                int minecraftColor = getMinecraftColor(next);
                if (minecraftColor != -1) {
                    // Сохраняем текущий сегмент
                    if (currentText.length() > 0) {
                        result.segments.add(new Segment(currentText.toString(), currentColor));
                        currentText.setLength(0);
                    }
                    
                    currentColor = minecraftColor;
                    i++; // Пропускаем код цвета
                    continue;
                }
            }
            
            // Обычный символ
            currentText.append(c);
        }
        
        // Добавляем последний сегмент
        if (currentText.length() > 0) {
            result.segments.add(new Segment(currentText.toString(), currentColor));
        }
        
        return result;
    }
    
    /**
     * Проверяет что строка - валидный HEX код (6 символов 0-9A-Fa-f)
     */
    private static boolean isValidHex(String hex) {
        if (hex.length() != 6) {
            return false;
        }
        
        for (char c : hex.toCharArray()) {
            if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f'))) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Преобразует код Minecraft цвета в RGB
     * @return RGB цвет или -1 если код неизвестен
     */
    private static int getMinecraftColor(char code) {
        switch (code) {
            case '0': return 0xFF000000; // Черный
            case '1': return 0xFF0000AA; // Темно-синий
            case '2': return 0xFF00AA00; // Темно-зеленый
            case '3': return 0xFF00AAAA; // Темно-голубой
            case '4': return 0xFFAA0000; // Темно-красный
            case '5': return 0xFFAA00AA; // Темно-фиолетовый
            case '6': return 0xFFFFAA00; // Золотой
            case '7': return 0xFFAAAAAA; // Серый
            case '8': return 0xFF555555; // Темно-серый
            case '9': return 0xFF5555FF; // Синий
            case 'a': case 'A': return 0xFF55FF55; // Зеленый
            case 'b': case 'B': return 0xFF55FFFF; // Голубой
            case 'c': case 'C': return 0xFFFF5555; // Красный
            case 'd': case 'D': return 0xFFFF55FF; // Светло-фиолетовый
            case 'e': case 'E': return 0xFFFFFF55; // Желтый
            case 'f': case 'F': return 0xFFFFFFFF; // Белый
            case 'r': case 'R': return 0xFFFFFFFF; // Сброс (белый)
            default: return -1; // Неизвестный код
        }
    }
    
    /**
     * Возвращает список сегментов
     */
    public List<Segment> getSegments() {
        return segments;
    }
    
    /**
     * Возвращает текст без цветовых кодов
     */
    public String getPlainText() {
        StringBuilder result = new StringBuilder();
        for (Segment segment : segments) {
            result.append(segment.text);
        }
        return result.toString();
    }
    
    /**
     * Проверяет пустой ли текст
     */
    public boolean isEmpty() {
        return segments.isEmpty();
    }
}
