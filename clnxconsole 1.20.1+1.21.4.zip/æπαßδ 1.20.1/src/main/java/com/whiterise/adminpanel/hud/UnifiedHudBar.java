package com.whiterise.adminpanel.hud;

import com.whiterise.adminpanel.AdminPanelClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;

/**
 * Единый горизонтальный HUD бар - ТОЧНАЯ КОПИЯ ДИЗАЙНА ИЗ FIGMA
 */
public class UnifiedHudBar {
    // ЦВЕТА ИЗ FIGMA
    private static final int COLOR_BG = 0xFF312541;           // Фон бара
    private static final int COLOR_STROKE = 0x40B700FF;       // Обводка (25% opacity)
    private static final int COLOR_TEXT = 0xFFE17FE3;         // Текст (розовый)
    private static final int COLOR_DIVIDER = 0x408D00C8;      // Разделители (25% opacity)
    private static final int COLOR_SHADOW = 0x40000000;       // Тень M3/Elevation Light/1
    
    // ИКОНКИ (PNG текстуры)
    private static final Identifier ICON_LOGO = new Identifier("whiterise_adminpanel", "textures/icons/logo.png");
    private static final Identifier ICON_PLAYER = new Identifier("whiterise_adminpanel", "textures/icons/player.png");
    private static final Identifier ICON_FPS = new Identifier("whiterise_adminpanel", "textures/icons/fps.png");
    private static final Identifier ICON_PING = new Identifier("whiterise_adminpanel", "textures/icons/ping.png");
    private static final Identifier ICON_TIME = new Identifier("whiterise_adminpanel", "textures/icons/time.png");
    private static final Identifier ICON_PUNISH = new Identifier("whiterise_adminpanel", "textures/icons/punishment.png");
    
    // Режим рендеринга: true = гладкие текстуры (Figma style), false = геометрия
    private static final boolean USE_SMOOTH_RENDERING = true;
    
    // РАЗМЕРЫ ИЗ FIGMA
    private static final int BAR_HEIGHT = 20;                 // Высота бара
    private static final int CORNER_RADIUS = 10;              // Скругление правой стороны
    private static final int DIVIDER_WIDTH = 1;               // Толщина разделителя
    private static final int DIVIDER_HEIGHT = 14;             // Высота разделителя
    private static final int PADDING_LEFT = 8;                // Отступ слева (увеличен)
    private static final int PADDING_RIGHT = 8;               // Отступ справа (увеличен)
    private static final int ITEM_SPACING = 12;               // Расстояние между элементами (увеличено)
    private static final int ICON_SIZE = 12;                  // Размер иконки (меньше)
    
    // ФИКСИРОВАННЫЕ ШИРИНЫ для элементов (уменьшены)
    private static final int FPS_WIDTH = 30;                  // Фиксированная ширина для FPS (уменьшена)
    private static final int PING_WIDTH = 26;                 // Фиксированная ширина для пинга (уменьшена)
    
    // Настройки отображения элементов
    private boolean showPlayer = true;
    private boolean showFps = true;
    private boolean showPing = true;
    private boolean showTime = true;
    private boolean showPunishments = true;
    private float scale = 1.0f; // Масштаб бара
    
    private long sessionStartTime = 0;
    private boolean enabled = true;
    private float opacity = 1.0f;
    private boolean isPreviewMode = false; // Флаг режима предпросмотра
    
    public void render(DrawContext context, int screenWidth, int screenHeight, float delta) {
        if (!enabled) return;
        
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden && !isPreviewMode) return; // В режиме предпросмотра игнорируем hudHidden
        
        // Инициализируем время сессии
        if (sessionStartTime == 0 && client.world != null) {
            sessionStartTime = System.currentTimeMillis();
        }
        if (client.world == null) {
            sessionStartTime = 0;
            return;
        }
        
        // Собираем данные
        String playerName = client.player != null ? client.player.getName().getString() : "Player";
        int fps = client.getCurrentFps();
        int ping = getPing(client);
        String sessionTime = formatTime(System.currentTimeMillis() - sessionStartTime);
        int punishments = getPunishmentsCount();
        
        // Вычисляем динамическую ширину бара
        int barWidth = calculateDynamicWidth(client, playerName, fps, ping, sessionTime, punishments);
        int barX = 10;
        int barY = 10;
        
        // Применяем масштаб
        context.getMatrices().push();
        context.getMatrices().scale(scale, scale, 1.0f);
        
        // Пересчитываем позиции с учетом масштаба
        int scaledX = (int)(barX / scale);
        int scaledY = (int)(barY / scale);
        
        // === УЛУЧШЕННЫЙ СОВРЕМЕННЫЙ РЕНДЕРИНГ ===
        // СНАЧАЛА рисуем ВСЕ фоны и тени с улучшенными эффектами
        if (USE_SMOOTH_RENDERING) {
            // Многослойная падающая тень (layered shadow) с прозрачностью
            drawLayeredShadow(context, scaledX, scaledY, barWidth, BAR_HEIGHT, 8, opacity);
            
            // Основная панель БЕЗ закругления слева, только справа (#312541 с прозрачностью из настроек)
            int bgAlpha = (int) (0xE6 * opacity); // Применяем opacity к базовой прозрачности 90%
            int bgColor = (bgAlpha << 24) | 0x312541;
            
            // Рисуем прямоугольник с закруглением только справа
            // Левая сторона - прямая, правая - скругленная
            context.fill(scaledX, scaledY, scaledX + barWidth - CORNER_RADIUS, scaledY + BAR_HEIGHT, bgColor);
            com.whiterise.adminpanel.util.RenderUtils.fillRounded(context, scaledX + barWidth - CORNER_RADIUS * 2, scaledY, CORNER_RADIUS * 2, BAR_HEIGHT, CORNER_RADIUS, bgColor);
            
            // Outline (обводка) цвета разделителя с прозрачностью из настроек - тоже только справа
            int outlineAlpha = (int) (0x66 * opacity); // Применяем opacity к базовой прозрачности 40%
            int outlineColor = (outlineAlpha << 24) | 0x8D00C8;
            
            // Обводка: левая сторона прямая, правая скругленная
            context.fill(scaledX, scaledY, scaledX + 1, scaledY + BAR_HEIGHT, outlineColor); // Левая граница
            context.fill(scaledX, scaledY, scaledX + barWidth - CORNER_RADIUS, scaledY + 1, outlineColor); // Верхняя граница
            context.fill(scaledX, scaledY + BAR_HEIGHT - 1, scaledX + barWidth - CORNER_RADIUS, scaledY + BAR_HEIGHT, outlineColor); // Нижняя граница
            com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorder(context, scaledX + barWidth - CORNER_RADIUS * 2, scaledY, CORNER_RADIUS * 2, BAR_HEIGHT, CORNER_RADIUS, outlineColor);
        } else {
            // Старый геометрический рендеринг (fallback)
            int shadowAlpha = (int) (0x40 * opacity);
            int shadowColor = (shadowAlpha << 24) | 0x000000;
            fillRoundedRight(context, scaledX, scaledY + 1, barWidth, BAR_HEIGHT, CORNER_RADIUS, shadowColor);
            
            int bgAlpha = (int) (0xFF * opacity);
            int bgColor = (bgAlpha << 24) | 0x312541;
            fillRoundedRight(context, scaledX, scaledY, barWidth, BAR_HEIGHT, CORNER_RADIUS, bgColor);
            
            int strokeAlpha = (int) (0x40 * opacity);
            int strokeColor = (strokeAlpha << 24) | 0xB700FF;
            drawRoundedBorderRight(context, scaledX, scaledY, barWidth, BAR_HEIGHT, CORNER_RADIUS, strokeColor);
        }
        
        // ПОТОМ рисуем элементы ПОВЕРХ фона
        context.getMatrices().push();
        context.getMatrices().translate(0, 0, 1); // Z-offset чтобы быть поверх фона
        
        // Включаем scissor для правильного обрезания содержимого по скругленным краям
        // НО только если НЕ в режиме предпросмотра
        int scissorPadding = 8; // Отступ от краев для скругления
        if (!isPreviewMode) {
            context.enableScissor(scaledX + scissorPadding, scaledY, scaledX + barWidth - scissorPadding, scaledY + BAR_HEIGHT);
        }
        
        // Рендерим элементы с ДИНАМИЧЕСКИМИ позициями и отступами от краев
        int currentX = scaledX + PADDING_LEFT + 2; // Добавляем небольшой отступ от левого края
        
        // 1. Логотип (всегда показывается) - иконка (увеличенный размер)
        renderLogoIcon(context, currentX, scaledY, client);
        currentX += (ICON_SIZE + 4) + ITEM_SPACING; // Размер увеличенной иконки
        
        // 2. Игрок
        if (showPlayer) {
            renderDivider(context, currentX, scaledY);
            currentX += DIVIDER_WIDTH + ITEM_SPACING;
            renderIconWithText(context, currentX, scaledY, ICON_PLAYER, playerName, client);
            currentX += ICON_SIZE + 4 + client.textRenderer.getWidth(playerName) + ITEM_SPACING;
        }
        
        // 3. FPS
        if (showFps) {
            renderDivider(context, currentX, scaledY);
            currentX += DIVIDER_WIDTH + ITEM_SPACING;
            renderIconWithText(context, currentX, scaledY, ICON_FPS, "fps " + fps, client);
            currentX += ICON_SIZE + 4 + FPS_WIDTH + ITEM_SPACING;
        }
        
        // 4. Пинг
        if (showPing) {
            renderDivider(context, currentX, scaledY);
            currentX += DIVIDER_WIDTH + ITEM_SPACING;
            renderIconWithText(context, currentX, scaledY, ICON_PING, ping + " ms", client);
            currentX += ICON_SIZE + 4 + PING_WIDTH + ITEM_SPACING;
        }
        
        // 5. Время сессии
        if (showTime) {
            renderDivider(context, currentX, scaledY);
            currentX += DIVIDER_WIDTH + ITEM_SPACING;
            renderIconWithText(context, currentX, scaledY, ICON_TIME, sessionTime, client);
            currentX += ICON_SIZE + 4 + client.textRenderer.getWidth(sessionTime) + ITEM_SPACING;
        }
        
        // 6. Наказания
        if (showPunishments) {
            renderDivider(context, currentX, scaledY);
            currentX += DIVIDER_WIDTH + ITEM_SPACING;
            renderIconWithText(context, currentX, scaledY, ICON_PUNISH, String.valueOf(punishments), client);
        }
        
        // Отключаем scissor только если он был включен
        if (!isPreviewMode) {
            context.disableScissor();
        }
        
        context.getMatrices().pop(); // Закрываем Z-offset для элементов
        
        context.getMatrices().pop(); // Закрываем основную матрицу масштаба
    }
    
    
    /**
     * Рендерит логотип (статичная иконка без анимаций) с учётом прозрачности
     */
    private void renderLogoIcon(DrawContext context, int x, int y, MinecraftClient client) {
        int iconSize = ICON_SIZE + 4; // Увеличен размер логотипа (16 вместо 12)
        int iconY = y + (BAR_HEIGHT - iconSize) / 2;
        
        // Рендерим иконку с правильным blend mode и прозрачностью (БЕЗ анимаций)
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.blendFunc(
            com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
            com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA
        );
        
        // Применяем прозрачность через цвет
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, opacity);
        
        // Рендерим иконку без анимаций
        context.drawTexture(ICON_LOGO, x + 1, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Восстанавливаем цвет и blend
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
    }
    
    /**
     * Рендерит эмодзи
     */
    private void renderEmoji(DrawContext context, int x, int y, String emoji, MinecraftClient client) {
        int emojiY = y + (BAR_HEIGHT - 8) / 2 - 1;
        int textColor = applyOpacity(COLOR_TEXT);
        context.drawText(client.textRenderer, emoji, x, emojiY, textColor, false);
    }
    
    
    /**
     * Рендерит иконку с текстом (PNG иконка + текст) с учётом прозрачности
     */
    private void renderIconWithText(DrawContext context, int x, int y, Identifier icon, String text, MinecraftClient client) {
        int iconSize = ICON_SIZE;
        int iconY = y + (BAR_HEIGHT - iconSize) / 2;
        
        // Рендерим PNG иконку с правильным blend mode и прозрачностью (БЕЗ мерцания)
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        com.mojang.blaze3d.systems.RenderSystem.blendFunc(
            com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
            com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA
        );
        
        // Применяем только обычную прозрачность (без мерцания)
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, opacity);
        
        // Рендерим PNG иконку
        context.drawTexture(icon, x, iconY, 0, 0, iconSize, iconSize, iconSize, iconSize);
        
        // Восстанавливаем цвет и blend для текста
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
        
        // Текст справа от иконки - выровнен по центру с иконкой (БЕЗ мерцания)
        int textX = x + iconSize + 4;
        int textY = y + (BAR_HEIGHT - 8) / 2;  // Центрируем текст по высоте бара
        
        // Применяем обычную прозрачность к тексту (без мерцания)
        int textColor = applyOpacity(COLOR_TEXT);
        
        if (USE_SMOOTH_RENDERING) {
            com.whiterise.adminpanel.util.SmoothHudRenderer.drawSmoothText(context, text, textX, textY, textColor);
        } else {
            context.drawText(client.textRenderer, text, textX, textY, textColor, false);
        }
    }
    
    /**
     * Рендерит эмодзи с текстом (гладкий рендеринг) - DEPRECATED, используй renderIconWithText
     */
    private void renderEmojiWithText(DrawContext context, int x, int y, String emoji, String text, MinecraftClient client) {
        int textY = y + (BAR_HEIGHT - 8) / 2 - 1;
        int textColor = applyOpacity(COLOR_TEXT);
        
        if (USE_SMOOTH_RENDERING) {
            // Гладкий текст с антиалиасингом
            com.whiterise.adminpanel.util.SmoothHudRenderer.drawSmoothText(context, emoji, x, textY, textColor);
            int textX = x + client.textRenderer.getWidth(emoji) + 6;
            com.whiterise.adminpanel.util.SmoothHudRenderer.drawSmoothText(context, text, textX, textY, textColor);
        } else {
            // Обычный текст
            context.drawText(client.textRenderer, emoji, x, textY, textColor, false);
            int textX = x + client.textRenderer.getWidth(emoji) + 6;
            context.drawText(client.textRenderer, text, textX, textY, textColor, false);
        }
    }
    
    /**
     * Рендерит вертикальный разделитель (гладкий) с учётом прозрачности
     */
    private void renderDivider(DrawContext context, int x, int y) {
        int dividerY = y + (BAR_HEIGHT - DIVIDER_HEIGHT) / 2;
        
        if (USE_SMOOTH_RENDERING) {
            // Гладкий разделитель с градиентом и прозрачностью
            for (int i = 0; i < DIVIDER_HEIGHT; i++) {
                float alpha = 1.0f - Math.abs(i - DIVIDER_HEIGHT / 2.0f) / (DIVIDER_HEIGHT / 2.0f);
                int alphaInt = (int)(alpha * 64 * opacity); // 25% максимум с учётом opacity
                int color = (alphaInt << 24) | 0x8D00C8;
                context.fill(x, dividerY + i, x + DIVIDER_WIDTH, dividerY + i + 1, color);
            }
        } else {
            // Обычный разделитель с прозрачностью
            int dividerColor = applyOpacity(COLOR_DIVIDER);
            context.fill(x, dividerY, x + DIVIDER_WIDTH, dividerY + DIVIDER_HEIGHT, dividerColor);
        }
    }
    
    /**
     * Вычисляет динамическую ширину бара в зависимости от включенных элементов
     */
    private int calculateDynamicWidth(MinecraftClient client, String playerName, int fps, int ping, String sessionTime, int punishments) {
        int width = PADDING_LEFT + PADDING_RIGHT;
        
        // Логотип (всегда показывается) - иконка (увеличенный размер)
        width += (ICON_SIZE + 4) + ITEM_SPACING;
        
        // Игрок
        if (showPlayer) {
            width += DIVIDER_WIDTH + ITEM_SPACING;
            width += ICON_SIZE + 4 + client.textRenderer.getWidth(playerName) + ITEM_SPACING;
        }
        
        // FPS
        if (showFps) {
            width += DIVIDER_WIDTH + ITEM_SPACING;
            width += ICON_SIZE + 4 + FPS_WIDTH + ITEM_SPACING;
        }
        
        // Пинг
        if (showPing) {
            width += DIVIDER_WIDTH + ITEM_SPACING;
            width += ICON_SIZE + 4 + PING_WIDTH + ITEM_SPACING;
        }
        
        // Время
        if (showTime) {
            width += DIVIDER_WIDTH + ITEM_SPACING;
            width += ICON_SIZE + 4 + client.textRenderer.getWidth(sessionTime) + ITEM_SPACING;
        }
        
        // Наказания (последний элемент - добавляем ITEM_SPACING для правого отступа)
        if (showPunishments) {
            width += DIVIDER_WIDTH + ITEM_SPACING;
            width += ICON_SIZE + 4 + client.textRenderer.getWidth(String.valueOf(punishments)) + ITEM_SPACING;
        }
        
        return width;
    }
    
    /**
     * Получает пинг игрока
     */
    private int getPing(MinecraftClient client) {
        if (client.player == null) return 0;
        
        PlayerListEntry playerEntry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        if (playerEntry != null) {
            return playerEntry.getLatency();
        }
        return 0;
    }
    
    /**
     * Получает количество наказаний
     */
    private int getPunishmentsCount() {
        return (int) AdminPanelClient.getPunishmentManager().getPunishmentHistory().stream()
            .filter(record -> record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE 
                           && record.getType() != com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN)
            .count();
    }
    
    /**
     * Форматирует время
     */
    private String formatTime(long millis) {
        long seconds = millis / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, secs);
        } else {
            return String.format("%02d:%02d", minutes, secs);
        }
    }
    
    /**
     * Рисует прямоугольник с закруглением ТОЛЬКО ПРАВОЙ стороны
     */
    private void fillRoundedRight(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        // Используем геометрический рендеринг (fallback)
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedRight(context, x, y, width, height, radius, color);
    }
    
    /**
     * Рисует обводку с закруглением ТОЛЬКО ПРАВОЙ стороны
     */
    private void drawRoundedBorderRight(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        // Используем геометрический рендеринг
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorderRight(context, x, y, width, height, radius, color);
    }
    
    /**
     * Рисует многослойную падающую тень (layered shadow) с учётом прозрачности
     */
    private void drawLayeredShadow(DrawContext context, int x, int y, int width, int height, int radius, float opacity) {
        // 3 слоя тени с разной прозрачностью и смещением, применяем opacity
        int shadow1Alpha = (int) (0x10 * opacity);
        int shadow2Alpha = (int) (0x15 * opacity);
        int shadow3Alpha = (int) (0x20 * opacity);
        
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedRight(context, x + 1, y + 2, width, height, radius, (shadow1Alpha << 24) | 0x000000);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedRight(context, x + 1, y + 3, width, height, radius, (shadow2Alpha << 24) | 0x000000);
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedRight(context, x + 2, y + 4, width, height, radius, (shadow3Alpha << 24) | 0x000000);
    }
    
    /**
     * Рисует гладкий закругленный прямоугольник (БЕЗ текстур, чистый fill)
     */
    private void drawSmoothRoundedRect(DrawContext context, int x, int y, int width, int height, int radius, int color, float alpha) {
        int alphaInt = (int)(alpha * 255);
        int finalColor = (alphaInt << 24) | (color & 0xFFFFFF);
        
        // Используем геометрический рендеринг с правильным цветом
        com.whiterise.adminpanel.util.RenderUtils.fillRoundedRight(context, x, y, width, height, radius, finalColor);
    }
    
    /**
     * Рисует гладкую обводку
     */
    private void drawSmoothBorder(DrawContext context, int x, int y, int width, int height, int radius, int color, float alpha) {
        int alphaInt = (int)(alpha * 255);
        int finalColor = (alphaInt << 24) | (color & 0xFFFFFF);
        
        com.whiterise.adminpanel.util.RenderUtils.drawRoundedBorderRight(context, x, y, width, height, radius, finalColor);
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setOpacity(float opacity) {
        this.opacity = Math.max(0.0f, Math.min(1.0f, opacity));
    }
    
    /**
     * Применяет текущую прозрачность к цвету
     */
    private int applyOpacity(int color) {
        int alpha = (color >> 24) & 0xFF;
        int newAlpha = (int) (alpha * opacity);
        return (newAlpha << 24) | (color & 0x00FFFFFF);
    }
    
    public float getOpacity() {
        return opacity;
    }
    
    // Геттеры и сеттеры для элементов
    public boolean isShowPlayer() {
        return showPlayer;
    }
    
    public void setShowPlayer(boolean showPlayer) {
        this.showPlayer = showPlayer;
    }
    
    public boolean isShowFps() {
        return showFps;
    }
    
    public void setShowFps(boolean showFps) {
        this.showFps = showFps;
    }
    
    public boolean isShowPing() {
        return showPing;
    }
    
    public void setShowPing(boolean showPing) {
        this.showPing = showPing;
    }
    
    public boolean isShowTime() {
        return showTime;
    }
    
    public void setShowTime(boolean showTime) {
        this.showTime = showTime;
    }
    
    public boolean isShowPunishments() {
        return showPunishments;
    }
    
    public void setShowPunishments(boolean showPunishments) {
        this.showPunishments = showPunishments;
    }
    
    public float getScale() {
        return scale;
    }
    
    public void setScale(float scale) {
        this.scale = Math.max(0.5f, Math.min(2.0f, scale));
    }
    
    public boolean isPreviewMode() {
        return isPreviewMode;
    }
    
    public void setPreviewMode(boolean previewMode) {
        this.isPreviewMode = previewMode;
    }
}
