package com.whiterise.adminpanel.background;

/**
 * Прямоугольная область (запретная зона для частиц)
 * 
 * Представляет область UI, которую частицы должны обходить
 * Используется для защиты важных элементов интерфейса от перекрытия
 * Поддерживает проверку точек и пересечения линий
 */
public class Rectangle {
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    
    public Rectangle(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    /**
     * Проверяет, находится ли точка внутри прямоугольника
     */
    public boolean contains(float px, float py) {
        return px >= x && px <= x + width && py >= y && py <= y + height;
    }
    
    /**
     * Проверяет, пересекает ли линия прямоугольник
     */
    public boolean intersectsLine(float x1, float y1, float x2, float y2) {
        // Проверяем, находятся ли концы линии внутри прямоугольника
        if (contains(x1, y1) || contains(x2, y2)) {
            return true;
        }
        
        // Проверяем пересечение линии с каждой стороной прямоугольника
        // Левая сторона
        if (lineIntersectsLine(x1, y1, x2, y2, x, y, x, y + height)) return true;
        // Правая сторона
        if (lineIntersectsLine(x1, y1, x2, y2, x + width, y, x + width, y + height)) return true;
        // Верхняя сторона
        if (lineIntersectsLine(x1, y1, x2, y2, x, y, x + width, y)) return true;
        // Нижняя сторона
        if (lineIntersectsLine(x1, y1, x2, y2, x, y + height, x + width, y + height)) return true;
        
        return false;
    }
    
    /**
     * Проверяет пересечение двух линий
     */
    private boolean lineIntersectsLine(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4) {
        float denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
        if (denom == 0) return false;
        
        float ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denom;
        float ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denom;
        
        return ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return width;
    }
    
    public int getHeight() {
        return height;
    }
}
