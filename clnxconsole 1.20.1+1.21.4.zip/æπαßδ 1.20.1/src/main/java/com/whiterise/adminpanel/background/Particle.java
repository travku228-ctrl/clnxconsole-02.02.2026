package com.whiterise.adminpanel.background;

/**
 * Одна фоновая частица для GUI
 * 
 * ПЕРМАНЕНТНАЯ частица без времени жизни
 * Использует float координаты для плавности
 * Wrap-around при выходе за границы экрана
 * Физика отталкивания от других частиц
 */
public class Particle {
    // Позиция (float для плавности)
    private float x;
    private float y;
    
    // Скорость (пикселей в секунду)
    private float velocityX;
    private float velocityY;
    
    // Размер частицы
    private final float radius;
    
    // Демпфирование для плавности (0.995 = 0.5% затухание за секунду - меньше чем было)
    private static final float DAMPING = 0.995f;
    
    // Минимальная базовая скорость (частицы всегда двигаются хотя бы с этой скоростью)
    private static final float MIN_BASE_SPEED = 2.0f; // 2 пикселя в секунду
    
    // Границы экрана
    private int screenWidth;
    private int screenHeight;
    
    /**
     * Конструктор частицы
     */
    public Particle(float x, float y, float velocityX, float velocityY, float radius, 
                   int screenWidth, int screenHeight) {
        this.x = x;
        this.y = y;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.radius = radius;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    
    /**
     * Обновление позиции частицы
     * 
     * ПЛАВНОЕ движение без хаотичных изменений
     * WRAP-AROUND при выходе за границы (НЕ респавн!)
     * Демпфирование для сглаживания рывков
     */
    public void update(float delta) {
        // Применяем демпфирование для плавности (затухание скорости)
        // Уменьшаем демпфирование чтобы частицы не останавливались полностью
        float dampingFactor = (float) Math.pow(DAMPING, delta * 60); // Нормализуем к 60 FPS
        velocityX *= dampingFactor;
        velocityY *= dampingFactor;
        
        // Добавляем минимальную базовую скорость чтобы частицы всегда двигались
        // Если скорость слишком мала - добавляем небольшой импульс
        float currentSpeed = (float) Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        if (currentSpeed < MIN_BASE_SPEED) {
            // Добавляем небольшую скорость в текущем направлении
            if (currentSpeed > 0.1f) {
                float factor = MIN_BASE_SPEED / currentSpeed;
                velocityX *= factor;
                velocityY *= factor;
            } else {
                // Если скорость почти нулевая - задаём случайное направление
                double angle = Math.random() * Math.PI * 2;
                velocityX = (float) (Math.cos(angle) * MIN_BASE_SPEED);
                velocityY = (float) (Math.sin(angle) * MIN_BASE_SPEED);
            }
        }
        
        // Простое плавное движение
        x += velocityX * delta;
        y += velocityY * delta;
        
        // WRAP-AROUND (телепорт на противоположную сторону)
        if (x < 0) {
            x = screenWidth;
        } else if (x > screenWidth) {
            x = 0;
        }
        
        if (y < 0) {
            y = screenHeight;
        } else if (y > screenHeight) {
            y = 0;
        }
    }
    
    /**
     * Применяет внешнюю силу к частице (отталкивание от курсора или других частиц)
     * Добавляет силу к скорости, а не напрямую к позиции для более плавного эффекта
     */
    public void applyForce(float forceX, float forceY) {
        velocityX += forceX;
        velocityY += forceY;
        
        // Ограничиваем максимальную скорость для предотвращения слишком быстрого движения
        float maxSpeed = 200.0f; // Максимум 200 пикселей в секунду
        float speed = (float) Math.sqrt(velocityX * velocityX + velocityY * velocityY);
        if (speed > maxSpeed) {
            velocityX = (velocityX / speed) * maxSpeed;
            velocityY = (velocityY / speed) * maxSpeed;
        }
    }
    
    /**
     * Обновление размеров экрана (при изменении разрешения)
     */
    public void updateScreenSize(int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
    }
    
    // Геттеры
    public float getX() {
        return x;
    }
    
    public float getY() {
        return y;
    }
    
    public float getRadius() {
        return radius;
    }
}
