package com.whiterise.adminpanel.data;

public class ChatMessage {
    private final String username;
    private final String message;
    private final long timestamp;
    private final String playerGroup; // Привилегия игрока (admin, moder, helper, default)
    private final boolean isCaps; // CAPS-детекция
    
    public ChatMessage(String username, String message) {
        this(username, message, "default");
    }
    
    public ChatMessage(String username, String message, String playerGroup) {
        this.username = username;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
        this.playerGroup = playerGroup != null ? playerGroup : "default";
        this.isCaps = detectCaps(message);
    }
    
    /**
     * Детекция CAPS-сообщений
     * Правила:
     * 1) Не менее 50% букв в верхнем регистре
     * 2) ИЛИ подряд есть 6 и более символов в верхнем регистре
     * 
     * Условия:
     * - Учитывать ТОЛЬКО буквы (A-Z, А-Я)
     * - Цифры, пробелы, символы не учитывать
     * - Короткие сообщения (меньше 6 букв) не считать CAPS
     */
    private static boolean detectCaps(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }
        
        // Подсчет букв
        int totalLetters = 0;
        int upperLetters = 0;
        int consecutiveUpper = 0;
        int maxConsecutiveUpper = 0;
        
        for (char c : text.toCharArray()) {
            // Проверяем, является ли символ буквой (латиница или кириллица)
            if (Character.isLetter(c)) {
                totalLetters++;
                
                if (Character.isUpperCase(c)) {
                    upperLetters++;
                    consecutiveUpper++;
                    maxConsecutiveUpper = Math.max(maxConsecutiveUpper, consecutiveUpper);
                } else {
                    consecutiveUpper = 0;
                }
            } else {
                // Не буква - сбрасываем счетчик подряд идущих
                consecutiveUpper = 0;
            }
        }
        
        // Короткие сообщения (меньше 6 букв) не считаем CAPS
        if (totalLetters < 6) {
            return false;
        }
        
        // Правило 1: Не менее 50% букв в верхнем регистре
        double upperPercentage = (double) upperLetters / totalLetters;
        if (upperPercentage >= 0.5) {
            return true;
        }
        
        // Правило 2: Подряд 6 и более символов в верхнем регистре
        if (maxConsecutiveUpper >= 6) {
            return true;
        }
        
        return false;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getMessage() {
        return message;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public String getPlayerGroup() {
        return playerGroup;
    }
    
    public boolean isCaps() {
        return isCaps;
    }
}
