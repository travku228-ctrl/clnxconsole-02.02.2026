package com.whiterise.adminpanel.gui;

import com.whiterise.adminpanel.AdminPanelClient;
import com.whiterise.adminpanel.sound.SoundManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Контекстное меню для быстрых мутов игроков
 * Открывается по ПКМ на сообщении в логах чата
 * ОБНОВЛЕНО: Компактная сетка, без описаний, умное позиционирование
 */
public class QuickMuteMenu {
    // КОМПАКТНАЯ СЕТКА: 3 колонки
    private static final int COLUMNS = 3;
    private static final int BUTTON_WIDTH = 140;
    private static final int BUTTON_HEIGHT = 32;
    private static final int BUTTON_SPACING = 8;
    private static final int HEADER_HEIGHT = 32;
    private static final int MENU_PADDING = 12;
    
    // Цвета
    private static final int COLOR_BG = 0xFF151b26;
    private static final int COLOR_HEADER = 0xFF1a2332;
    private static final int COLOR_BORDER = 0xFF2a3441;
    private static final int COLOR_SHADOW = 0x88000000;
    private static final int COLOR_TEXT_PRIMARY = 0xFFFFFFFF;
    private static final int COLOR_TEXT_MUTED = 0xFF6b7280;
    
    // Цвета для категорий (тонкие намёки)
    private static final int COLOR_NEUTRAL_BG = 0xFF1a2332;
    private static final int COLOR_NEUTRAL_HOVER = 0xFF1f2838;
    private static final int COLOR_OFFENSE_BG = 0xFF1f2533;
    private static final int COLOR_OFFENSE_HOVER = 0xFF242a3a;
    private static final int COLOR_SEVERE_BG = 0xFF221f2e;
    private static final int COLOR_SEVERE_HOVER = 0xFF272436;
    
    private final String targetPlayer;
    private final List<MuteReason> reasons;
    private int menuX;
    private int menuY;
    private int menuWidth;
    private int menuHeight;
    private int hoveredIndex = -1;
    private boolean isOpen = false;
    
    public QuickMuteMenu(String targetPlayer) {
        this.targetPlayer = targetPlayer;
        this.reasons = createMuteReasons();
        
        // Вычисляем размеры сетки
        int rows = (int) Math.ceil((double) reasons.size() / COLUMNS);
        this.menuWidth = COLUMNS * BUTTON_WIDTH + (COLUMNS - 1) * BUTTON_SPACING + MENU_PADDING * 2;
        this.menuHeight = HEADER_HEIGHT + 1 + rows * BUTTON_HEIGHT + (rows - 1) * BUTTON_SPACING + MENU_PADDING * 2;
    }
    
    /**
     * Создает список причин для мута (БЕЗ ОПИСАНИЙ)
     */
    private List<MuteReason> createMuteReasons() {
        List<MuteReason> list = new ArrayList<>();
        
        // Нейтральные
        list.add(new MuteReason("3.2", "Капс", "30m", MuteCategory.NEUTRAL));
        list.add(new MuteReason("3.2.1", "Попрошайка", "1h", MuteCategory.NEUTRAL));
        list.add(new MuteReason("3.3", "Флуд / Спам", "1h", MuteCategory.NEUTRAL));
        
        // Оскорбления
        list.add(new MuteReason("3.4", "Оскорбление", "3h", MuteCategory.OFFENSE));
        list.add(new MuteReason("3.5", "Оск. админов", "12h", MuteCategory.OFFENSE));
        list.add(new MuteReason("3.6", "Оск. родных", "24h", MuteCategory.OFFENSE));
        
        // Серьезные
        list.add(new MuteReason("3.8", "Дискриминация", "3h", MuteCategory.SEVERE));
        list.add(new MuteReason("3.13", "18+ контент", "3h", MuteCategory.SEVERE));
        
        return list;
    }
    
    /**
     * Открывает меню с УМНЫМ позиционированием (никогда не выходит за границы)
     */
    public void open(int mouseX, int mouseY, int screenWidth, int screenHeight) {
        // Начальная позиция: справа и снизу от курсора
        this.menuX = mouseX + 10;
        this.menuY = mouseY + 10;
        
        // УМНАЯ ПРОВЕРКА ГРАНИЦ
        // Правая граница
        if (menuX + menuWidth > screenWidth - 10) {
            menuX = mouseX - menuWidth - 10; // Flip влево
            // Если все равно не влезает
            if (menuX < 10) {
                menuX = screenWidth - menuWidth - 10;
            }
        }
        
        // Нижняя граница
        if (menuY + menuHeight > screenHeight - 10) {
            menuY = mouseY - menuHeight - 10; // Flip вверх
            // Если все равно не влезает
            if (menuY < 10) {
                menuY = screenHeight - menuHeight - 10;
            }
        }
        
        // Левая граница (на всякий случай)
        if (menuX < 10) {
            menuX = 10;
        }
        
        // Верхняя граница (на всякий случай)
        if (menuY < 10) {
            menuY = 10;
        }
        
        this.isOpen = true;
        SoundManager.playClickSound();
    }
    
    public void close() {
        this.isOpen = false;
        this.hoveredIndex = -1;
    }
    
    public boolean isOpen() {
        return isOpen;
    }
    
    /**
     * Рендерит контекстное меню (КОМПАКТНАЯ СЕТКА)
     */
    public void render(DrawContext context, int mouseX, int mouseY) {
        if (!isOpen) return;
        
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Тень
        context.fill(menuX + 4, menuY + 4, menuX + menuWidth + 4, menuY + menuHeight + 4, COLOR_SHADOW);
        
        // Фон
        context.fill(menuX, menuY, menuX + menuWidth, menuY + menuHeight, COLOR_BG);
        
        // Рамка
        context.fill(menuX, menuY, menuX + menuWidth, menuY + 1, COLOR_BORDER);
        context.fill(menuX, menuY, menuX + 1, menuY + menuHeight, COLOR_BORDER);
        context.fill(menuX + menuWidth - 1, menuY, menuX + menuWidth, menuY + menuHeight, COLOR_BORDER);
        context.fill(menuX, menuY + menuHeight - 1, menuX + menuWidth, menuY + menuHeight, COLOR_BORDER);
        
        // Header
        context.fill(menuX, menuY, menuX + menuWidth, menuY + HEADER_HEIGHT, COLOR_HEADER);
        String headerText = "🔇 Быстрый мут: " + targetPlayer;
        context.drawText(client.textRenderer, headerText, menuX + MENU_PADDING, menuY + 10, COLOR_TEXT_PRIMARY, true);
        
        // Разделитель
        context.fill(menuX, menuY + HEADER_HEIGHT, menuX + menuWidth, menuY + HEADER_HEIGHT + 1, COLOR_BORDER);
        
        // Обновляем hover
        updateHover(mouseX, mouseY);
        
        // Рендерим кнопки в СЕТКЕ
        int startY = menuY + HEADER_HEIGHT + 1 + MENU_PADDING;
        int row = 0;
        int col = 0;
        
        for (int i = 0; i < reasons.size(); i++) {
            int btnX = menuX + MENU_PADDING + col * (BUTTON_WIDTH + BUTTON_SPACING);
            int btnY = startY + row * (BUTTON_HEIGHT + BUTTON_SPACING);
            
            renderButton(context, btnX, btnY, reasons.get(i), i == hoveredIndex, client);
            
            col++;
            if (col >= COLUMNS) {
                col = 0;
                row++;
            }
        }
    }
    
    /**
     * Рендерит одну кнопку (НОВЫЙ ФОРМАТ: "Код · Время")
     */
    private void renderButton(DrawContext context, int x, int y, MuteReason reason, boolean isHovered, MinecraftClient client) {
        // Фон кнопки
        int bgColor = isHovered ? 
            (reason.category == MuteCategory.NEUTRAL ? COLOR_NEUTRAL_HOVER :
             reason.category == MuteCategory.OFFENSE ? COLOR_OFFENSE_HOVER : COLOR_SEVERE_HOVER) :
            (reason.category == MuteCategory.NEUTRAL ? COLOR_NEUTRAL_BG :
             reason.category == MuteCategory.OFFENSE ? COLOR_OFFENSE_BG : COLOR_SEVERE_BG);
        
        context.fill(x, y, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, bgColor);
        
        // Рамка при hover
        if (isHovered) {
            context.fill(x, y, x + BUTTON_WIDTH, y + 1, 0xFF5588ff);
            context.fill(x, y, x + 1, y + BUTTON_HEIGHT, 0xFF5588ff);
            context.fill(x + BUTTON_WIDTH - 1, y, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, 0xFF5588ff);
            context.fill(x, y + BUTTON_HEIGHT - 1, x + BUTTON_WIDTH, y + BUTTON_HEIGHT, 0xFF5588ff);
        }
        
        // НОВЫЙ ФОРМАТ: "Код · Время"
        // Центрируем текст
        String displayText = reason.code + " · " + formatDuration(reason.duration);
        int textWidth = client.textRenderer.getWidth(displayText);
        int textX = x + (BUTTON_WIDTH - textWidth) / 2;
        int textY = y + (BUTTON_HEIGHT - 8) / 2;
        
        // Код (оранжевый)
        int codeWidth = client.textRenderer.getWidth(reason.code);
        context.drawText(client.textRenderer, reason.code, textX, textY, 0xFFf59e0b, true);
        
        // Разделитель " · " (серый)
        int separatorX = textX + codeWidth;
        context.drawText(client.textRenderer, " · ", separatorX, textY, COLOR_TEXT_MUTED, false);
        
        // Время (белый)
        int separatorWidth = client.textRenderer.getWidth(" · ");
        int timeX = separatorX + separatorWidth;
        context.drawText(client.textRenderer, formatDuration(reason.duration), timeX, textY, COLOR_TEXT_PRIMARY, false);
    }
    
    /**
     * Форматирует длительность для отображения
     */
    private String formatDuration(String duration) {
        // Преобразуем "30m" → "30м", "1h" → "1ч", "24h" → "1д"
        if (duration.endsWith("m")) {
            return duration.replace("m", "м");
        } else if (duration.endsWith("h")) {
            String hours = duration.replace("h", "");
            int h = Integer.parseInt(hours);
            if (h >= 24) {
                return (h / 24) + "д";
            }
            return hours + "ч";
        } else if (duration.endsWith("d")) {
            return duration.replace("d", "д");
        }
        return duration;
    }
    
    /**
     * Обновляет индекс наведенной кнопки
     */
    private void updateHover(int mouseX, int mouseY) {
        hoveredIndex = -1;
        
        int startY = menuY + HEADER_HEIGHT + 1 + MENU_PADDING;
        int row = 0;
        int col = 0;
        
        for (int i = 0; i < reasons.size(); i++) {
            int btnX = menuX + MENU_PADDING + col * (BUTTON_WIDTH + BUTTON_SPACING);
            int btnY = startY + row * (BUTTON_HEIGHT + BUTTON_SPACING);
            
            if (mouseX >= btnX && mouseX <= btnX + BUTTON_WIDTH &&
                mouseY >= btnY && mouseY <= btnY + BUTTON_HEIGHT) {
                hoveredIndex = i;
                return;
            }
            
            col++;
            if (col >= COLUMNS) {
                col = 0;
                row++;
            }
        }
    }
    
    /**
     * Обрабатывает клик по меню
     */
    public boolean handleClick(int mouseX, int mouseY) {
        if (!isOpen) return false;
        
        // Клик вне меню - закрыть
        if (mouseX < menuX || mouseX > menuX + menuWidth ||
            mouseY < menuY || mouseY > menuY + menuHeight) {
            close();
            return true;
        }
        
        // Клик по header - игнорировать
        if (mouseY < menuY + HEADER_HEIGHT + 1) {
            return true;
        }
        
        // Клик по кнопке
        if (hoveredIndex >= 0 && hoveredIndex < reasons.size()) {
            applyMute(reasons.get(hoveredIndex));
            close();
            return true;
        }
        
        return true;
    }
    
    /**
     * Применяет мут к игроку
     */
    private void applyMute(MuteReason reason) {
        SoundManager.playClickSound();
        AdminPanelClient.getPunishmentManager().issueMute(targetPlayer, reason.duration, reason.code);
        
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal("§a✓ " + targetPlayer + " замучен (" + 
                                                   reason.code + " " + reason.name + ", " + reason.duration + ")"), false);
        }
    }
    
    public boolean isMouseOver(int mouseX, int mouseY) {
        if (!isOpen) return false;
        return mouseX >= menuX && mouseX <= menuX + menuWidth &&
               mouseY >= menuY && mouseY <= menuY + menuHeight;
    }
    
    // ===== ВСПОМОГАТЕЛЬНЫЕ КЛАССЫ =====
    
    private enum MuteCategory {
        NEUTRAL, OFFENSE, SEVERE
    }
    
    private static class MuteReason {
        final String code;
        final String name;
        final String duration;
        final MuteCategory category;
        
        MuteReason(String code, String name, String duration, MuteCategory category) {
            this.code = code;
            this.name = name;
            this.duration = duration;
            this.category = category;
        }
    }
}
