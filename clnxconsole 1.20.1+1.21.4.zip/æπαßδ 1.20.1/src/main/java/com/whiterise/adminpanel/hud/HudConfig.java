package com.whiterise.adminpanel.hud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * Конфигурация HUD-элементов
 */
public class HudConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FILE = "config/clnxconsole_hud.json";
    
    // Настройка режима редактирования
    private static boolean editModeEnabled = true; // По умолчанию включен
    
    // Настройка фоновых частиц в GUI
    private static boolean backgroundParticlesEnabled = true; // По умолчанию включены
    
    // Настройки частиц
    private static int particleCount = 40; // По умолчанию 40 частиц
    private static float particleSpeed = 1.0f; // По умолчанию 1.0 (множитель скорости)
    
    public static boolean isEditModeEnabled() {
        return editModeEnabled;
    }
    
    public static void setEditModeEnabled(boolean enabled) {
        editModeEnabled = enabled;
    }
    
    public static boolean isBackgroundParticlesEnabled() {
        return backgroundParticlesEnabled;
    }
    
    public static void setBackgroundParticlesEnabled(boolean enabled) {
        backgroundParticlesEnabled = enabled;
    }
    
    public static int getParticleCount() {
        return particleCount;
    }
    
    public static void setParticleCount(int count) {
        particleCount = Math.max(10, Math.min(100, count)); // Ограничение 10-100
    }
    
    public static float getParticleSpeed() {
        return particleSpeed;
    }
    
    public static void setParticleSpeed(float speed) {
        particleSpeed = Math.max(0.1f, Math.min(3.0f, speed)); // Ограничение 0.1-3.0
    }
    
    /**
     * Сохраняет настройки HUD
     */
    public static void save(HudManager manager) {
        try {
            File configFile = new File(MinecraftClient.getInstance().runDirectory, CONFIG_FILE);
            configFile.getParentFile().mkdirs();
            
            JsonObject root = new JsonObject();
            
            // Сохраняем настройку режима редактирования
            root.addProperty("editModeEnabled", editModeEnabled);
            
            // Сохраняем настройку фоновых частиц
            root.addProperty("backgroundParticlesEnabled", backgroundParticlesEnabled);
            root.addProperty("particleCount", particleCount);
            root.addProperty("particleSpeed", particleSpeed);
            
            for (HudElement element : manager.getAllElements()) {
                JsonObject elementObj = new JsonObject();
                elementObj.addProperty("enabled", element.isEnabled());
                elementObj.addProperty("position", element.getPosition().name());
                elementObj.addProperty("scale", element.getScale());
                elementObj.addProperty("opacity", element.getOpacity());
                elementObj.addProperty("offsetX", element.getOffsetX());
                elementObj.addProperty("offsetY", element.getOffsetY());
                
                root.add(element.getId(), elementObj);
            }
            
            try (FileWriter writer = new FileWriter(configFile)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Загружает настройки HUD
     */
    public static void load(HudManager manager) {
        try {
            File configFile = new File(MinecraftClient.getInstance().runDirectory, CONFIG_FILE);
            
            if (!configFile.exists()) {
                return; // Используем дефолтные настройки
            }
            
            try (FileReader reader = new FileReader(configFile)) {
                JsonObject root = GSON.fromJson(reader, JsonObject.class);
                
                // Загружаем настройку режима редактирования
                if (root.has("editModeEnabled")) {
                    editModeEnabled = root.get("editModeEnabled").getAsBoolean();
                }
                
                // Загружаем настройку фоновых частиц
                if (root.has("backgroundParticlesEnabled")) {
                    backgroundParticlesEnabled = root.get("backgroundParticlesEnabled").getAsBoolean();
                }
                if (root.has("particleCount")) {
                    particleCount = root.get("particleCount").getAsInt();
                }
                if (root.has("particleSpeed")) {
                    particleSpeed = root.get("particleSpeed").getAsFloat();
                }
                
                for (HudElement element : manager.getAllElements()) {
                    if (root.has(element.getId())) {
                        JsonObject elementObj = root.getAsJsonObject(element.getId());
                        
                        if (elementObj.has("enabled")) {
                            element.setEnabled(elementObj.get("enabled").getAsBoolean());
                        }
                        if (elementObj.has("position")) {
                            element.setPosition(HudElement.HudPosition.valueOf(elementObj.get("position").getAsString()));
                        }
                        if (elementObj.has("scale")) {
                            element.setScale(elementObj.get("scale").getAsFloat());
                        }
                        if (elementObj.has("opacity")) {
                            element.setOpacity(elementObj.get("opacity").getAsFloat());
                        }
                        if (elementObj.has("offsetX")) {
                            element.setOffsetX(elementObj.get("offsetX").getAsInt());
                        }
                        if (elementObj.has("offsetY")) {
                            element.setOffsetY(elementObj.get("offsetY").getAsInt());
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
