package com.whiterise.adminpanel.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Generator for beautiful HUD icons (Figma style with #8F57AF color)
 */
public class IconGenerator {
    
    private static final int ICON_SIZE = 16;
    private static final Color BG_COLOR = new Color(0x31, 0x25, 0x41, 255); // Panel background
    private static final Color ICON_COLOR = new Color(0x8F, 0x57, 0xAF, 255); // Figma purple #8F57AF
    
    /**
     * Generates user/player icon (person silhouette) - Figma style
     */
    public static void generatePlayerIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupQuality(g2d);
        
        // Background - FULLY OPAQUE
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        // Icon in Figma purple
        g2d.setColor(ICON_COLOR);
        
        // Head (circle) - более округлый
        g2d.fillOval(5, 2, 6, 6);
        
        // Shoulders/body (trapezoid shape)
        int[] xPoints = {3, 13, 11, 5};
        int[] yPoints = {14, 14, 9, 9};
        g2d.fillPolygon(xPoints, yPoints, 4);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Generates FPS icon (monitor/screen) - Figma style
     */
    public static void generateFpsIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupQuality(g2d);
        
        // Background - FULLY OPAQUE
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Monitor outline (rounded rectangle)
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawRoundRect(2, 2, 12, 9, 2, 2);
        
        // Monitor stand
        g2d.fillRect(7, 11, 2, 2);
        g2d.fillRect(5, 13, 6, 1);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Generates ping icon (signal waves) - Figma style
     */
    public static void generatePingIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupQuality(g2d);
        
        // Background - FULLY OPAQUE
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // WiFi/signal arcs (curved lines)
        g2d.setStroke(new BasicStroke(1.5f));
        
        // Small arc
        g2d.drawArc(5, 7, 6, 6, 0, 180);
        
        // Medium arc
        g2d.drawArc(3, 5, 10, 10, 0, 180);
        
        // Large arc
        g2d.drawArc(1, 3, 14, 14, 0, 180);
        
        // Center dot
        g2d.fillOval(7, 12, 2, 2);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Generates time icon (clock) - Figma style
     */
    public static void generateTimeIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupQuality(g2d);
        
        // Background - FULLY OPAQUE
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Clock circle (outline)
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawOval(2, 2, 12, 12);
        
        // Clock hands
        g2d.setStroke(new BasicStroke(1.3f));
        g2d.drawLine(8, 8, 8, 5);  // Hour hand (up)
        g2d.drawLine(8, 8, 11, 8); // Minute hand (right)
        
        // Center dot
        g2d.fillOval(7, 7, 2, 2);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Generates punishment icon (gavel/hammer) - Figma style
     */
    public static void generatePunishmentIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupQuality(g2d);
        
        // Background - FULLY OPAQUE
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Gavel head (rotated rectangle)
        g2d.fillRoundRect(9, 3, 5, 3, 2, 2);
        
        // Gavel handle (thick line)
        g2d.setStroke(new BasicStroke(2f));
        g2d.drawLine(9, 5, 3, 11);
        
        // Base/block
        g2d.fillRoundRect(2, 12, 6, 2, 1, 1);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Generates logo icon (diamond/gem) - Figma style
     */
    public static void generateLogoIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupQuality(g2d);
        
        // Background - FULLY OPAQUE
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Triangle/play button style (modern)
        Path2D triangle = new Path2D.Float();
        triangle.moveTo(5, 3);      // Top left
        triangle.lineTo(5, 13);     // Bottom left
        triangle.lineTo(12, 8);     // Right point
        triangle.closePath();
        g2d.fill(triangle);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    private static void setupQuality(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    }
    
    private static void saveImage(BufferedImage image, String path) {
        try {
            File output = new File(path);
            output.getParentFile().mkdirs();
            ImageIO.write(image, "PNG", output);
            System.out.println("Generated icon: " + path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        String basePath = "src/main/resources/assets/whiterise_adminpanel/textures/icons";
        
        generateLogoIcon(basePath + "/logo.png");
        generatePlayerIcon(basePath + "/player.png");
        generateFpsIcon(basePath + "/fps.png");
        generatePingIcon(basePath + "/ping.png");
        generateTimeIcon(basePath + "/time.png");
        generatePunishmentIcon(basePath + "/punishment.png");
        
        System.out.println("All HUD icons generated!");
    }
}
