package com.whiterise.adminpanel.render.builders;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import com.whiterise.adminpanel.render.builders.impl.RectangleBuilder;

@Environment(EnvType.CLIENT)
public final class Builder {
   private static final RectangleBuilder RECTANGLE_BUILDER = new RectangleBuilder();

   public static RectangleBuilder rectangle() {
      return RECTANGLE_BUILDER;
   }
}