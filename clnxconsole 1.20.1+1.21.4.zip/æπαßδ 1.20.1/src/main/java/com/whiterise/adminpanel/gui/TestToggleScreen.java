package com.whiterise.adminpanel.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class TestToggleScreen extends Screen {
    private AnimatedToggle testToggle;
    
    public TestToggleScreen() {
        super(Text.literal("Тест переключателя"));
    }
    
    @Override
    protected void init() {
        // ОДИН переключатель по центру экрана (теперь с анимацией!)
        testToggle = new AnimatedToggle(
            width/2 - 25,  // X
            height/2 - 15, // Y  
            50,            // ширина
            30,            // высота
            false          // начальное состояние (выключен)
        );
        addDrawableChild(testToggle);
        
        // Кнопка назад
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Назад"), 
            button -> {
                close();
            }
        ).dimensions(20, 20, 60, 20).build());
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        
        // Заголовок
        context.drawCenteredTextWithShadow(textRenderer, "Тест переключателя", width/2, 50, 0xFFFFFF);
        
        // Состояние переключателя
        String stateText = "Состояние: " + (testToggle.isEnabled() ? "ВКЛ" : "ВЫКЛ");
        context.drawCenteredTextWithShadow(textRenderer, stateText, width/2, height/2 + 30, 
            testToggle.isEnabled() ? 0x00FF00 : 0xFF0000);
        
        super.render(context, mouseX, mouseY, delta);
    }
}
