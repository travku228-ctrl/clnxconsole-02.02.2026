package com.whiterise.adminpanel.manager;

import com.whiterise.adminpanel.data.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

import java.util.*;
import java.util.stream.Collectors;

public class PlayerManager {
    private static final int MAX_PLAYERS = 500; // Ограничение на случай больших серверов
    private final Map<String, PlayerData> players = new HashMap<>();
    private int tickCounter = 0;
    
    public void tick() {
        tickCounter++;
        // Обновляем список каждую секунду (20 тиков)
        if (tickCounter >= 20) {
            tickCounter = 0;
            updatePlayerList();
        }
    }
    
    private void updatePlayerList() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() == null) {
            // Если нет подключения - очищаем список
            clear();
            return;
        }
        
        Collection<PlayerListEntry> playerList = client.getNetworkHandler().getPlayerList();
        Set<String> currentPlayers = new HashSet<>();
        
        for (PlayerListEntry entry : playerList) {
            String username = entry.getProfile().getName();
            currentPlayers.add(username);
            
            if (!players.containsKey(username)) {
                players.put(username, new PlayerData(username));
            }
        }
        
        // Удаляем игроков, которые вышли
        players.keySet().retainAll(currentPlayers);
    }
    
    public void updatePlayerChatActivity(String username) {
        PlayerData player = players.get(username);
        if (player != null) {
            player.updateChatActivity();
        }
    }
    
    public List<PlayerData> getPlayersSortedByActivity() {
        return players.values().stream()
            .sorted((p1, p2) -> Long.compare(p2.getLastChatActivity(), p1.getLastChatActivity()))
            .collect(Collectors.toList());
    }
    
    public List<PlayerData> getPlayersSortedAlphabetically() {
        return players.values().stream()
            .sorted(Comparator.comparing(PlayerData::getUsername))
            .collect(Collectors.toList());
    }
    
    public List<PlayerData> searchPlayers(String query) {
        String lowerQuery = query.toLowerCase();
        return players.values().stream()
            .filter(p -> p.getUsername().toLowerCase().contains(lowerQuery))
            .sorted(Comparator.comparing(PlayerData::getUsername))
            .collect(Collectors.toList());
    }
    
    /**
     * Очищает список игроков
     * Вызывается при disconnect
     */
    public void clear() {
        players.clear();
        tickCounter = 0;
    }
    
    /**
     * Возвращает количество игроков
     */
    public int getPlayerCount() {
        return players.size();
    }
}
