package com.whiterise.adminpanel.render.builders.impl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import com.whiterise.adminpanel.render.builders.AbstractBuilder;
import com.whiterise.adminpanel.render.builders.states.QuadColorState;
import com.whiterise.adminpanel.render.builders.states.QuadRadiusState;
import com.whiterise.adminpanel.render.builders.states.SizeState;
import com.whiterise.adminpanel.render.renderers.impl.BuiltRectangle;
import java.awt.Color;

@Environment(EnvType.CLIENT)
public final class RectangleBuilder extends AbstractBuilder<BuiltRectangle> {
   private SizeState size;
   private QuadRadiusState radius;
   private QuadColorState color;
   private float smoothness;

   public RectangleBuilder size(SizeState size) {
      this.size = size;
      return this;
   }

   public RectangleBuilder size(float width, float height) {
      this.size = new SizeState(width, height);
      return this;
   }

   public RectangleBuilder radius(QuadRadiusState radius) {
      this.radius = radius;
      return this;
   }

   public RectangleBuilder radius(float radius) {
      this.radius = new QuadRadiusState(radius);
      return this;
   }

   public RectangleBuilder radius(float radius1, float radius2, float radius3, float radius4) {
      this.radius = new QuadRadiusState(radius1, radius2, radius3, radius4);
      return this;
   }

   public RectangleBuilder color(QuadColorState color) {
      this.color = color;
      return this;
   }

   public RectangleBuilder color(int color) {
      this.color = new QuadColorState(color);
      return this;
   }

   public RectangleBuilder color(Color color) {
      this.color = new QuadColorState(color);
      return this;
   }

   public RectangleBuilder gradient(int color1, int color2, int color3, int color4) {
      this.color = new QuadColorState(color1, color2, color3, color4);
      return this;
   }

   public RectangleBuilder smoothness(float smoothness) {
      this.smoothness = smoothness;
      return this;
   }

   protected BuiltRectangle _build() {
      return new BuiltRectangle(this.size, this.radius, this.color, this.smoothness);
   }

   protected void reset() {
      this.size = SizeState.NONE;
      this.radius = QuadRadiusState.NO_ROUND;
      this.color = QuadColorState.TRANSPARENT;
      this.smoothness = 1.0F;
   }
}