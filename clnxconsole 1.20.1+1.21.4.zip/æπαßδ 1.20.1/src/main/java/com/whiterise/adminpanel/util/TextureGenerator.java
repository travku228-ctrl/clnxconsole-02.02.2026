package com.whiterise.adminpanel.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Texture generator with perfectly smooth rounded corners
 */
public class TextureGenerator {
    
    /**
     * Generates smooth panel texture for 9-patch rendering (like in Figma)
     * Creates a 32x32 texture with 16px rounded corners
     */
    public static void generateSmoothPanel(String outputPath) {
        int size = 32;
        int radius = 16;
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();
        
        // MAXIMUM quality antialiasing
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        
        // Transparent background
        g2d.setComposite(AlphaComposite.Clear);
        g2d.fillRect(0, 0, size, size);
        g2d.setComposite(AlphaComposite.Src);
        
        // Draw white rounded rectangle (color will be applied via shader)
        g2d.setColor(Color.WHITE);
        g2d.fillRoundRect(0, 0, size, size, radius * 2, radius * 2);
        
        g2d.dispose();
        
        try {
            File output = new File(outputPath);
            output.getParentFile().mkdirs();
            ImageIO.write(image, "PNG", output);
            System.out.println("Generated smooth panel: " + outputPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Generates smooth corner texture (16x16 with perfect antialiasing)
     */
    public static void generateSmoothCorner(String outputPath) {
        int size = 16;
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();
        
        // MAXIMUM quality
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        
        // Transparent background
        g2d.setComposite(AlphaComposite.Clear);
        g2d.fillRect(0, 0, size, size);
        g2d.setComposite(AlphaComposite.Src);
        
        // Draw quarter circle (top-left corner)
        g2d.setColor(Color.WHITE);
        g2d.fillRoundRect(0, 0, size * 2, size * 2, size * 2, size * 2);
        
        g2d.dispose();
        
        try {
            File output = new File(outputPath);
            output.getParentFile().mkdirs();
            ImageIO.write(image, "PNG", output);
            System.out.println("Generated smooth corner: " + outputPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        String outputPath = "src/main/resources/assets/whiterise_adminpanel/textures/gui";
        generateSmoothPanel(outputPath + "/smooth_panel.png");
        generateSmoothCorner(outputPath + "/smooth_corner.png");
        System.out.println("All smooth textures generated!");
    }
}
