package com.whiterise.adminpanel.data;

import com.whiterise.adminpanel.util.ColoredText;

/**
 * МИНИМАЛЬНАЯ запись лога чата
 * Хранит RAW текст + время + Text объект + распарсенный ColoredText
 */
public class ChatLogEntry {
    private final String timeString; // [HH:mm:ss]
    private final String rawText;    // Сообщение как есть
    private final String hashKey;    // Для дедупликации
    private final net.minecraft.text.Text textObject; // Text объект с цветами (может быть null)
    private final ColoredText coloredText; // Распарсенный текст с цветами
    
    public ChatLogEntry(String rawText) {
        this.rawText = rawText;
        this.timeString = formatCurrentTime();
        this.hashKey = generateHashKey();
        this.textObject = null;
        this.coloredText = ColoredText.parse(rawText);
    }
    
    public ChatLogEntry(String rawText, net.minecraft.text.Text textObject) {
        this.rawText = rawText;
        this.timeString = formatCurrentTime();
        this.hashKey = generateHashKey();
        this.textObject = textObject;
        this.coloredText = ColoredText.parse(rawText);
    }
    
    /**
     * Форматирует текущее время в [HH:mm:ss]
     */
    private static String formatCurrentTime() {
        java.time.LocalTime time = java.time.LocalTime.now();
        return String.format("[%02d:%02d:%02d]", time.getHour(), time.getMinute(), time.getSecond());
    }
    
    /**
     * Генерирует ключ для дедупликации: timeBucket + rawText
     * timeBucket = текущая секунда (HH:mm:ss)
     */
    private String generateHashKey() {
        return timeString + "|" + rawText;
    }
    
    public String getTimeString() {
        return timeString;
    }
    
    public String getRawText() {
        return rawText;
    }
    
    public String getHashKey() {
        return hashKey;
    }
    
    public net.minecraft.text.Text getTextObject() {
        return textObject;
    }
    
    public ColoredText getColoredText() {
        return coloredText;
    }
    
    /**
     * Проверяет, является ли сообщение CAPS
     * Правила: ≥6 заглавных букв подряд ИЛИ ≥50% заглавных букв
     */
    public boolean isCaps() {
        int totalLetters = 0;
        int upperLetters = 0;
        int consecutiveUpper = 0;
        int maxConsecutiveUpper = 0;
        
        for (char c : rawText.toCharArray()) {
            // Проверяем буквы (A-Z, А-Я, Ё)
            if (Character.isLetter(c)) {
                totalLetters++;
                
                if (Character.isUpperCase(c)) {
                    upperLetters++;
                    consecutiveUpper++;
                    maxConsecutiveUpper = Math.max(maxConsecutiveUpper, consecutiveUpper);
                } else {
                    consecutiveUpper = 0;
                }
            } else {
                consecutiveUpper = 0;
            }
        }
        
        // Короткие сообщения не считаем CAPS
        if (totalLetters < 6) {
            return false;
        }
        
        // Правило 1: ≥6 заглавных подряд
        if (maxConsecutiveUpper >= 6) {
            return true;
        }
        
        // Правило 2: ≥50% заглавных букв
        double upperPercentage = (double) upperLetters / totalLetters;
        return upperPercentage >= 0.5;
    }
}
