package com.whiterise.adminpanel.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * High-quality icon generator with 64x64 base resolution
 * Icons are then scaled down to 16x16 with maximum quality
 */
public class HighQualityIconGenerator {
    
    private static final int BASE_SIZE = 256; // Generate at 256x256 for MAXIMUM quality
    private static final int FINAL_SIZE = 16; // Scale down to 16x16
    private static final Color BG_COLOR = new Color(0x31, 0x25, 0x41, 255); // #312541
    private static final Color ICON_COLOR = new Color(0x8F, 0x57, 0xAF, 255); // #8F57AF
    
    /**
     * Generates high-quality player/user icon
     */
    public static void generatePlayerIcon(String outputPath) {
        BufferedImage baseImage = new BufferedImage(BASE_SIZE, BASE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = baseImage.createGraphics();
        setupMaxQuality(g2d);
        
        // Background
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, BASE_SIZE, BASE_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Head (circle) - centered and larger
        int headSize = 80;
        int headX = (BASE_SIZE - headSize) / 2;
        int headY = 48;
        g2d.fillOval(headX, headY, headSize, headSize);
        
        // Body (rounded trapezoid)
        Path2D body = new Path2D.Float();
        body.moveTo(64, BASE_SIZE - 32); // Bottom left
        body.lineTo(80, 144); // Top left (shoulders)
        body.curveTo(96, 128, 160, 128, 176, 144); // Curved shoulders
        body.lineTo(192, BASE_SIZE - 32); // Bottom right
        body.curveTo(176, BASE_SIZE - 16, 80, BASE_SIZE - 16, 64, BASE_SIZE - 32); // Rounded bottom
        body.closePath();
        g2d.fill(body);
        
        g2d.dispose();
        
        // Scale down to 16x16 with high quality
        BufferedImage finalImage = scaleToFinal(baseImage);
        saveImage(finalImage, outputPath);
    }
    
    /**
     * Generates high-quality FPS/monitor icon
     */
    public static void generateFpsIcon(String outputPath) {
        BufferedImage baseImage = new BufferedImage(BASE_SIZE, BASE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = baseImage.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, BASE_SIZE, BASE_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Monitor screen (rounded rectangle)
        g2d.setStroke(new BasicStroke(14f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        RoundRectangle2D screen = new RoundRectangle2D.Float(32, 32, 192, 128, 24, 24);
        g2d.draw(screen);
        
        // Inner screen detail
        g2d.setStroke(new BasicStroke(8f));
        g2d.drawRect(48, 48, 160, 96);
        
        // Monitor stand
        g2d.setStroke(new BasicStroke(16f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.drawLine(128, 160, 128, 192);
        
        // Monitor base
        g2d.setStroke(new BasicStroke(12f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.drawLine(80, 208, 176, 208);
        
        g2d.dispose();
        
        BufferedImage finalImage = scaleToFinal(baseImage);
        saveImage(finalImage, outputPath);
    }
    
    /**
     * Generates high-quality ping/wifi icon
     */
    public static void generatePingIcon(String outputPath) {
        BufferedImage baseImage = new BufferedImage(BASE_SIZE, BASE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = baseImage.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, BASE_SIZE, BASE_SIZE);
        
        g2d.setColor(ICON_COLOR);
        g2d.setStroke(new BasicStroke(14f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // WiFi arcs (3 levels)
        // Small arc
        g2d.drawArc(80, 112, 96, 96, 0, 180);
        
        // Medium arc
        g2d.drawArc(48, 80, 160, 160, 0, 180);
        
        // Large arc
        g2d.drawArc(16, 48, 224, 224, 0, 180);
        
        // Center dot (router)
        g2d.fillOval(112, 192, 32, 32);
        
        g2d.dispose();
        
        BufferedImage finalImage = scaleToFinal(baseImage);
        saveImage(finalImage, outputPath);
    }
    
    /**
     * Generates high-quality time/clock icon
     */
    public static void generateTimeIcon(String outputPath) {
        BufferedImage baseImage = new BufferedImage(BASE_SIZE, BASE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = baseImage.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, BASE_SIZE, BASE_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Clock circle
        g2d.setStroke(new BasicStroke(14f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.drawOval(32, 32, 192, 192);
        
        // Hour markers (12, 3, 6, 9)
        g2d.setStroke(new BasicStroke(10f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        // 12 o'clock
        g2d.drawLine(128, 48, 128, 72);
        // 3 o'clock
        g2d.drawLine(208, 128, 184, 128);
        // 6 o'clock
        g2d.drawLine(128, 208, 128, 184);
        // 9 o'clock
        g2d.drawLine(48, 128, 72, 128);
        
        // Clock hands
        g2d.setStroke(new BasicStroke(12f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        // Hour hand (pointing to 10)
        g2d.drawLine(128, 128, 88, 88);
        // Minute hand (pointing to 2)
        g2d.drawLine(128, 128, 168, 80);
        
        // Center dot
        g2d.fillOval(112, 112, 32, 32);
        
        g2d.dispose();
        
        BufferedImage finalImage = scaleToFinal(baseImage);
        saveImage(finalImage, outputPath);
    }
    
    /**
     * Generates high-quality punishment/gavel icon
     */
    public static void generatePunishmentIcon(String outputPath) {
        BufferedImage baseImage = new BufferedImage(BASE_SIZE, BASE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = baseImage.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, BASE_SIZE, BASE_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Gavel head (rotated rectangle)
        g2d.rotate(Math.toRadians(-30), 128, 128);
        RoundRectangle2D gavelHead = new RoundRectangle2D.Float(144, 48, 80, 40, 16, 16);
        g2d.fill(gavelHead);
        g2d.rotate(Math.toRadians(30), 128, 128);
        
        // Gavel handle (thick line)
        g2d.setStroke(new BasicStroke(20f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.drawLine(144, 80, 64, 160);
        
        // Base/block
        RoundRectangle2D base = new RoundRectangle2D.Float(32, 192, 96, 32, 12, 12);
        g2d.fill(base);
        
        g2d.dispose();
        
        BufferedImage finalImage = scaleToFinal(baseImage);
        saveImage(finalImage, outputPath);
    }
    
    /**
     * Generates high-quality logo/play icon
     */
    public static void generateLogoIcon(String outputPath) {
        BufferedImage baseImage = new BufferedImage(BASE_SIZE, BASE_SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = baseImage.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, BASE_SIZE, BASE_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        // Play button triangle (centered)
        Path2D triangle = new Path2D.Float();
        triangle.moveTo(80, 48);      // Top left
        triangle.lineTo(80, 208);     // Bottom left
        triangle.lineTo(192, 128);    // Right point
        triangle.closePath();
        g2d.fill(triangle);
        
        // Optional: Add subtle border for depth
        g2d.setStroke(new BasicStroke(8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.draw(triangle);
        
        g2d.dispose();
        
        BufferedImage finalImage = scaleToFinal(baseImage);
        saveImage(finalImage, outputPath);
    }
    
    /**
     * Scales image from BASE_SIZE to FINAL_SIZE with maximum quality
     */
    private static BufferedImage scaleToFinal(BufferedImage baseImage) {
        BufferedImage finalImage = new BufferedImage(FINAL_SIZE, FINAL_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = finalImage.createGraphics();
        
        // Maximum quality scaling
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        
        g2d.drawImage(baseImage, 0, 0, FINAL_SIZE, FINAL_SIZE, null);
        g2d.dispose();
        
        return finalImage;
    }
    
    private static void setupMaxQuality(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }
    
    private static void saveImage(BufferedImage image, String path) {
        try {
            File output = new File(path);
            output.getParentFile().mkdirs();
            ImageIO.write(image, "PNG", output);
            System.out.println("✓ Generated: " + new File(path).getName());
        } catch (IOException e) {
            System.err.println("✗ Error saving " + path + ": " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        String basePath = "C:/Users/doooo/Desktop/custom-mods/clnxconsole/src/main/resources/assets/whiterise_adminpanel/textures/icons";
        
        System.out.println("=== Generating HIGH QUALITY icons (256x256 → 16x16) ===\n");
        System.out.println("Background: #312541");
        System.out.println("Icon color: #8F57AF (Figma purple)\n");
        
        generateLogoIcon(basePath + "/logo.png");
        generatePlayerIcon(basePath + "/player.png");
        generateFpsIcon(basePath + "/fps.png");
        generatePingIcon(basePath + "/ping.png");
        generateTimeIcon(basePath + "/time.png");
        generatePunishmentIcon(basePath + "/punishment.png");
        
        System.out.println("\n=== All icons generated successfully! ===");
        System.out.println("Icons are now 16x16 with high quality rendering");
    }
}
