package com.whiterise.adminpanel.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Utility to add solid background to existing icons and colorize them
 */
public class IconBackgroundAdder {
    
    private static final int ICON_SIZE = 16;
    private static final Color BG_COLOR = new Color(0x31, 0x25, 0x41, 255); // Panel background #312541
    private static final Color ICON_COLOR = new Color(0x8F, 0x57, 0xAF, 255); // Figma purple #8F57AF
    
    /**
     * Adds solid background to an icon
     */
    public static void addBackgroundToIcon(String inputPath, String outputPath) {
        try {
            // Load original icon
            File inputFile = new File(inputPath);
            BufferedImage originalIcon = ImageIO.read(inputFile);
            
            // Get dimensions
            int width = originalIcon.getWidth();
            int height = originalIcon.getHeight();
            
            // Create new image with RGB (no alpha)
            BufferedImage newImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = newImage.createGraphics();
            
            // Enable antialiasing
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            
            // Fill background with panel color
            g2d.setColor(BG_COLOR);
            g2d.fillRect(0, 0, width, height);
            
            // Draw original icon on top
            g2d.drawImage(originalIcon, 0, 0, null);
            
            g2d.dispose();
            
            // Save result
            File outputFile = new File(outputPath);
            outputFile.getParentFile().mkdirs();
            ImageIO.write(newImage, "PNG", outputFile);
            
            System.out.println("Processed: " + inputPath + " -> " + outputPath);
            
        } catch (IOException e) {
            System.err.println("Error processing " + inputPath + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Resizes icon to 16x16 if needed, adds background, and colorizes to purple
     */
    public static void resizeAndAddBackground(String inputPath, String outputPath) {
        try {
            // Load original icon
            File inputFile = new File(inputPath);
            BufferedImage originalIcon = ImageIO.read(inputFile);
            
            // Create new 16x16 image with RGB (no alpha)
            BufferedImage newImage = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = newImage.createGraphics();
            
            // Enable MAXIMUM quality rendering
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
            
            // Fill background with panel color
            g2d.setColor(BG_COLOR);
            g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
            
            // Calculate scaling to fit icon in 16x16 while maintaining aspect ratio
            int originalWidth = originalIcon.getWidth();
            int originalHeight = originalIcon.getHeight();
            
            double scale = Math.min(
                (double) ICON_SIZE / originalWidth,
                (double) ICON_SIZE / originalHeight
            );
            
            int scaledWidth = (int) (originalWidth * scale);
            int scaledHeight = (int) (originalHeight * scale);
            
            // Center the icon
            int x = (ICON_SIZE - scaledWidth) / 2;
            int y = (ICON_SIZE - scaledHeight) / 2;
            
            // Create colorized version of the icon
            BufferedImage colorizedIcon = colorizeIcon(originalIcon, ICON_COLOR);
            
            // Draw scaled colorized icon
            g2d.drawImage(colorizedIcon, x, y, scaledWidth, scaledHeight, null);
            
            g2d.dispose();
            
            // Save result
            File outputFile = new File(outputPath);
            outputFile.getParentFile().mkdirs();
            ImageIO.write(newImage, "PNG", outputFile);
            
            System.out.println("Resized and colorized: " + inputPath + " -> " + outputPath);
            
        } catch (IOException e) {
            System.err.println("Error processing " + inputPath + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Colorizes an icon to the specified color (preserves brightness)
     */
    private static BufferedImage colorizeIcon(BufferedImage original, Color targetColor) {
        BufferedImage colorized = new BufferedImage(
            original.getWidth(), 
            original.getHeight(), 
            BufferedImage.TYPE_INT_ARGB
        );
        
        for (int y = 0; y < original.getHeight(); y++) {
            for (int x = 0; x < original.getWidth(); x++) {
                int pixel = original.getRGB(x, y);
                
                // Extract alpha and brightness
                int alpha = (pixel >> 24) & 0xFF;
                int red = (pixel >> 16) & 0xFF;
                int green = (pixel >> 8) & 0xFF;
                int blue = pixel & 0xFF;
                
                // Calculate brightness (0-255)
                float brightness = (red + green + blue) / 3.0f / 255.0f;
                
                // Apply target color with brightness
                int newRed = (int) (targetColor.getRed() * brightness);
                int newGreen = (int) (targetColor.getGreen() * brightness);
                int newBlue = (int) (targetColor.getBlue() * brightness);
                
                // Combine with alpha
                int newPixel = (alpha << 24) | (newRed << 16) | (newGreen << 8) | newBlue;
                colorized.setRGB(x, y, newPixel);
            }
        }
        
        return colorized;
    }
    
    public static void main(String[] args) {
        // Use absolute paths
        String basePath = "C:/Users/doooo/Desktop/custom-mods/clnxconsole/src/main/resources/assets/whiterise_adminpanel/textures/icons";
        String sourcePath = "C:/Users/doooo/Downloads/icons/icons";
        
        // Process ALL icons with resize, background, and purple colorization
        System.out.println("Processing downloaded icons with background and purple color (#8F57AF)...\n");
        
        // Map downloaded icons to HUD icons
        System.out.println("Processing: Time icon...");
        resizeAndAddBackground(sourcePath + "/action/ic_schedule_48px.png", basePath + "/time.png");
        
        System.out.println("Processing: Ping icon...");
        resizeAndAddBackground(sourcePath + "/action/ic_settings_input_antenna_48px.png", basePath + "/ping.png");
        
        System.out.println("Processing: Player icon...");
        resizeAndAddBackground(sourcePath + "/action/ic_supervisor_account_48px.png", basePath + "/player.png");
        
        System.out.println("Processing: FPS icon...");
        resizeAndAddBackground(sourcePath + "/hardware/ic_desktop_windows_48px.png", basePath + "/fps.png");
        
        // Keep generated icons for logo and punishment
        System.out.println("\nKeeping generated icons for logo and punishment...");
        
        System.out.println("\n✓ All icons processed successfully!");
        System.out.println("✓ Icons now have solid #312541 background");
        System.out.println("✓ Icons are colorized to #8F57AF (Figma purple)");
        System.out.println("✓ All icons are 16x16 pixels with maximum quality");
    }
    
    /**
     * Regenerates FPS icon with high quality
     */
    private static void regenerateFpsIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        g2d.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2d.drawRoundRect(2, 2, 12, 9, 2, 2);
        g2d.fillRect(7, 11, 2, 2);
        g2d.fillRect(5, 13, 6, 1);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Regenerates Ping icon with high quality
     */
    private static void regeneratePingIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        g2d.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        g2d.drawArc(5, 7, 6, 6, 0, 180);
        g2d.drawArc(3, 5, 10, 10, 0, 180);
        g2d.drawArc(1, 3, 14, 14, 0, 180);
        g2d.fillOval(7, 12, 2, 2);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    /**
     * Regenerates Logo icon with high quality
     */
    private static void regenerateLogoIcon(String outputPath) {
        BufferedImage image = new BufferedImage(ICON_SIZE, ICON_SIZE, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        setupMaxQuality(g2d);
        
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, ICON_SIZE, ICON_SIZE);
        
        g2d.setColor(ICON_COLOR);
        
        int[] xPoints = {5, 5, 12};
        int[] yPoints = {3, 13, 8};
        g2d.fillPolygon(xPoints, yPoints, 3);
        
        g2d.dispose();
        saveImage(image, outputPath);
    }
    
    private static void setupMaxQuality(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
    }
    
    private static void saveImage(BufferedImage image, String path) {
        try {
            File output = new File(path);
            output.getParentFile().mkdirs();
            ImageIO.write(image, "PNG", output);
            System.out.println("Generated: " + path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
