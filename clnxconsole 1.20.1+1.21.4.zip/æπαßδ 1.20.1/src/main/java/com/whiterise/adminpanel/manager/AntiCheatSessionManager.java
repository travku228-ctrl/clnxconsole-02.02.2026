package com.whiterise.adminpanel.manager;

/**
 * Менеджер сессий проверки на читы.
 * Сессия существует независимо от GUI и сохраняется при закрытии интерфейса.
 * Только действия "Отпустить" или "Забанить" завершают сессию.
 */
public class AntiCheatSessionManager {
    private static AntiCheatSession activeSession = null;
    
    /**
     * Начинает новую сессию проверки
     */
    public static void startSession(String playerName) {
        activeSession = new AntiCheatSession(playerName, System.currentTimeMillis());
    }
    
    /**
     * Завершает активную сессию
     */
    public static void endSession() {
        activeSession = null;
    }
    
    /**
     * Проверяет, есть ли активная сессия
     */
    public static boolean hasActiveSession() {
        return activeSession != null;
    }
    
    /**
     * Возвращает активную сессию (или null)
     */
    public static AntiCheatSession getActiveSession() {
        return activeSession;
    }
    
    /**
     * Класс сессии проверки
     */
    public static class AntiCheatSession {
        private final String playerName;
        private final long startTime;
        private static final long CHECK_DURATION = 5 * 60 * 1000; // 5 минут
        
        public AntiCheatSession(String playerName, long startTime) {
            this.playerName = playerName;
            this.startTime = startTime;
        }
        
        public String getPlayerName() {
            return playerName;
        }
        
        public long getStartTime() {
            return startTime;
        }
        
        public long getElapsedTime() {
            return System.currentTimeMillis() - startTime;
        }
        
        public long getRemainingTime() {
            return Math.max(0, CHECK_DURATION - getElapsedTime());
        }
        
        public boolean isTimeExpired() {
            return getRemainingTime() <= 0;
        }
        
        public String getFormattedRemainingTime() {
            long remaining = getRemainingTime();
            int minutes = (int) (remaining / 60000);
            int seconds = (int) ((remaining % 60000) / 1000);
            return String.format("%d:%02d", minutes, seconds);
        }
    }
}
