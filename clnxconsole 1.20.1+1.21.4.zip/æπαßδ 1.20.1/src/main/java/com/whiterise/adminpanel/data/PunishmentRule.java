package com.whiterise.adminpanel.data;

import java.util.ArrayList;
import java.util.List;

public class PunishmentRule {
    private final String code;
    private final String reason;
    private final String duration;
    private final boolean isSeparator;
    
    public PunishmentRule(String code, String reason, String duration) {
        this.code = code;
        this.reason = reason;
        this.duration = duration;
        this.isSeparator = false;
    }
    
    // Конструктор для разделителя
    private PunishmentRule() {
        this.code = "";
        this.reason = "";
        this.duration = "";
        this.isSeparator = true;
    }
    
    public static PunishmentRule separator() {
        return new PunishmentRule();
    }
    
    public boolean isSeparator() {
        return isSeparator;
    }
    
    public String getCode() {
        return code;
    }
    
    public String getReason() {
        return reason;
    }
    
    public String getDuration() {
        return duration;
    }
    
    /**
     * Возвращает время в русском формате (ч, д, м вместо h, d, m)
     */
    public String getDisplayDuration() {
        if (duration == null || duration.equals("-")) {
            return duration;
        }
        
        // Заменяем английские суффиксы на русские
        return duration
            .replace("h", "ч")
            .replace("d", "д")
            .replace("m", "м")
            .replace("s", "с");
    }
    
    public static List<PunishmentRule> getMuteRules() {
        List<PunishmentRule> rules = new ArrayList<>();
        
        // === БЫСТРЫЕ НАКАЗАНИЯ ===
        rules.add(new PunishmentRule("3.2", "Капс", "30m"));
        rules.add(new PunishmentRule("3.2.1", "Попрошайка", "1h"));
        rules.add(new PunishmentRule("3.3", "Спам / Флуд", "1h"));
        rules.add(new PunishmentRule("3.4", "Оскорбление", "3h"));
        rules.add(new PunishmentRule("3.5", "Оскорбление администрации", "12h"));
        rules.add(new PunishmentRule("3.6", "Оскорбление родителей", "12h"));
        rules.add(new PunishmentRule("3.13", "18+ контент", "3h"));
        
        // Разделитель
        rules.add(PunishmentRule.separator());
        
        // === ВСЕ ОСТАЛЬНЫЕ ПРИЧИНЫ ===
        rules.add(new PunishmentRule("3.1", "Реклама", "3h"));
        rules.add(new PunishmentRule("3.2", "Капс", "30m"));
        rules.add(new PunishmentRule("3.2.1", "Попрошайка", "1h"));
        rules.add(new PunishmentRule("3.3", "Спам / Флуд", "1h"));
        rules.add(new PunishmentRule("3.4", "Оскорбление", "3h"));
        rules.add(new PunishmentRule("3.5", "Оскорбление администрации", "12h"));
        rules.add(new PunishmentRule("3.6", "Оскорбление родителей", "12h"));
        rules.add(new PunishmentRule("3.7", "Организованный флуд", "3h"));
        rules.add(new PunishmentRule("3.8", "Дискриминация", "3h"));
        rules.add(new PunishmentRule("3.9.1", "Нацизм / Расизм", "8h"));
        rules.add(new PunishmentRule("3.9.2", "Терроризм", "12h"));
        rules.add(new PunishmentRule("3.9.3", "Политические призывы", "12h"));
        rules.add(new PunishmentRule("3.10", "Ложные угрозы", "3h"));
        rules.add(new PunishmentRule("3.12", "Введение в заблуждение", "6h"));
        rules.add(new PunishmentRule("3.13", "18+ контент", "3h"));
        rules.add(new PunishmentRule("3.14", "Подстрекательство на нарушение", "6h"));
        return rules;
    }
    
    public static List<PunishmentRule> getBanRules() {
        List<PunishmentRule> rules = new ArrayList<>();
        
        // === БЫСТРЫЕ НАКАЗАНИЯ ===
        rules.add(new PunishmentRule("2.4", "Читы", "14d/21d"));
        rules.add(new PunishmentRule("2.4.3", "Обход бана", "42d"));
        rules.add(new PunishmentRule("2.6", "Запрещённый никнейм", "999d"));
        
        // Разделитель
        rules.add(PunishmentRule.separator());
        
        // === ВСЕ ОСТАЛЬНЫЕ ПРИЧИНЫ ===
        rules.add(new PunishmentRule("2.1", "Выдача себя за администрацию", "1d"));
        rules.add(new PunishmentRule("2.3", "Запрещённая постройка", "3d"));
        rules.add(new PunishmentRule("2.4", "Читы", "14d/21d"));
        rules.add(new PunishmentRule("2.4.1", "Ложный SPEC", "3h"));
        rules.add(new PunishmentRule("2.4.2", "Тим с читером", "14d"));
        rules.add(new PunishmentRule("2.4.3", "Обход бана", "42d"));
        rules.add(new PunishmentRule("2.6", "Запрещённый никнейм", "999d"));
        rules.add(new PunishmentRule("3.1", "Реклама", "999d"));
        return rules;
    }
    
    public static List<PunishmentRule> getIPBanRules() {
        List<PunishmentRule> rules = new ArrayList<>();
        rules.add(new PunishmentRule("2.2", "ФП Селл", "999d"));
        rules.add(new PunishmentRule("2.2.1", "Взлом", "999d"));
        rules.add(new PunishmentRule("3.2.2", "Обход мута", "1h"));
        rules.add(new PunishmentRule("3.11", "Доксинг / Сватинг", "999d"));
        return rules;
    }
    
    public static List<PunishmentRule> getOtherRules() {
        List<PunishmentRule> rules = new ArrayList<>();
        rules.add(new PunishmentRule("unmute", "Размут", "-"));
        rules.add(new PunishmentRule("ipban", "IP-бан", "999d"));
        return rules;
    }
}
