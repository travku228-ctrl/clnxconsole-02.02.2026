package com.whiterise.adminpanel.data;

import java.util.ArrayList;
import java.util.List;

public class PunishmentRecord {
    private final String username;
    private final PunishmentType type;
    private final String duration;
    private final String reason;
    private final long timestamp;
    private final List<ChatMessage> lastMessages;
    
    public PunishmentRecord(String username, PunishmentType type, String duration, String reason, List<ChatMessage> lastMessages) {
        this.username = username;
        this.type = type;
        this.duration = duration;
        this.reason = reason;
        this.timestamp = System.currentTimeMillis();
        this.lastMessages = new ArrayList<>(lastMessages);
    }
    
    public String getUsername() {
        return username;
    }
    
    public PunishmentType getType() {
        return type;
    }
    
    public String getDuration() {
        return duration;
    }
    
    public String getReason() {
        return reason;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public List<ChatMessage> getLastMessages() {
        return lastMessages;
    }
    
    public enum PunishmentType {
        MUTE("Мут"),
        BAN("Бан"),
        IP_BAN("IP-бан"),
        UNMUTE("Размут"),
        UNBAN("Разбан");
        
        private final String displayName;
        
        PunishmentType(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() {
            return displayName;
        }
    }
}
