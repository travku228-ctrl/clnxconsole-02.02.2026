package com.whiterise.adminpanel.mixin;

import com.whiterise.adminpanel.AdminPanelClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перехватывает отправку команд в чат
 * Отслеживает команды наказаний (/mute, /ban и т.д.)
 */
@Mixin(ClientPlayNetworkHandler.class)
public class ClientCommandMixin {
    
    @Inject(method = "sendChatMessage", at = @At("HEAD"))
    private void onSendChatMessage(String message, CallbackInfo ci) {
        try {
            if (message == null || message.isEmpty()) {
                return;
            }
            
            // Проверяем, является ли это командой наказания
            if (message.startsWith("/")) {
                trackPunishmentCommand(message);
            }
        } catch (Exception e) {
            // Игнорируем ошибки
        }
    }
    
    @Inject(method = "sendChatCommand", at = @At("HEAD"))
    private void onSendChatCommand(String command, CallbackInfo ci) {
        try {
            if (command == null || command.isEmpty()) {
                return;
            }
            
            // Добавляем "/" если его нет
            String fullCommand = command.startsWith("/") ? command : "/" + command;
            trackPunishmentCommand(fullCommand);
        } catch (Exception e) {
            // Игнорируем ошибки
        }
    }
    
    /**
     * Отслеживает команды наказаний
     */
    private void trackPunishmentCommand(String command) {
        String[] parts = command.split(" ");
        if (parts.length < 2) {
            return; // Недостаточно аргументов
        }
        
        String cmd = parts[0].toLowerCase();
        String targetNickname = parts[1];
        String duration = "-";
        String reason = "-";
        
        // Определяем тип наказания
        com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType type = null;
        
        switch (cmd) {
            case "/mute":
            case "/tempmute":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.MUTE;
                if (parts.length >= 3) {
                    duration = parts[2];
                }
                if (parts.length >= 4) {
                    reason = String.join(" ", java.util.Arrays.copyOfRange(parts, 3, parts.length));
                }
                break;
                
            case "/ban":
            case "/tempban":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.BAN;
                if (parts.length >= 3) {
                    duration = parts[2];
                }
                if (parts.length >= 4) {
                    reason = String.join(" ", java.util.Arrays.copyOfRange(parts, 3, parts.length));
                }
                break;
                
            case "/banip":
            case "/ipban":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.IP_BAN;
                if (parts.length >= 3) {
                    duration = parts[2];
                }
                if (parts.length >= 4) {
                    reason = String.join(" ", java.util.Arrays.copyOfRange(parts, 3, parts.length));
                }
                break;
                
            case "/unmute":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNMUTE;
                break;
                
            case "/unban":
                type = com.whiterise.adminpanel.data.PunishmentRecord.PunishmentType.UNBAN;
                break;
                
            default:
                return; // Не команда наказания
        }
        
        // Добавляем в историю наказаний
        if (type != null) {
            com.whiterise.adminpanel.data.PunishmentRecord record = new com.whiterise.adminpanel.data.PunishmentRecord(
                targetNickname,
                type,
                duration,
                reason,
                new java.util.ArrayList<>()
            );
            AdminPanelClient.getPunishmentManager().addPunishment(record);
        }
    }
}
