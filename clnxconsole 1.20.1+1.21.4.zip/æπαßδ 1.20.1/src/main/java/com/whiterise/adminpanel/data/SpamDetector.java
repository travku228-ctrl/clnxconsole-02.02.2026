package com.whiterise.adminpanel.data;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Детектор спама и капса в чате
 * Отслеживает повторяющиеся сообщения и использование CAPS LOCK
 */
public class SpamDetector {
    // Хранилище сообщений: никнейм -> список сообщений с временем
    private static final Map<String, List<MessageEntry>> playerMessages = new ConcurrentHashMap<>();
    
    // Хранилище нарушителей капса: никнейм -> true
    private static final Map<String, Long> capsViolators = new ConcurrentHashMap<>();
    
    // Хранилище нарушителей флуда: никнейм -> true
    private static final Map<String, Long> floodViolators = new ConcurrentHashMap<>();
    
    // Время жизни сообщения (60 секунд)
    private static final long MESSAGE_LIFETIME = 60000;
    
    // Время жизни метки капса (60 секунд)
    private static final long CAPS_MARK_LIFETIME = 60000;
    
    // Время жизни метки флуда (60 секунд)
    private static final long FLOOD_MARK_LIFETIME = 60000;
    
    // Количество одинаковых сообщений для детекта спама
    private static final int SPAM_THRESHOLD = 3;
    
    // Минимум символов для проверки капса
    private static final int CAPS_MIN_LENGTH = 6;
    
    // Процент капса для нарушения
    private static final double CAPS_THRESHOLD = 0.5; // 50%
    
    // Минимум символов для проверки флуда
    private static final int FLOOD_MIN_LENGTH = 12;
    
    // Максимальный процент повторяющихся символов для флуда
    private static final double FLOOD_REPEAT_THRESHOLD = 0.6; // 60%
    
    /**
     * Добавляет сообщение от игрока
     * @param username Никнейм игрока
     * @param message Текст сообщения
     * @return true если обнаружен спам
     */
    public static boolean addMessage(String username, String message) {
        if (username == null || message == null || message.isEmpty()) {
            return false;
        }
        
        long now = System.currentTimeMillis();
        
        // Проверяем капс
        if (isCapsMessage(message)) {
            capsViolators.put(username, now);
        }
        
        // Проверяем флуд бессмысленными сообщениями
        if (isFloodMessage(message)) {
            floodViolators.put(username, now);
        }
        
        // Получаем или создаем список сообщений игрока
        List<MessageEntry> messages = playerMessages.computeIfAbsent(username, k -> new ArrayList<>());
        
        // Удаляем старые сообщения (старше 60 секунд)
        messages.removeIf(entry -> now - entry.timestamp > MESSAGE_LIFETIME);
        
        // Добавляем новое сообщение
        messages.add(new MessageEntry(message, now));
        
        // Проверяем на спам
        return checkSpam(messages, message);
    }
    
    /**
     * Проверяет является ли игрок спамером
     * @param username Никнейм игрока
     * @return true если игрок спамит
     */
    public static boolean isSpammer(String username) {
        if (username == null) {
            return false;
        }
        
        List<MessageEntry> messages = playerMessages.get(username);
        if (messages == null || messages.isEmpty()) {
            return false;
        }
        
        long now = System.currentTimeMillis();
        
        // Удаляем старые сообщения
        messages.removeIf(entry -> now - entry.timestamp > MESSAGE_LIFETIME);
        
        // Проверяем есть ли 3+ одинаковых сообщения
        Map<String, Integer> messageCounts = new HashMap<>();
        for (MessageEntry entry : messages) {
            messageCounts.put(entry.message, messageCounts.getOrDefault(entry.message, 0) + 1);
        }
        
        for (int count : messageCounts.values()) {
            if (count >= SPAM_THRESHOLD) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Проверяет является ли игрок нарушителем капса
     * @param username Никнейм игрока
     * @return true если игрок использует капс
     */
    public static boolean isCapsViolator(String username) {
        if (username == null) {
            return false;
        }
        
        Long timestamp = capsViolators.get(username);
        if (timestamp == null) {
            return false;
        }
        
        long now = System.currentTimeMillis();
        
        // Проверяем не истекла ли метка
        if (now - timestamp > CAPS_MARK_LIFETIME) {
            capsViolators.remove(username);
            return false;
        }
        
        return true;
    }
    
    /**
     * Проверяет является ли игрок нарушителем флуда
     * @param username Никнейм игрока
     * @return true если игрок флудит бессмысленными сообщениями
     */
    public static boolean isFloodViolator(String username) {
        if (username == null) {
            return false;
        }
        
        Long timestamp = floodViolators.get(username);
        if (timestamp == null) {
            return false;
        }
        
        long now = System.currentTimeMillis();
        
        // Проверяем не истекла ли метка
        if (now - timestamp > FLOOD_MARK_LIFETIME) {
            floodViolators.remove(username);
            return false;
        }
        
        return true;
    }
    
    /**
     * Проверяет сообщение на использование капса
     * @param message Текст сообщения
     * @return true если сообщение нарушает правила капса
     */
    private static boolean isCapsMessage(String message) {
        if (message == null || message.isEmpty()) {
            return false;
        }
        
        // Считаем буквы
        int totalLetters = 0;
        int upperCaseLetters = 0;
        
        for (char c : message.toCharArray()) {
            if (Character.isLetter(c)) {
                totalLetters++;
                if (Character.isUpperCase(c)) {
                    upperCaseLetters++;
                }
            }
        }
        
        // Проверяем условия:
        // 1. Минимум 6 заглавных букв
        if (upperCaseLetters >= CAPS_MIN_LENGTH) {
            return true;
        }
        
        // 2. 50% или больше заглавных букв (если есть хотя бы 1 буква)
        if (totalLetters > 0) {
            double capsRatio = (double) upperCaseLetters / totalLetters;
            if (capsRatio >= CAPS_THRESHOLD) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Проверяет сообщение на флуд бессмысленными символами
     * @param message Текст сообщения
     * @return true если сообщение является флудом
     */
    private static boolean isFloodMessage(String message) {
        if (message == null || message.length() < FLOOD_MIN_LENGTH) {
            return false;
        }
        
        // Убираем пробелы для анализа
        String cleaned = message.replaceAll("\\s+", "");
        
        if (cleaned.length() < FLOOD_MIN_LENGTH) {
            return false;
        }
        
        // Подсчитываем частоту каждого символа
        Map<Character, Integer> charFrequency = new HashMap<>();
        for (char c : cleaned.toCharArray()) {
            charFrequency.put(c, charFrequency.getOrDefault(c, 0) + 1);
        }
        
        // Находим самый частый символ
        int maxFrequency = 0;
        for (int freq : charFrequency.values()) {
            if (freq > maxFrequency) {
                maxFrequency = freq;
            }
        }
        
        // Если один символ повторяется 60%+ раз - это флуд
        double repeatRatio = (double) maxFrequency / cleaned.length();
        if (repeatRatio >= FLOOD_REPEAT_THRESHOLD) {
            return true;
        }
        
        // Проверяем на повторяющиеся паттерны (2-3 символа)
        // Например: "хахахахаха", "хыхыхыхы", "[f[f[f[f"
        if (hasRepeatingPattern(cleaned)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Проверяет наличие повторяющихся паттернов в сообщении
     */
    private static boolean hasRepeatingPattern(String text) {
        if (text.length() < FLOOD_MIN_LENGTH) {
            return false;
        }
        
        // Проверяем паттерны длиной 2-4 символа
        for (int patternLength = 2; patternLength <= 4; patternLength++) {
            if (text.length() < patternLength * 3) {
                continue; // Нужно минимум 3 повторения
            }
            
            // Берем первый паттерн
            String pattern = text.substring(0, patternLength);
            
            // Считаем сколько раз он повторяется подряд
            int repeatCount = 1;
            int pos = patternLength;
            
            while (pos + patternLength <= text.length()) {
                String nextChunk = text.substring(pos, pos + patternLength);
                if (nextChunk.equals(pattern)) {
                    repeatCount++;
                    pos += patternLength;
                } else {
                    break;
                }
            }
            
            // Если паттерн повторился 4+ раз - это флуд
            if (repeatCount >= 4) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Проверяет наличие спама в списке сообщений
     */
    private static boolean checkSpam(List<MessageEntry> messages, String newMessage) {
        int count = 0;
        for (MessageEntry entry : messages) {
            if (entry.message.equals(newMessage)) {
                count++;
            }
        }
        return count >= SPAM_THRESHOLD;
    }
    
    /**
     * Очищает все данные
     */
    public static void clear() {
        playerMessages.clear();
        capsViolators.clear();
        floodViolators.clear();
    }
    
    /**
     * Очищает данные конкретного игрока
     */
    public static void clearPlayer(String username) {
        playerMessages.remove(username);
        capsViolators.remove(username);
        floodViolators.remove(username);
    }
    
    /**
     * Запись сообщения с временем
     */
    private static class MessageEntry {
        final String message;
        final long timestamp;
        
        MessageEntry(String message, long timestamp) {
            this.message = message;
            this.timestamp = timestamp;
        }
    }
}
